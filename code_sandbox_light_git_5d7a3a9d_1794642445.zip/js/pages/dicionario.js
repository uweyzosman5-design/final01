/* ============================================================
   Página do dicionário
   ============================================================ */
(function () {
  'use strict';

  function esc(s) { return window.EF.ui.esc(s); }

  var termo = '';
  var letra = null;
  var categoria = 'todas';
  var soFavoritos = false;
  var ordem = 'en';
  var limite = 24;

  function todas() {
    return (window.EF.dicionario || []).slice();
  }

  function filtrar() {
    var t = window.EF.exercicios ? window.EF.exercicios.normalizarTexto(termo) : termo.toLowerCase();
    var lista = todas().filter(function (d) {
      var okTermo = !t ||
        d.en.toLowerCase().indexOf(t) !== -1 ||
        d.pt.toLowerCase().indexOf(t) !== -1;
      var okLetra = !letra || d.en.toLowerCase().charAt(0) === letra.toLowerCase();
      var okCat = categoria === 'todas' || d.cat === categoria;
      var okFav = !soFavoritos || window.EF.store.ehFavorito(d.en);
      return okTermo && okLetra && okCat && okFav;
    });

    if (ordem === 'pt') lista.sort(function (a, b) { return a.pt.localeCompare(b.pt, 'pt'); });
    else if (ordem === 'cat') lista.sort(function (a, b) { return (a.cat + a.en).localeCompare(b.cat + b.en, 'pt'); });
    else lista.sort(function (a, b) { return a.en.localeCompare(b.en, 'en'); });

    return lista;
  }

  function itemHTML(d) {
    var fav = window.EF.store.ehFavorito(d.en);
    return '<article class="card dict-item">' +
      '<div class="flex-entre wrap gap-10">' +
        '<div class="dict-item__cab" style="margin:0">' +
          '<span class="dict-item__palavra">' + esc(d.en) + '</span>' +
          '<span class="dict-item__classe">' + esc(d.classe || '') + '</span>' +
          '<span class="badge badge--cinza" style="font-size:.66rem">' + esc(d.cat || '') + '</span>' +
        '</div>' +
        '<div class="flex-centro gap-6">' +
          '<button class="btn-audio" type="button" data-falar="' + esc(d.en) + '" aria-label="Ouvir ' + esc(d.en) + '">' +
            '<i class="fa-solid fa-volume-high" aria-hidden="true"></i></button>' +
          '<button class="btn-audio" type="button" data-fav="' + esc(d.en) + '" aria-pressed="' + (fav ? 'true' : 'false') + '" ' +
            'aria-label="Guardar nos favoritos: ' + esc(d.en) + '"' + (fav ? ' style="background:var(--amarelo);color:#42360a"' : '') + '>' +
            '<i class="fa-' + (fav ? 'solid' : 'regular') + ' fa-star" aria-hidden="true"></i></button>' +
        '</div>' +
      '</div>' +
      '<div class="dict-item__traducao">' + esc(d.pt) + '</div>' +
      '<div class="pequeno muted">Pronúncia: <strong>' + esc(d.pron) + '</strong></div>' +
      '<div class="dict-item__bloco"><b>Exemplo</b><em>' + esc(d.ex) + '</em><br>' + esc(d.exPt) + '</div>' +
      (d.sin && d.sin.length ? '<div class="dict-item__bloco"><b>Sinónimos</b>' + esc(d.sin.join(', ')) +
        ' <button class="btn-audio" type="button" data-falar="' + esc(d.sin[0]) + '" style="width:24px;height:24px;font-size:.65rem" aria-label="Ouvir sinónimo"><i class="fa-solid fa-volume-high" aria-hidden="true"></i></button></div>' : '') +
      (d.ant && d.ant.length ? '<div class="dict-item__bloco"><b>Antónimos</b>' + esc(d.ant.join(', ')) + '</div>' : '') +
    '</article>';
  }

  function render() {
    var lista = filtrar();
    var alvo = document.getElementById('listaDicionario');
    var info = document.getElementById('resultadoInfo');
    if (!alvo) return;

    var visiveis = lista.slice(0, limite);

    if (!lista.length) {
      alvo.innerHTML = '<div class="vazio"><div class="vazio__ico">🔍</div>' +
        '<p>Nenhuma entrada encontrada' + (termo ? ' para «' + esc(termo) + '»' : '') + '.</p>' +
        '<p class="pequeno">Tenta uma palavra mais simples ou pesquisa em português.</p>' +
        '<button class="btn btn--pequeno btn--ghost" type="button" data-limpar-tudo>Limpar filtros</button></div>';
    } else {
      alvo.innerHTML = visiveis.map(itemHTML).join('');
    }

    if (info) {
      info.textContent = lista.length + ' entrada' + (lista.length === 1 ? '' : 's') +
        (soFavoritos ? ' nos favoritos' : '') +
        (letra ? ' a começar por «' + letra.toUpperCase() + '»' : '') +
        (termo ? ' para «' + termo + '»' : '') +
        (visiveis.length < lista.length ? ' · a mostrar ' + visiveis.length : '');
    }

    var btnMais = document.getElementById('btnMais');
    if (btnMais) btnMais.style.display = visiveis.length < lista.length ? '' : 'none';
  }

  function renderLetras() {
    var alvo = document.getElementById('letras');
    if (!alvo) return;
    var usadas = {};
    todas().forEach(function (d) { usadas[d.en.charAt(0).toUpperCase()] = true; });
    var alfabeto = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
    alvo.innerHTML = '<button class="letra-btn ativo" type="button" data-letra="">Todas</button>' +
      alfabeto.map(function (l) {
        var tem = usadas[l];
        return '<button class="letra-btn" type="button" data-letra="' + l + '"' +
          (tem ? '' : ' disabled style="opacity:.32;cursor:default"') + '>' + l + '</button>';
      }).join('');
  }

  function renderCategorias() {
    var sel = document.getElementById('filtroCat');
    if (!sel) return;
    var cats = {};
    todas().forEach(function (d) { if (d.cat) cats[d.cat] = (cats[d.cat] || 0) + 1; });
    sel.innerHTML = '<option value="todas">Todas as categorias (' + todas().length + ')</option>' +
      Object.keys(cats).sort().map(function (c) {
        return '<option value="' + esc(c) + '">' + esc(c) + ' (' + cats[c] + ')</option>';
      }).join('');
  }

  function atualizarFavoritos() {
    var u = window.EF.store.utilizador();
    var n = u && Array.isArray(u.favoritos) ? u.favoritos.length : 0;
    var cont = document.getElementById('contFavoritos');
    if (cont) cont.textContent = n;
  }

  document.addEventListener('DOMContentLoaded', function () {
    window.EF.ui.iniciar('dicionario');

    var total = todas().length;
    var tp = document.getElementById('totalPalavras');
    if (tp) tp.textContent = total;

    renderLetras();
    renderCategorias();
    atualizarFavoritos();
    render();

    /* Destacar pesquisa vinda de outra página */
    var params = new URLSearchParams(window.location.search);
    if (params.get('q')) {
      termo = params.get('q');
      var inp = document.getElementById('buscaDicionario');
      if (inp) inp.value = termo;
      render();
    }

    var inp = document.getElementById('buscaDicionario');
    if (inp) {
      inp.addEventListener('input', function () {
        termo = inp.value.trim();
        limite = 24;
        letra = null;
        document.querySelectorAll('[data-letra]').forEach(function (b) { b.classList.remove('ativo'); });
        var primeira = document.querySelector('[data-letra=""]');
        if (primeira) primeira.classList.add('ativo');
        render();
      });
    }

    document.addEventListener('click', function (e) {
      var lb = e.target.closest('[data-letra]');
      if (lb && !lb.disabled) {
        letra = lb.getAttribute('data-letra') || null;
        limite = 24;
        document.querySelectorAll('[data-letra]').forEach(function (b) { b.classList.remove('ativo'); });
        lb.classList.add('ativo');
        render();
        return;
      }

      var favBtn = e.target.closest('[data-fav]');
      if (favBtn) {
        var palavra = favBtn.getAttribute('data-fav');
        if (!window.EF.store.utilizador()) {
          window.EF.ui.toast('Cria conta para guardar favoritos.', 'info');
          window.EF.ui.abrirLogin('registo');
          return;
        }
        var r = window.EF.store.alternarFavorito(palavra);
        atualizarFavoritos();
        window.EF.ui.toast(r.ativo ? '«' + palavra + '» guardada.' : 'Removida dos favoritos.', 'ok');
        (r.medalhas || []).forEach(function (m) {
          var meta = window.EF.medalhas.filter(function (x) { return x.id === m; })[0];
          if (meta) setTimeout(function () { window.EF.ui.toast('Medalha: ' + meta.nome + ' ' + meta.icone, 'ok'); }, 500);
        });
        render();
        return;
      }

      if (e.target.closest('[data-limpar-tudo]')) {
        termo = ''; letra = null; categoria = 'todas'; soFavoritos = false; limite = 24;
        if (inp) inp.value = '';
        var sel = document.getElementById('filtroCat');
        if (sel) sel.value = 'todas';
        renderLetras();
        render();
      }
    });

    var sel = document.getElementById('filtroCat');
    if (sel) {
      sel.addEventListener('change', function () {
        categoria = sel.value;
        limite = 24;
        render();
      });
    }

    var ord = document.getElementById('ordenarPor');
    if (ord) {
      ord.addEventListener('change', function () { ordem = ord.value; render(); });
    }

    var btnFav = document.getElementById('btnFavoritos');
    if (btnFav) {
      btnFav.addEventListener('click', function () {
        soFavoritos = !soFavoritos;
        btnFav.setAttribute('aria-pressed', soFavoritos ? 'true' : 'false');
        btnFav.classList.toggle('btn--amarelo', soFavoritos);
        btnFav.classList.toggle('btn--ghost', !soFavoritos);
        render();
      });
    }

    var btnMais = document.getElementById('btnMais');
    if (btnMais) {
      btnMais.addEventListener('click', function () { limite += 24; render(); });
    }

    var btnLimpar = document.getElementById('btnLimparBusca');
    if (btnLimpar) {
      btnLimpar.addEventListener('click', function () {
        termo = '';
        if (inp) { inp.value = ''; inp.focus(); }
        render();
      });
    }
  });
})();
