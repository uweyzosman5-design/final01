/* ============================================================
   Página de certificado de conclusão de nível
   ============================================================ */
(function () {
  'use strict';

  function esc(s) { return window.EF.ui.esc(s); }

  document.addEventListener('DOMContentLoaded', function () {
    window.EF.ui.iniciar('painel');
    var alvo = document.getElementById('areaCertificado');
    var params = new URLSearchParams(window.location.search);
    var nivelId = params.get('nivel') || 'iniciante';
    var nivel = window.EF.niveis.filter(function (n) { return n.id === nivelId; })[0];
    var u = window.EF.store.utilizador();

    if (!nivel) {
      alvo.innerHTML = '<div class="vazio"><div class="vazio__ico">📭</div><h2>Nível não encontrado</h2><a class="btn" href="cursos.html">Ver cursos</a></div>';
      return;
    }

    var p = window.EF.store.progressoNivel(nivelId);
    var completo = p.pct === 100;

    if (!u) {
      alvo.innerHTML = '<div class="card text-center" style="max-width:520px;margin:0 auto;padding:40px 24px">' +
        '<div style="font-size:2.4rem">🔐</div><h2>Entra na tua conta</h2>' +
        '<p class="pequeno">O certificado é emitido com o teu nome e só fica disponível quando concluis todas as aulas do nível.</p>' +
        '<button class="btn" type="button" data-abrir-login data-aba="entrar">Entrar</button></div>';
      return;
    }

    if (!completo) {
      alvo.innerHTML = '<div class="card text-center" style="max-width:560px;margin:0 auto;padding:40px 24px">' +
        '<div style="font-size:2.4rem">🔒</div>' +
        '<h2>Certificado ainda bloqueado</h2>' +
        '<p class="pequeno">Concluíste <strong>' + p.feitas + ' de ' + p.total + '</strong> aulas do nível ' + esc(nivel.nome) + '. Faltam ' + (p.total - p.feitas) + '.</p>' +
        '<div class="barra-progresso mb-20"><span style="width:' + Math.max(1, p.pct) + '%;background:' + nivel.corHex + '"></span></div>' +
        '<a class="btn" href="cursos.html?nivel=' + nivelId + '">Continuar as aulas</a></div>';
      return;
    }

    var data = new Date().toLocaleDateString('pt-PT', { day: '2-digit', month: 'long', year: 'numeric' });
    var codigo = 'EF-' + nivelId.toUpperCase().slice(0, 3) + '-' + String(Date.now()).slice(-6);

    document.title = 'Certificado ' + nivel.nome + ' — English Fácil';

    alvo.innerHTML =
      '<div class="flex-entre wrap gap-10 mb-20 no-print">' +
        '<h1 style="font-size:1.3rem;margin:0">Certificado de conclusão</h1>' +
        '<div class="flex gap-10 wrap">' +
          '<button class="btn btn--pequeno" type="button" id="btnImprimir"><i class="fa-solid fa-print" aria-hidden="true"></i> Imprimir / Guardar PDF</button>' +
          '<a class="btn btn--pequeno btn--ghost" href="painel.html">Voltar ao painel</a>' +
        '</div>' +
      '</div>' +
      '<div class="certificado" id="certificadoFinal">' +
        '<div style="font-size:2.4rem;line-height:1">🎓</div>' +
        '<div class="pequeno" style="letter-spacing:.28em;text-transform:uppercase;color:#64748b;margin-top:10px">English Fácil</div>' +
        '<h2 style="margin-top:14px">Certificado de Conclusão</h2>' +
        '<p style="color:#475569;margin:0">Certificamos que</p>' +
        '<div class="cert-nome">' + esc(u.nome) + '</div>' +
        '<p style="color:#334155;max-width:560px;margin:0 auto 6px">concluiu com aproveitamento todas as <strong>' + p.total + ' aulas</strong> do nível</p>' +
        '<div style="font-size:1.28rem;font-weight:800;color:#1d4ed8;margin:10px 0">' + nivel.icone + ' ' + esc(nivel.nome) + ' (' + nivel.cefr + ')</div>' +
        '<p style="color:#64748b;font-size:.86rem;max-width:520px;margin:6px auto 0">' + esc(nivel.resumo) + '</p>' +
        '<div style="display:flex;justify-content:space-around;flex-wrap:wrap;gap:18px;margin-top:34px;font-size:.8rem;color:#475569">' +
          '<div><strong style="display:block;color:#10214a">' + data + '</strong>Data de emissão</div>' +
          '<div><strong style="display:block;color:#10214a">' + esc(codigo) + '</strong>Código de verificação</div>' +
          '<div><strong style="display:block;color:#10214a">' + (u.pontos || 0) + ' pontos</strong>Pontuação total</div>' +
        '</div>' +
        '<div style="margin-top:26px;padding-top:16px;border-top:1px dashed #cbd5e1;font-size:.72rem;color:#94a3b8">' +
          'Certificado digital emitido pela plataforma English Fácil · englishfacil · válido como registo de estudo pessoal.' +
        '</div>' +
      '</div>' +
      '<p class="pequeno muted text-center mt-20 no-print" style="max-width:560px;margin-left:auto;margin-right:auto">' +
        'Este certificado atesta a conclusão das aulas desta plataforma e não substitui exames oficiais de certificação (Cambridge, IELTS, TOEFL).</p>';

    var btn = document.getElementById('btnImprimir');
    if (btn) btn.addEventListener('click', function () { window.print(); });
  });
})();
