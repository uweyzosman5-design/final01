/* ============================================================
   Página de aula — explicação, vocabulário, exercícios, teste
   ============================================================ */
(function () {
  'use strict';

  function esc(s) { return window.EF.ui.esc(s); }
  var licao = null;
  var nivel = null;

  function buscarLicao() {
    var params = new URLSearchParams(window.location.search);
    var id = params.get('id');
    var licoes = window.EF.licoes || [];
    if (!id) {
      var prox = window.EF.store.proximaLicao();
      return prox || licoes[0] || null;
    }
    return licoes.filter(function (l) { return l.id === id; })[0] || licoes[0] || null;
  }

  function blocoExplicacao(l) {
    return '<section class="bloco-aula reveal" id="explicacao">' +
      '<h2><span class="num-secao" aria-hidden="true">1</span> Explicação em português</h2>' +
      '<div class="explicacao">' +
        l.explicacao.map(function (b) {
          return '<h3 style="font-size:1rem;margin-top:18px;margin-bottom:6px">' + esc(b.t) + '</h3><p>' + b.p + '</p>';
        }).join('') +
      '</div>' +
      (l.dica ? '<div class="destaque"><i class="fa-solid fa-lightbulb amarelo" aria-hidden="true"></i> <strong>Dica do professor:</strong> ' + l.dica + '</div>' : '') +
    '</section>';
  }

  function blocoTabela(l) {
    if (!l.tabela) return '';
    return '<section class="bloco-aula reveal" id="tabela">' +
      '<h2><span class="num-secao" aria-hidden="true">2</span> ' + esc(l.tabela.titulo) + '</h2>' +
      '<div style="overflow-x:auto">' +
        '<table class="tabela"><thead><tr>' +
          l.tabela.cabecalho.map(function (c) { return '<th scope="col">' + esc(c) + '</th>'; }).join('') +
        '</tr></thead><tbody>' +
          l.tabela.linhas.map(function (linha) {
            return '<tr>' + linha.map(function (c, i) {
              return i === 0 ? '<td><strong>' + esc(c) + '</strong></td>' : '<td>' + esc(c) + '</td>';
            }).join('') + '</tr>';
          }).join('') +
        '</tbody></table>' +
      '</div>' +
    '</section>';
  }

  function blocoVocabulario(l) {
    return '<section class="bloco-aula reveal" id="vocabulario">' +
      '<h2><span class="num-secao" aria-hidden="true">3</span> Palavras e frases da aula</h2>' +
      '<p class="pequeno muted">Toca no altifalante para ouvir a pronúncia correta. A coluna «pronúncia» é uma aproximação para português.</p>' +
      '<div class="grelha grelha--2" style="gap:12px">' +
        l.vocabulario.map(function (v) {
          var fav = window.EF.store.ehFavorito(v.en);
          return '<div class="vocab">' +
            '<div class="vocab__topo">' +
              '<span class="vocab__en">' + esc(v.en) + '</span>' +
              '<button class="btn-audio" type="button" data-falar="' + esc(v.en) + '" aria-label="Ouvir ' + esc(v.en) + '">' +
                '<i class="fa-solid fa-volume-high" aria-hidden="true"></i></button>' +
              '<button class="btn-audio fav-btn' + (fav ? ' ativo' : '') + '" type="button" data-favoritar="' + esc(v.en) + '" aria-label="Guardar nos favoritos: ' + esc(v.en) + '" aria-pressed="' + (fav ? 'true' : 'false') + '"' +
                (fav ? ' style="background:var(--amarelo);color:#42360a"' : '') + '>' +
                '<i class="fa-' + (fav ? 'solid' : 'regular') + ' fa-star" aria-hidden="true"></i></button>' +
            '</div>' +
            '<span class="vocab__pt">' + esc(v.pt) + '</span>' +
            '<span class="vocab__pron">Pronúncia: ' + esc(v.pron) + '</span>' +
            '<div class="vocab__ex">' + esc(v.ex) + '<em>' + esc(v.exPt) + '</em></div>' +
          '</div>';
        }).join('') +
      '</div>' +
    '</section>';
  }

  function blocoObjetivos(l) {
    return '<section class="bloco-aula reveal" id="objetivos">' +
      '<h2><span class="num-secao" aria-hidden="true">0</span> No fim desta aula vais conseguir</h2>' +
      '<ul style="list-style:none;padding:0;margin:0">' +
        l.objetivos.map(function (o) {
          return '<li style="display:flex;gap:10px;align-items:flex-start;margin-bottom:8px">' +
            '<i class="fa-solid fa-circle-check verde" aria-hidden="true" style="margin-top:4px"></i><span class="pequeno">' + esc(o) + '</span></li>';
        }).join('') +
      '</ul></section>';
  }

  function blocoExercicios(l) {
    return '<section class="bloco-aula reveal" id="exercicios">' +
      '<h2><span class="num-secao" aria-hidden="true">4</span> Exercícios práticos</h2>' +
      '<p class="pequeno muted">Correção imediata com explicação do motivo. Podes repetir quantas vezes quiseres.</p>' +
      '<div id="areaExercicios"></div>' +
    '</section>';
  }

  function blocoTeste(l) {
    return '<section class="bloco-aula reveal" id="testeFinal">' +
      '<h2><span class="num-secao" aria-hidden="true">5</span> Teste final da aula</h2>' +
      '<p class="pequeno muted">Todas as perguntas em sequência. No fim recebes a pontuação e ganhas pontos para o teu perfil.</p>' +
      '<div id="areaTeste"></div>' +
    '</section>';
  }

  function render() {
    if (!licao) {
      document.getElementById('aulaConteudo').innerHTML =
        '<div class="vazio"><div class="vazio__ico">📭</div><h2>Aula não encontrada</h2>' +
        '<p>O endereço não corresponde a nenhuma aula.</p><a class="btn" href="cursos.html">Ver todos os cursos</a></div>';
      return;
    }
    nivel = window.EF.niveis.filter(function (n) { return n.id === licao.nivel; })[0] || { nome: licao.nivel, cefr: '', cor: 'a1' };
    document.title = licao.titulo + ' — English Fácil';

    document.getElementById('aulaTitulo').textContent = licao.icone + ' ' + licao.titulo;
    document.getElementById('aulaResumo').textContent = licao.resumo;
    document.getElementById('aulaBreadcrumb').innerHTML =
      '<a href="cursos.html" style="color:#bfdbfe;font-size:.85rem"><i class="fa-solid fa-arrow-left" aria-hidden="true"></i> Voltar aos cursos</a>' +
      '<span style="color:#64748b">/</span>' +
      '<a href="cursos.html?nivel=' + licao.nivel + '" style="color:#bfdbfe;font-size:.85rem">' + esc(nivel.nome) + ' · ' + nivel.cefr + '</a>';

    var u = window.EF.store.utilizador();
    var feita = window.EF.store.licaoConcluida(u, licao.id);
    document.getElementById('aulaMeta').innerHTML =
      '<span class="badge">' + esc(nivel.nome) + ' · ' + nivel.cefr + '</span>' +
      '<span class="badge badge--amarelo"><i class="fa-regular fa-clock"></i> ' + licao.min + ' min</span>' +
      '<span class="badge" style="background:rgba(255,255,255,.16);color:#fff"><i class="fa-solid fa-list-check"></i> ' + licao.exercicios.length + ' exercícios</span>' +
      (feita ? '<span class="badge" style="background:#16a34a;color:#fff"><i class="fa-solid fa-check"></i> Concluída</span>' : '');

    document.getElementById('aulaConteudo').innerHTML =
      blocoObjetivos(licao) +
      blocoExplicacao(licao) +
      blocoTabela(licao) +
      blocoVocabulario(licao) +
      blocoExercicios(licao) +
      blocoTeste(licao) +
      '<section class="bloco-aula"><div class="flex-entre wrap gap-14">' +
        '<div><strong>Terminaste a aula?</strong><p class="pequeno muted mb-0">Marca como concluída para ganhar pontos e manter a sequência.</p></div>' +
        '<div class="flex gap-10 wrap">' +
          '<button class="btn btn--amarelo" type="button" id="btnConcluir"><i class="fa-solid fa-check" aria-hidden="true"></i> Marcar aula como concluída</button>' +
          '<a class="btn btn--ghost" href="#" id="btnProximaAula">Próxima aula <i class="fa-solid fa-arrow-right" aria-hidden="true"></i></a>' +
        '</div></div></section>';

    renderExercicioSequencial();
    renderTeste();
    renderLateral();
    ligarFavoritos();
    ligarConcluir();
    ligarIndice();

    document.getElementById('linkProfessor').href = 'conversacao.html?tema=' + encodeURIComponent(licao.titulo);

    /* Reveal dos blocos */
    if ('IntersectionObserver' in window) {
      var obs = new IntersectionObserver(function (en) {
        en.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('visivel'); obs.unobserve(e.target); } });
      }, { threshold: 0.05 });
      document.querySelectorAll('.reveal').forEach(function (el) { obs.observe(el); });
    } else {
      document.querySelectorAll('.reveal').forEach(function (el) { el.classList.add('visivel'); });
    }
  }

  function renderExercicioSequencial() {
    var area = document.getElementById('areaExercicios');
    if (!area) return;
    var exs = licao.exercicios || [];
    var indice = 0, acertos = 0;

    function passo() {
      if (indice >= exs.length) {
        var pct = Math.round((acertos / exs.length) * 100);
        area.innerHTML = '<div class="card text-center" style="background:var(--card-2)">' +
          '<div style="font-size:2rem">' + (pct >= 80 ? '🎯' : pct >= 50 ? '👏' : '💪') + '</div>' +
          '<h3 style="font-size:1.1rem">' + acertos + ' de ' + exs.length + ' exercícios corretos</h3>' +
          '<p class="pequeno">' + (pct >= 80 ? 'Excelente domínio desta aula!' : 'Reveja a explicação e repita — a repetição é o que fixa.') + '</p>' +
          '<button class="btn btn--pequeno btn--ghost" type="button" data-repetir-ex>Repetir exercícios</button></div>';
        area.querySelector('[data-repetir-ex]').addEventListener('click', function () {
          indice = 0; acertos = 0; passo();
        });
        return;
      }
      area.innerHTML = '';
      var alvo = document.createElement('div');
      area.appendChild(alvo);
      window.EF.exercicios.render(exs[indice], alvo, {
        indice: indice,
        total: exs.length,
        aoResponder: function (ok) {
          if (ok) acertos++;
          var botoes = document.createElement('div');
          botoes.className = 'flex gap-10 wrap mt-20';
          botoes.innerHTML = '<button class="btn" type="button" data-prox-ex>' +
            (indice === exs.length - 1 ? 'Ver resultado <i class="fa-solid fa-flag-checkered"></i>' : 'Próximo exercício <i class="fa-solid fa-arrow-right"></i>') +
            '</button>';
          alvo.querySelector('.exercicio').appendChild(botoes);
          botoes.querySelector('[data-prox-ex]').addEventListener('click', function () { indice++; passo(); });
        }
      });
    }
    passo();
  }

  function renderTeste() {
    var area = document.getElementById('areaTeste');
    if (!area) return;
    var exs = (licao.exercicios || []).slice();
    window.EF.exercicios.criarTeste(area, exs, {
      titulo: licao.titulo,
      aoTerminar: function (res) {
        var u = window.EF.store.utilizador();
        if (u) {
          var novas = window.EF.store.registarTeste({
            tipo: 'aula-' + licao.id,
            acertos: res.acertos,
            total: res.total,
            data: Date.now()
          });
          window.EF.store.enviarParaRanking();
          novas.forEach(function (m) {
            var meta = window.EF.medalhas.filter(function (x) { return x.id === m; })[0];
            if (meta) window.EF.ui.toast('Medalha desbloqueada: ' + meta.nome + ' ' + meta.icone, 'ok');
          });
          window.EF.ui.toast('Resultado guardado. Bom trabalho!', 'ok');
        } else {
          window.EF.ui.toast('Cria conta para guardar o resultado e ganhar pontos.', 'info');
        }
        renderLateral();
      }
    });
  }

  function renderLateral() {
    var p = window.EF.store.progressoNivel(licao.nivel);
    document.getElementById('lateralPct').textContent = p.pct + '%';
    document.getElementById('lateralBarra').style.width = Math.max(1, p.pct) + '%';
    document.getElementById('lateralTexto').textContent = p.feitas + ' de ' + p.total + ' aulas do nível ' + nivel.nome;

    var indice = [
      ['objetivos', 'Objetivos'],
      ['explicacao', 'Explicação'],
      ['tabela', 'Tabela'],
      ['vocabulario', 'Vocabulário'],
      ['exercicios', 'Exercícios'],
      ['testeFinal', 'Teste final']
    ].filter(function (i) { return document.getElementById(i[0]); });

    document.getElementById('lateralIndice').innerHTML = indice.map(function (i) {
      return '<li style="margin-bottom:8px"><a href="#' + i[0] + '" class="flex-centro gap-6 pequeno" style="text-decoration:none">' +
        '<i class="fa-solid fa-circle-small muted" aria-hidden="true" style="font-size:.4rem"></i> ' + i[1] + '</a></li>';
    }).join('');

    var u = window.EF.store.utilizador();
    var doNivel = (window.EF.licoes || []).filter(function (l) { return l.nivel === licao.nivel; });
    document.getElementById('lateralAulas').innerHTML = doNivel.map(function (l) {
      var ativo = l.id === licao.id;
      var feita = window.EF.store.licaoConcluida(u, l.id);
      return '<li style="margin-bottom:8px"><a href="aula.html?id=' + l.id + '" class="pequeno flex-centro gap-6" ' +
        'style="text-decoration:none;' + (ativo ? 'font-weight:800;color:var(--azul-600)' : '') + '">' +
        '<i class="fa-solid ' + (feita ? 'fa-circle-check verde' : 'fa-circle muted') + '" aria-hidden="true" style="font-size:.7rem"></i> ' +
        (l.ordem) + '. ' + esc(l.titulo) + '</a></li>';
    }).join('');

    var prox = proximaDoNivel();
    var btn = document.getElementById('btnProximaAula');
    if (btn && prox) btn.href = 'aula.html?id=' + prox.id;
  }

  function proximaDoNivel() {
    var lista = window.EF.licoes || [];
    var i = lista.findIndex(function (l) { return l.id === licao.id; });
    return i >= 0 && i + 1 < lista.length ? lista[i + 1] : null;
  }

  function ligarFavoritos() {
    document.querySelectorAll('[data-favoritar]').forEach(function (b) {
      b.addEventListener('click', function () {
        var palavra = b.getAttribute('data-favoritar');
        if (!window.EF.store.utilizador()) {
          window.EF.ui.toast('Cria conta para guardar palavras favoritas.', 'info');
          window.EF.ui.abrirLogin('registo');
          return;
        }
        var r = window.EF.store.alternarFavorito(palavra);
        b.classList.toggle('ativo', r.ativo);
        b.style.background = r.ativo ? 'var(--amarelo)' : '';
        b.style.color = r.ativo ? '#42360a' : '';
        b.setAttribute('aria-pressed', r.ativo ? 'true' : 'false');
        b.innerHTML = '<i class="fa-' + (r.ativo ? 'solid' : 'regular') + ' fa-star" aria-hidden="true"></i>';
        window.EF.ui.toast(r.ativo ? '«' + palavra + '» guardada nos favoritos.' : 'Removida dos favoritos.', 'ok');
        (r.medalhas || []).forEach(function (m) {
          var meta = window.EF.medalhas.filter(function (x) { return x.id === m; })[0];
          if (meta) window.EF.ui.toast('Medalha: ' + meta.nome + ' ' + meta.icone, 'ok');
        });
      });
    });
  }

  function ligarConcluir() {
    var btn = document.getElementById('btnConcluir');
    if (!btn) return;
    var u = window.EF.store.utilizador();
    if (u && window.EF.store.licaoConcluida(u, licao.id)) {
      btn.innerHTML = '<i class="fa-solid fa-check"></i> Aula já concluída';
      btn.classList.remove('btn--amarelo');
      btn.classList.add('btn--ghost');
    }
    btn.addEventListener('click', function () {
      if (!window.EF.store.utilizador()) {
        window.EF.ui.toast('Cria conta grátis para guardar o progresso.', 'info');
        window.EF.ui.abrirLogin('registo');
        return;
      }
      var r = window.EF.store.concluirLicao(licao.id, licao.exercicios.length, licao.exercicios.length);
      window.EF.store.enviarParaRanking();
      if (r.pontos > 0) {
        window.EF.ui.toast('Aula concluída! +' + r.pontos + ' pontos', 'ok');
      } else {
        window.EF.ui.toast('Aula revista. Progresso mantido.', 'ok');
      }
      (r.medalhas || []).forEach(function (m) {
        var meta = window.EF.medalhas.filter(function (x) { return x.id === m; })[0];
        if (meta) setTimeout(function () { window.EF.ui.toast('Medalha desbloqueada: ' + meta.nome + ' ' + meta.icone, 'ok'); }, 700);
      });
      renderLateral();
      btn.innerHTML = '<i class="fa-solid fa-check"></i> Aula concluída';
      btn.classList.add('btn--ghost');
      btn.classList.remove('btn--amarelo');
      /* Sugerir próxima aula */
      var prox = proximaDoNivel();
      if (prox) {
        setTimeout(function () {
          window.EF.ui.toast('A seguir: ' + prox.titulo, 'info');
        }, 1400);
      }
      /* Conquista de nível completo */
      var p = window.EF.store.progressoNivel(licao.nivel);
      if (p.pct === 100) {
        setTimeout(function () {
          window.EF.ui.abrirModal(
            '<div class="text-center"><div style="font-size:3rem">🎓</div>' +
            '<h2>Nível ' + esc(nivel.nome) + ' concluído!</h2>' +
            '<p>Completaste as ' + p.total + ' aulas deste nível. O teu certificado está pronto.</p>' +
            '<a class="btn btn--amarelo btn--bloco mt-20" href="certificado.html?nivel=' + licao.nivel + '">Ver certificado</a>' +
            '<button class="btn btn--ghost btn--bloco mt-10" type="button" data-fechar-modal>Continuar</button></div>'
          );
        }, 2000);
      }
    });
  }

  function ligarIndice() {
    document.querySelectorAll('#lateralIndice a').forEach(function (a) {
      a.addEventListener('click', function (e) {
        var alvo = document.querySelector(a.getAttribute('href'));
        if (alvo) {
          e.preventDefault();
          alvo.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      });
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    window.EF.ui.iniciar('cursos');
    licao = buscarLicao();
    render();
  });
})();
