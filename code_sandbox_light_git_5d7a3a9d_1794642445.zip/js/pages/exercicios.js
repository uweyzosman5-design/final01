/* ============================================================
   Página de exercícios interativos
   ============================================================ */
(function () {
  'use strict';

  function esc(s) { return window.EF.ui.esc(s); }

  var tipos = [
    { id: 'escolha', nome: 'Escolha múltipla', icone: 'fa-circle-check', cor: '', desc: 'Escolhe a opção correta entre três ou quatro alternativas.' },
    { id: 'completar', nome: 'Completar frases', icone: 'fa-pen-to-square', cor: 'icone-circulo--amarelo', desc: 'Preenche a lacuna com a palavra adequada.' },
    { id: 'traducao', nome: 'Traduzir', icone: 'fa-language', cor: 'icone-circulo--verde', desc: 'Traduz frases de português para inglês.' },
    { id: 'ordenar', nome: 'Ordenar palavras', icone: 'fa-shuffle', cor: 'icone-circulo--roxo', desc: 'Constrói a frase na ordem correta do inglês.' },
    { id: 'escuta', nome: 'Listening', icone: 'fa-headphones', cor: '', desc: 'Ouve o áudio e escolhe o que foi dito.' },
    { id: 'escrita', nome: 'Writing', icone: 'fa-pencil', cor: 'icone-circulo--verde', desc: 'Escreve livremente e compara com um exemplo.' },
    { id: 'fala', nome: 'Speaking', icone: 'fa-microphone', cor: 'icone-circulo--amarelo', desc: 'Grava a tua voz e compara com o modelo.' }
  ];

  var tipoAtual = null;
  var nivelAtual = 'todos';

  function todosExercicios() {
    var lista = [];
    (window.EF.licoes || []).forEach(function (l) {
      (l.exercicios || []).forEach(function (ex, i) {
        lista.push(Object.assign({}, ex, { _licao: l.titulo, _licaoId: l.id, _nivel: l.nivel, _idx: i }));
      });
    });
    return lista;
  }

  function filtrar(tipo, nivel) {
    return todosExercicios().filter(function (ex) {
      var okTipo = !tipo || ex.tipo === tipo;
      var okNivel = !nivel || nivel === 'todos' || ex._nivel === nivel;
      return okTipo && okNivel;
    });
  }

  function embaralhar(arr) {
    var a = arr.slice();
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }

  function renderTipos() {
    var alvo = document.getElementById('tiposExercicio');
    if (!alvo) return;
    alvo.innerHTML = tipos.map(function (t) {
      var n = filtrar(t.id, nivelAtual).length;
      return '<button class="card card--hover text-center" type="button" data-tipo="' + t.id + '" ' +
        'style="cursor:pointer;font-family:inherit;text-align:center;width:100%;border:1px solid var(--borda)">' +
        '<div class="icone-circulo ' + (t.cor || '') + '" style="margin:0 auto 12px"><i class="fa-solid ' + t.icone + '" aria-hidden="true"></i></div>' +
        '<strong style="display:block;font-size:.95rem;color:var(--texto)">' + t.nome + '</strong>' +
        '<span class="pequeno muted" style="display:block;margin-top:4px">' + n + ' exercícios</span>' +
      '</button>';
    }).join('');
  }

  function renderStats() {
    var total = todosExercicios().length;
    var u = window.EF.store.utilizador();
    var testes = (u && u.testes) || [];
    document.getElementById('statTotal').textContent = total;
    document.getElementById('statTestes').textContent = testes.length;
    var melhor = testes.length ? Math.max.apply(null, testes.map(function (t) {
      return t.total ? Math.round((t.acertos / t.total) * 100) : 0;
    })) : null;
    document.getElementById('statMelhor').textContent = melhor === null ? '—' : melhor + '%';
  }

  function abrirPratica(tipo, nivel) {
    tipoAtual = tipo;
    nivelAtual = nivel || nivelAtual || 'todos';
    var info = tipos.filter(function (t) { return t.id === tipo; })[0];
    var lista = embaralhar(filtrar(tipo, nivelAtual)).slice(0, 8);

    var titulo = document.getElementById('tituloPratica');
    var sub = document.getElementById('subtituloPratica');
    if (titulo) titulo.textContent = info ? info.nome : 'Prática livre';
    if (sub) sub.textContent = info ? info.desc : '';

    var alvo = document.getElementById('areaPratica');
    if (!lista.length) {
      alvo.innerHTML = '<div class="vazio"><div class="vazio__ico">🔍</div><p>Sem exercícios deste tipo neste nível. Tenta «Todos os níveis».</p></div>';
      document.getElementById('pratica').scrollIntoView({ behavior: 'smooth' });
      return;
    } else {
      alvo.innerHTML = '';
      window.EF.exercicios.criarTeste(alvo, lista, {
        titulo: info ? info.nome : 'Prática',
        aoTerminar: function (res) {
          var u = window.EF.store.utilizador();
          if (u) {
            window.EF.store.registarTeste({ tipo: tipo, acertos: res.acertos, total: res.total, data: Date.now() });
            window.EF.store.adicionarPontos(Math.round(res.pct / 10));
            window.EF.store.marcarDia();
            window.EF.store.enviarParaRanking();
            renderStats();
            renderHistorico();
          }
        }
      });
    }
    document.getElementById('pratica').scrollIntoView({ behavior: 'smooth' });
  }

  function abrirDesafio() {
    var dia = Math.floor(Date.now() / 86400000);
    var desafio = (window.EF.desafios || [])[dia % (window.EF.desafios || []).length];
    var todas = todosExercicios();
    var selecao = embaralhar(todas).slice(0, 5);
    var alvo = document.getElementById('areaPratica');
    document.getElementById('tituloPratica').textContent = 'Desafio do dia: ' + (desafio ? desafio.titulo : 'prática rápida');
    document.getElementById('subtituloPratica').textContent = '5 exercícios mistos · +' + (desafio ? desafio.pontos : 10) + ' pontos ao concluir';

    alvo.innerHTML = '';
    window.EF.exercicios.criarTeste(alvo, selecao, {
      titulo: 'Desafio do dia',
      aoTerminar: function (res) {
        var u = window.EF.store.utilizador();
        if (!u) {
          window.EF.ui.toast('Cria conta para guardar pontos do desafio.', 'info');
          return;
        }
        var bonus = res.pct >= 60 ? (desafio ? desafio.pontos : 10) : 5;
        window.EF.store.adicionarPontos(bonus);
        window.EF.store.registarTeste({ tipo: 'desafio', acertos: res.acertos, total: res.total, data: Date.now() });
        window.EF.store.marcarDia();
        window.EF.store.enviarParaRanking();
        var novas = window.EF.store.avaliarMedalhas(window.EF.store.utilizador());
        window.EF.ui.toast('Desafio concluído! +' + bonus + ' pontos', 'ok');
        (novas || []).forEach(function (m) {
          var meta = window.EF.medalhas.filter(function (x) { return x.id === m; })[0];
          if (meta) setTimeout(function () { window.EF.ui.toast('Medalha: ' + meta.nome + ' ' + meta.icone, 'ok'); }, 600);
        });
        renderStats();
        renderHistorico();
      }
    });
    document.getElementById('pratica').scrollIntoView({ behavior: 'smooth' });
  }

  /* Mini-teste semanal: 10 perguntas determinísticas por semana */
  function semanaAtual() {
    var agora = new Date();
    var inicio = new Date(agora.getFullYear(), 0, 1);
    var dias = Math.floor((agora - inicio) / 86400000);
    return Math.floor(dias / 7) + '-' + agora.getFullYear();
  }

  function perguntasSemanais() {
    var todas = todosExercicios();
    var semana = semanaAtual();
    var semente = 0;
    for (var i = 0; i < semana.length; i++) semente = (semente * 31 + semana.charCodeAt(i)) >>> 0;
    var usados = {};
    var selecao = [];
    var passos = 0;
    while (selecao.length < 10 && passos < 400) {
      semente = (semente * 1103515245 + 12345) >>> 0;
      var idx = semente % todas.length;
      passos++;
      if (usados[idx]) continue;
      usados[idx] = true;
      selecao.push(todas[idx]);
    }
    return selecao;
  }

  function abrirSemanal() {
    var selecao = perguntasSemanais();
    document.getElementById('tituloPratica').textContent = 'Mini-teste semanal';
    document.getElementById('subtituloPratica').textContent = '10 perguntas de níveis mistos · semana ' + semanaAtual();
    var alvo = document.getElementById('areaPratica');
    alvo.innerHTML = '';
    window.EF.exercicios.criarTeste(alvo, selecao, {
      titulo: 'Mini-teste semanal',
      aoTerminar: function (res) {
        var u = window.EF.store.utilizador();
        if (u) {
          window.EF.store.registarTeste({ tipo: 'semanal-' + semanaAtual(), acertos: res.acertos, total: res.total, data: Date.now() });
          window.EF.store.adicionarPontos(30);
          window.EF.store.marcarDia();
          window.EF.store.enviarParaRanking();
          window.EF.ui.toast('Mini-teste registado! +30 pontos', 'ok');
          renderStats();
          renderHistorico();
          renderHistoricoSemanal();
        } else {
          window.EF.ui.toast('Cria conta para guardar o resultado semanal.', 'info');
        }
      }
    });
    document.getElementById('pratica').scrollIntoView({ behavior: 'smooth' });
  }

  function renderDesafio() {
    var dia = Math.floor(Date.now() / 86400000);
    var d = (window.EF.desafios || [])[dia % (window.EF.desafios || []).length];
    var alvo = document.getElementById('desafioConteudo');
    if (!alvo || !d) return;
    var u = window.EF.store.utilizador();
    var feitoHoje = u && (u.dias || []).indexOf(window.EF.store.hojeISO()) !== -1;
    alvo.innerHTML = '<div class="destaque"><strong>' + esc(d.titulo) + '</strong><br><span class="pequeno">' + esc(d.desc) + '</span></div>' +
      (feitoHoje ? '<span class="badge badge--verde mb-10"><i class="fa-solid fa-check"></i> Já estudaste hoje</span>' : '') +
      '<button class="btn btn--amarelo btn--bloco" type="button" id="btnFazerDesafio">Fazer o desafio <i class="fa-solid fa-arrow-right" aria-hidden="true"></i></button>';
    var btn = alvo.querySelector('#btnFazerDesafio');
    if (btn) btn.addEventListener('click', abrirDesafio);
  }

  function renderHistorico() {
    var alvo = document.getElementById('historicoTestes');
    if (!alvo) return;
    var u = window.EF.store.utilizador();
    if (!u) {
      alvo.innerHTML = '<div class="vazio"><div class="vazio__ico">🔒</div><p class="pequeno">Entra na tua conta para guardar e consultar o histórico.</p>' +
        '<button class="btn btn--pequeno" type="button" data-abrir-login>Entrar / Criar conta</button></div>';
      return;
    }
    var testes = (u.testes || []).slice().reverse().slice(0, 12);
    if (!testes.length) {
      alvo.innerHTML = '<div class="vazio"><div class="vazio__ico">📝</div><p class="pequeno">Ainda não fizeste testes. Começa por um dos tipos acima.</p></div>';
      return;
    }
    alvo.innerHTML = '<div style="overflow-x:auto"><table class="tabela"><caption class="sr-only">Histórico de testes</caption>' +
      '<thead><tr><th scope="col">Data</th><th scope="col">Tipo</th><th scope="col">Resultado</th><th scope="col">%</th></tr></thead><tbody>' +
      testes.map(function (t) {
        var pct = t.total ? Math.round((t.acertos / t.total) * 100) : 0;
        var d = t.data ? new Date(t.data) : new Date();
        var cor = pct >= 80 ? 'verde' : pct >= 50 ? 'amarelo' : '';
        return '<tr><td>' + d.toLocaleDateString('pt-PT') + '</td>' +
          '<td>' + esc(String(t.tipo || 'teste').replace(/-/g, ' ')) + '</td>' +
          '<td>' + t.acertos + '/' + t.total + '</td>' +
          '<td class="' + cor + '"><strong>' + pct + '%</strong></td></tr>';
      }).join('') + '</tbody></table></div>';
  }

  function renderHistoricoSemanal() {
    var alvo = document.getElementById('historicoSemanal');
    if (!alvo) return;
    var u = window.EF.store.utilizador();
    var testes = ((u && u.testes) || []).filter(function (t) { return String(t.tipo || '').indexOf('semanal') === 0; });
    if (!testes.length) {
      alvo.innerHTML = '<p class="pequeno muted mb-0">Sem testes semanais registados ainda.</p>';
      return;
    }
    alvo.innerHTML = '<strong class="pequeno">Últimos testes semanais</strong>' +
      testes.slice(-3).reverse().map(function (t) {
        var pct = t.total ? Math.round((t.acertos / t.total) * 100) : 0;
        return '<div class="flex-entre pequeno" style="padding:6px 0;border-bottom:1px solid var(--borda)">' +
          '<span class="muted">' + esc(String(t.tipo).replace('semanal-', 'semana ')) + '</span>' +
          '<strong>' + t.acertos + '/' + t.total + ' · ' + pct + '%</strong></div>';
      }).join('');
  }

  document.addEventListener('DOMContentLoaded', function () {
    window.EF.ui.iniciar('exercicios');
    renderTipos();
    renderStats();
    renderDesafio();
    renderHistorico();
    renderHistoricoSemanal();

    document.addEventListener('click', function (e) {
      var t = e.target.closest('[data-tipo]');
      if (t) { abrirPratica(t.getAttribute('data-tipo'), nivelAtual); return; }
    });

    var sel = document.getElementById('filtroNivelEx');
    if (sel) {
      sel.addEventListener('change', function () {
        nivelAtual = sel.value;
        renderTipos();
        if (tipoAtual) abrirPratica(tipoAtual, nivelAtual);
      });
    }

    ['btnDesafioTopo', 'btnDesafioCentro'].forEach(function (id) {
      var b = document.getElementById(id);
      if (b) b.addEventListener('click', abrirDesafio);
    });
    ['btnSemanal', 'btnSemanalTopo'].forEach(function (id) {
      var b = document.getElementById(id);
      if (b) b.addEventListener('click', abrirSemanal);
    });

    var params = new URLSearchParams(window.location.search);
    if (params.get('tipo')) abrirPratica(params.get('tipo'), nivelAtual);
    if (params.get('desafio')) abrirDesafio();
  });
})();
