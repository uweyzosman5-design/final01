/* ============================================================
   Página de cursos e níveis
   ============================================================ */
(function () {
  'use strict';

  function esc(s) { return window.EF.ui.esc(s); }
  var filtroAtual = 'todos';
  var busca = '';

  function aulasFiltradas() {
    return (window.EF.licoes || []).filter(function (l) {
      var okNivel = filtroAtual === 'todos' || l.nivel === filtroAtual;
      var okBusca = !busca || (l.titulo + ' ' + l.resumo).toLowerCase().indexOf(busca) !== -1;
      return okNivel && okBusca;
    });
  }

  function renderFiltros() {
    var alvo = document.getElementById('filtrosNivel');
    if (!alvo) return;
    alvo.innerHTML = window.EF.niveis.map(function (n) {
      return '<button class="btn btn--pequeno btn--ghost filtro-nivel" type="button" data-filtro="' + n.id + '">' +
        n.icone + ' ' + esc(n.nome) + ' <span class="muted" style="font-weight:600">' + n.cefr + '</span></button>';
    }).join('');
  }

  function renderCartoesNivel() {
    var alvo = document.getElementById('cartoesNivel');
    if (!alvo) return;
    alvo.innerHTML = window.EF.niveis.map(function (n) {
      var p = window.EF.store.progressoNivel(n.id);
      return '<article class="card reveal" id="nivel-' + n.id + '">' +
        '<div class="flex-entre mb-10 wrap gap-10">' +
          '<div class="flex-centro gap-10">' +
            '<div class="icone-circulo" style="background:' + n.corHex + '22;color:' + n.corHex + ';margin:0">' + n.icone + '</div>' +
            '<div><h3 class="mb-0" style="font-size:1.16rem">' + esc(n.nome) + '</h3>' +
            '<span class="pequeno muted">Nível ' + n.cefr + ' · ' + p.total + ' aulas</span></div>' +
          '</div>' +
          '<span class="badge' + (p.pct === 100 ? ' badge--verde' : '') + '">' + (p.pct === 100 ? '✓ Concluído' : p.pct + '%') + '</span>' +
        '</div>' +
        '<p class="pequeno">' + esc(n.descricao) + '</p>' +
        '<ul style="columns:2;column-gap:20px;font-size:.84rem" class="pequeno">' +
          n.pontos.map(function (pp) { return '<li>' + esc(pp) + '</li>'; }).join('') +
        '</ul>' +
        '<div class="barra-progresso mb-20"><span style="width:' + Math.max(1, p.pct) + '%;background:' + n.corHex + '"></span></div>' +
        '<div class="flex gap-10 wrap">' +
          '<button class="btn btn--pequeno" type="button" data-ir-nivel="' + n.id + '">Ver aulas <i class="fa-solid fa-arrow-down" aria-hidden="true"></i></button>' +
          (p.pct === 100 ? '<a class="btn btn--pequeno btn--amarelo" href="#certificados">Ver certificado</a>' : '') +
        '</div>' +
      '</article>';
    }).join('');
  }

  function renderLista() {
    var alvo = document.getElementById('listaAulas');
    if (!alvo) return;
    var u = window.EF.store.utilizador();
    var lista = aulasFiltradas();

    var nivelInfo = window.EF.niveis.filter(function (n) { return n.id === filtroAtual; })[0];
    var titulo = document.getElementById('tituloLista');
    var sub = document.getElementById('subtituloLista');
    if (titulo) titulo.textContent = nivelInfo ? (nivelInfo.icone + ' ' + nivelInfo.nome + ' — ' + nivelInfo.cefr) : 'Todas as aulas';
    if (sub) {
      var p = filtroAtual === 'todos' ? window.EF.store.progressoGeral() : window.EF.store.progressoNivel(filtroAtual);
      sub.textContent = lista.length + ' aula' + (lista.length === 1 ? '' : 's') + ' · ' + p.feitas + ' de ' + p.total + ' concluídas';
    }

    if (!lista.length) {
      alvo.innerHTML = '<div class="vazio"><div class="vazio__ico">🔍</div><p>Nenhuma aula corresponde à tua pesquisa.</p>' +
        '<button class="btn btn--pequeno btn--ghost" type="button" data-limpar-busca>Limpar pesquisa</button></div>';
      return;
    }

    alvo.innerHTML = lista.map(function (l) {
      var feita = window.EF.store.licaoConcluida(u, l.id);
      var reg = u && u.licoes ? u.licoes[l.id] : null;
      var nivel = window.EF.niveis.filter(function (n) { return n.id === l.nivel; })[0] || { cefr: '', corHex: '#2563eb' };
      return '<a class="aula-item' + (feita ? ' aula-item--feita' : '') + '" href="aula.html?id=' + l.id + '" data-nivel-item="' + l.nivel + '">' +
        '<span class="aula-item__num" aria-hidden="true">' + (feita ? '<i class="fa-solid fa-check"></i>' : l.ordem) + '</span>' +
        '<span class="aula-item__corpo">' +
          '<span class="aula-item__titulo">' + l.icone + ' ' + esc(l.titulo) + '</span>' +
          '<span class="aula-item__meta">' +
            '<span><i class="fa-regular fa-clock" aria-hidden="true"></i> ' + l.min + ' min</span>' +
            '<span><i class="fa-solid fa-list-check" aria-hidden="true"></i> ' + l.exercicios.length + ' exercícios</span>' +
            '<span style="color:' + nivel.corHex + ';font-weight:700">' + esc(nivel.cefr) + '</span>' +
            (reg && reg.melhor ? '<span><i class="fa-solid fa-star amarelo" aria-hidden="true"></i> ' + reg.melhor + '%</span>' : '') +
          '</span>' +
        '</span>' +
        '<i class="fa-solid fa-chevron-right muted" aria-hidden="true"></i>' +
      '</a>';
    }).join('');
  }

  function renderCertificados() {
    var alvo = document.getElementById('certificados');
    if (!alvo) return;
    var u = window.EF.store.utilizador();
    alvo.innerHTML = ['iniciante', 'intermediario', 'avancado'].map(function (id) {
      var n = window.EF.niveis.filter(function (x) { return x.id === id; })[0];
      var p = window.EF.store.progressoNivel(id);
      var completo = p.pct === 100;
      return '<article class="card text-center">' +
        '<div style="font-size:2.2rem" aria-hidden="true">' + (completo ? '📜' : '🔒') + '</div>' +
        '<h3 style="font-size:1.06rem">Certificado ' + esc(n.nome) + '</h3>' +
        '<p class="pequeno muted">' + p.feitas + ' de ' + p.total + ' aulas concluídas</p>' +
        '<div class="barra-progresso mb-20"><span style="width:' + Math.max(1, p.pct) + '%;background:' + n.corHex + '"></span></div>' +
        (completo
          ? '<a class="btn btn--pequeno btn--amarelo btn--bloco" href="certificado.html?nivel=' + id + '">Ver certificado</a>'
          : '<span class="btn btn--pequeno btn--ghost btn--bloco" style="opacity:.6;cursor:not-allowed" aria-disabled="true">Faltam ' + (p.total - p.feitas) + ' aulas</span>') +
      '</article>';
    }).join('');
  }

  /* ---------- Mini-teste de nível ---------- */
  var perguntasNivel = [
    { perg: 'Completa: «___ name is Maria.»', opcoes: ['I', 'My', 'Me'], correta: 1, peso: 1 },
    { perg: 'Completa: «She ___ to school every day.»', opcoes: ['go', 'goes', 'going'], correta: 1, peso: 2 },
    { perg: 'O que significa «I have never been to London»?', opcoes: ['Nunca estive em Londres.', 'Vou a Londres amanhã.', 'Estive em Londres ontem.'], correta: 0, peso: 2 },
    { perg: 'Completa: «If it rains, we ___ at home.»', opcoes: ['stay will', 'will stay', 'staying'], correta: 1, peso: 3 },
    { perg: 'Transforma na passiva: «They built the school in 1990.»', opcoes: ['The school was built in 1990.', 'The school is building in 1990.', 'The school built them in 1990.'], correta: 0, peso: 3 },
    { perg: 'Escolhe a opção mais natural em contexto profissional:', opcoes: ['Send me the file now.', 'Would you be able to send me the file?', 'I need that file.'], correta: 1, peso: 3 }
  ];

  function iniciarTeste() {
    var alvo = document.getElementById('testeNivel');
    var indice = 0, pontos = 0, maxPontos = 0;
    perguntasNivel.forEach(function (p) { maxPontos += p.peso; });

    function mostrar() {
      if (indice >= perguntasNivel.length) { resultado(); return; }
      var p = perguntasNivel[indice];
      alvo.innerHTML = '<div class="flex-entre mb-10 pequeno muted"><span>Pergunta ' + (indice + 1) + ' de ' + perguntasNivel.length + '</span>' +
        '<span>' + pontos + ' pontos</span></div>' +
        '<div class="barra-progresso mb-20"><span style="width:' + Math.round((indice / perguntasNivel.length) * 100) + '%"></span></div>' +
        '<h3 style="font-size:1.06rem">' + esc(p.perg) + '</h3>' +
        '<div class="opcoes">' + p.opcoes.map(function (o, i) {
          return '<button class="opcao" type="button" data-op="' + i + '"><span class="opcao__letra">' + ['A', 'B', 'C', 'D'][i] + '</span><span>' + esc(o) + '</span></button>';
        }).join('') + '</div>';

      alvo.querySelectorAll('[data-op]').forEach(function (b) {
        b.addEventListener('click', function () {
          var escolha = parseInt(b.getAttribute('data-op'), 10);
          var certa = escolha === p.correta;
          alvo.querySelectorAll('[data-op]').forEach(function (x) {
            var i = parseInt(x.getAttribute('data-op'), 10);
            x.disabled = true;
            if (i === p.correta) x.classList.add('correta');
            if (i === escolha && !certa) x.classList.add('errada');
          });
          if (certa) pontos += p.peso;
          indice++;
          setTimeout(mostrar, 750);
        });
      });
    }

    function resultado() {
      var pct = Math.round((pontos / maxPontos) * 100);
      var nivel = pct >= 75 ? 'avancado' : pct >= 45 ? 'intermediario' : 'iniciante';
      var n = window.EF.niveis.filter(function (x) { return x.id === nivel; })[0];
      var primeira = (window.EF.licoes || []).filter(function (l) { return l.nivel === nivel; })[0];
      var u = window.EF.store.utilizador();
      if (u) window.EF.store.atualizarNivel(nivel);

      alvo.innerHTML = '<div class="text-center">' +
        '<div style="font-size:2.6rem" aria-hidden="true">' + n.icone + '</div>' +
        '<h3>O teu nível sugerido: ' + esc(n.nome) + ' (' + n.cefr + ')</h3>' +
        '<p class="pequeno">Acertaste ' + pontos + ' de ' + maxPontos + ' pontos (' + pct + '%).</p>' +
        '<div class="destaque" style="text-align:left">' + esc(n.descricao) + '</div>' +
        (u ? '' : '<p class="pequeno muted">Cria conta para guardar este nível no teu perfil.</p>') +
        '<div class="flex gap-10 mt-20" style="justify-content:center;flex-wrap:wrap">' +
          (primeira ? '<a class="btn" href="aula.html?id=' + primeira.id + '">Começar em «' + esc(primeira.titulo) + '»</a>' : '') +
          (u ? '' : '<button class="btn btn--amarelo" type="button" data-guardar-nivel>Guardar o meu nível</button>') +
          '<button class="btn btn--ghost" type="button" id="repetirTesteNivel">Repetir</button>' +
        '</div></div>';

      var guardar = alvo.querySelector('[data-guardar-nivel]');
      if (guardar) {
        guardar.addEventListener('click', function () {
          sessionStorage.setItem('ef:nivel-sugerido', nivel);
          window.EF.ui.abrirLogin('registo');
          setTimeout(function () {
            var sel = document.getElementById('authNivel');
            if (sel) sel.value = nivel;
          }, 120);
        });
      }
      var repetir = alvo.querySelector('#repetirTesteNivel');
      if (repetir) repetir.addEventListener('click', function () { indice = 0; pontos = 0; mostrar(); });
    }

    mostrar();
  }

  document.addEventListener('DOMContentLoaded', function () {
    window.EF.ui.iniciar('cursos');
    renderFiltros();
    renderCartoesNivel();
    renderLista();
    renderCertificados();

    var params = new URLSearchParams(window.location.search);
    var nivelParam = params.get('nivel');
    if (nivelParam && window.EF.niveis.some(function (n) { return n.id === nivelParam; })) {
      filtroAtual = nivelParam;
      document.querySelectorAll('.filtro-nivel').forEach(function (b) {
        b.classList.toggle('ativo', b.getAttribute('data-filtro') === nivelParam);
      });
    }

    document.addEventListener('click', function (e) {
      var f = e.target.closest('.filtro-nivel');
      if (f) {
        filtroAtual = f.getAttribute('data-filtro');
        document.querySelectorAll('.filtro-nivel').forEach(function (b) {
          b.classList.toggle('ativo', b === f);
        });
        renderLista();
        var alvo = document.getElementById('lista-aulas');
        if (alvo) alvo.scrollIntoView({ behavior: 'smooth', block: 'start' });
        return;
      }
      var ir = e.target.closest('[data-ir-nivel]');
      if (ir) {
        filtroAtual = ir.getAttribute('data-ir-nivel');
        document.querySelectorAll('.filtro-nivel').forEach(function (b) {
          b.classList.toggle('ativo', b.getAttribute('data-filtro') === filtroAtual);
        });
        renderLista();
        document.getElementById('lista-aulas').scrollIntoView({ behavior: 'smooth' });
        return;
      }
      if (e.target.closest('[data-limpar-busca]')) {
        busca = '';
        var inp = document.getElementById('buscaAula');
        if (inp) inp.value = '';
        renderLista();
      }
    });

    var inp = document.getElementById('buscaAula');
    if (inp) {
      inp.addEventListener('input', function () {
        busca = inp.value.trim().toLowerCase();
        renderLista();
      });
    }

    var btnTeste = document.getElementById('iniciarTesteNivel');
    if (btnTeste) btnTeste.addEventListener('click', iniciarTeste);
  });
})();
