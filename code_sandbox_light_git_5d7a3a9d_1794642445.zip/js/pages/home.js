/* ============================================================
   Página inicial
   ============================================================ */
(function () {
  'use strict';

  function esc(s) { return window.EF.ui.esc(s); }

  var faq = [
    { q: 'Preciso de saber alguma coisa de inglês para começar?', a: 'Não. O nível Iniciante começa pela letra A e pelo verbo mais básico. Se souberes dizer «hello», já estás à frente.' },
    { q: 'O curso é mesmo gratuito?', a: 'Sim. Todas as 26 aulas, exercícios, dicionário e o professor virtual estão disponíveis sem pagamento.' },
    { q: 'Funciona no telemóvel?', a: 'Sim, foi desenhado primeiro para telemóvel. Funciona em telemóveis, tablets e computadores, com modo escuro.' },
    { q: 'Onde fica guardado o meu progresso?', a: 'A conta e o progresso ficam guardados no teu dispositivo (navegador), protegidos por palavra-passe com hash. O ranking é partilhado entre alunos.' },
    { q: 'O professor virtual é uma pessoa?', a: 'É um tutor automático que responde a partir de uma base de conhecimento de inglês. Dá explicações, exemplos e correções de gramática — mas não substitui um professor humano em casos muito específicos.' },
    { q: 'Quanto tempo demora a ficar fluente?', a: 'Com 15 a 20 minutos por dia, a maioria dos alunos conclui o A1–A2 em 3 a 4 meses. A fluência conversacional chega entre 12 e 18 meses de prática consistente.' },
    { q: 'Qual é a diferença entre português de Moçambique, Portugal e Brasil?', a: 'As explicações usam português neutro e incluem exemplos e notas das três variantes. Onde há diferença relevante (por exemplo «telemóvel/celular»), indicamos as duas formas.' }
  ];

  function renderFaq() {
    var alvo = document.getElementById('listaFaq');
    if (!alvo) return;
    alvo.innerHTML = faq.map(function (f, i) {
      return '<div class="card" style="padding:0;overflow:hidden">' +
        '<button class="flex-entre" type="button" style="width:100%;background:none;border:0;padding:18px 20px;cursor:pointer;font-family:inherit;font-size:1rem;font-weight:700;color:var(--texto);text-align:left;gap:14px" ' +
          'aria-expanded="false" aria-controls="faq-' + i + '" data-faq="' + i + '">' +
          '<span>' + esc(f.q) + '</span>' +
          '<i class="fa-solid fa-chevron-down" aria-hidden="true" style="transition:transform .25s;flex-shrink:0;color:var(--muted)"></i>' +
        '</button>' +
        '<div id="faq-' + i + '" style="display:none;padding:0 20px 18px"><p class="mb-0 pequeno">' + esc(f.a) + '</p></div>' +
      '</div>';
    }).join('');

    alvo.addEventListener('click', function (e) {
      var btn = e.target.closest('[data-faq]');
      if (!btn) return;
      var i = btn.getAttribute('data-faq');
      var painel = document.getElementById('faq-' + i);
      var aberto = btn.getAttribute('aria-expanded') === 'true';
      btn.setAttribute('aria-expanded', aberto ? 'false' : 'true');
      painel.style.display = aberto ? 'none' : 'block';
      var ico = btn.querySelector('i');
      if (ico) ico.style.transform = aberto ? '' : 'rotate(180deg)';
    });
  }

  function renderNiveis() {
    var alvo = document.getElementById('grelhaNiveis');
    if (!alvo) return;
    alvo.innerHTML = window.EF.niveis.map(function (n) {
      var p = window.EF.store.progressoNivel(n.id);
      return '<a class="nivel nivel--' + n.cor + ' reveal" href="cursos.html?nivel=' + n.id + '" style="text-decoration:none">' +
        '<span class="nivel__tag">' + n.cefr + '</span>' +
        '<h3>' + n.icone + ' ' + esc(n.nome) + '</h3>' +
        '<p>' + esc(n.resumo) + '</p>' +
        '<div class="nivel__pe"><span>' + p.total + ' aulas</span>' +
        '<span><i class="fa-solid fa-circle-check" aria-hidden="true"></i> ' + p.feitas + '/' + p.total + '</span></div>' +
        '<div class="barra-progresso" style="background:rgba(255,255,255,.25)"><span style="width:' + p.pct + '%;background:#facc15"></span></div>' +
      '</a>';
    }).join('');
  }

  function renderAulasDestaque() {
    var alvo = document.getElementById('aulasDestaque');
    if (!alvo) return;
    var ids = ['a1-01', 'a1-03', 'b1-01', 'real-01'];
    var u = window.EF.store.utilizador();
    var html = ids.map(function (id) {
      var l = (window.EF.licoes || []).filter(function (x) { return x.id === id; })[0];
      if (!l) return '';
      var nivel = window.EF.niveis.filter(function (n) { return n.id === l.nivel; })[0] || { nome: l.nivel };
      var feita = window.EF.store.licaoConcluida(u, l.id);
      return '<article class="card card--hover reveal">' +
        '<div class="flex-entre mb-10">' +
          '<span class="badge badge--cinza">' + esc(nivel.cefr || nivel.nome) + '</span>' +
          (feita ? '<span class="badge badge--verde"><i class="fa-solid fa-check"></i> Concluída</span>' : '<span class="badge badge--amarelo">Grátis</span>') +
        '</div>' +
        '<h3 style="font-size:1.14rem">' + l.icone + ' ' + esc(l.titulo) + '</h3>' +
        '<p class="pequeno">' + esc(l.resumo) + '</p>' +
        '<div class="flex-centro gap-10 wrap mt-10">' +
          '<a class="btn btn--pequeno" href="aula.html?id=' + l.id + '">Abrir aula <i class="fa-solid fa-arrow-right" aria-hidden="true"></i></a>' +
          '<span class="pequeno muted"><i class="fa-regular fa-clock" aria-hidden="true"></i> ' + l.min + ' min · ' + l.exercicios.length + ' exercícios</span>' +
        '</div>' +
      '</article>';
    }).join('');

    if (u) {
      var prox = window.EF.store.proximaLicao();
      if (prox) {
        html = '<article class="card reveal" style="grid-column:1/-1;border-color:var(--azul-400);background:var(--azul-50)">' +
          '<div class="flex-entre wrap gap-14">' +
            '<div><span class="badge badge--amarelo mb-10">Continua de onde paraste</span>' +
            '<h3 class="mb-0" style="font-size:1.1rem">' + prox.icone + ' ' + esc(prox.titulo) + '</h3>' +
            '<p class="pequeno muted mb-0">' + esc(prox.resumo) + '</p></div>' +
            '<a class="btn" href="aula.html?id=' + prox.id + '">Continuar <i class="fa-solid fa-arrow-right" aria-hidden="true"></i></a>' +
          '</div></article>' + html;
      }
    }
    alvo.innerHTML = html;
  }

  function renderDemo() {
    var alvo = document.getElementById('demoExercicio');
    if (!alvo) return;
    window.EF.exercicios.render({
      tipo: 'escolha',
      perg: 'Completa a frase: «She ___ a doctor.»',
      opcoes: ['am', 'is', 'are'],
      correta: 1,
      explica: 'Com he / she / it usa-se «is». «She is a doctor» — ela é médica. O «am» é só para I, e «are» para you / we / they.'
    }, alvo, {});
  }

  function renderDoDia() {
    var dia = Math.floor(Date.now() / 86400000);

    var p = window.EF.palavrasDoDia[dia % window.EF.palavrasDoDia.length];
    var alvoP = document.getElementById('palavraDoDia');
    if (alvoP) {
      alvoP.innerHTML = '<span class="badge badge--amarelo mb-10"><i class="fa-solid fa-book"></i> Palavra do dia</span>' +
        '<div class="flex-centro gap-10 wrap"><h3 class="mb-0" style="color:var(--azul-600)">' + esc(p.en) + '</h3>' +
        '<button class="btn-audio" type="button" data-falar="' + esc(p.en) + '" aria-label="Ouvir ' + esc(p.en) + '"><i class="fa-solid fa-volume-high" aria-hidden="true"></i></button></div>' +
        '<p class="mb-0 mt-10">' + esc(p.pt) + ' <span class="pequeno muted">· ' + esc(p.classe) + '</span></p>' +
        '<p class="pequeno muted mb-0">Pronúncia: ' + esc(p.pron) + '</p>' +
        '<div class="destaque mb-0 mt-10"><em>' + esc(p.ex) + '</em><br><span class="pequeno">' + esc(p.exPt) + '</span></div>';
    }

    var f = window.EF.frasesDoDia[dia % window.EF.frasesDoDia.length];
    var alvoF = document.getElementById('fraseDoDia');
    if (alvoF) {
      alvoF.innerHTML = '<span class="badge mb-10"><i class="fa-solid fa-quote-left"></i> Frase do dia</span>' +
        '<div class="flex-centro gap-10"><h3 class="mb-0" style="color:var(--azul-600);font-size:1.1rem">' + esc(f.en) + '</h3>' +
        '<button class="btn-audio" type="button" data-falar="' + esc(f.en) + '" aria-label="Ouvir a frase"><i class="fa-solid fa-volume-high" aria-hidden="true"></i></button></div>' +
        '<p class="pequeno mb-0 mt-10">' + esc(f.pt) + '</p>' +
        '<a class="btn btn--pequeno btn--ghost mt-20" href="conversacao.html">Usar esta frase na conversa</a>';
    }

    var desafio = window.EF.desafios ? window.EF.desafios[dia % window.EF.desafios.length] : null;
    var alvoD = document.getElementById('desafioDoDia');
    if (alvoD) {
      var d = desafio || { titulo: 'Diz 3 frases em voz alta', desc: 'Apresenta-te em inglês: nome, cidade e profissão.', pontos: 10 };
      alvoD.innerHTML = '<span class="badge badge--amarelo mb-10"><i class="fa-solid fa-bolt"></i> Desafio do dia</span>' +
        '<h3 style="font-size:1.08rem">' + esc(d.titulo) + '</h3>' +
        '<p class="pequeno">' + esc(d.desc) + '</p>' +
        '<p class="pequeno muted"><i class="fa-solid fa-coins amarelo" aria-hidden="true"></i> +' + d.pontos + ' pontos ao concluir</p>' +
        '<a class="btn btn--pequeno btn--amarelo" href="exercicios.html?desafio=1">Aceitar desafio</a>';
    }
  }

  function carregarRanking() {
    var alvo = document.getElementById('rankingHome');
    var alvoSeq = document.getElementById('sequenciasRanking');
    if (!alvo) return;

    window.EF.store.lerRanking(100).then(function (linhas) {
      var u = window.EF.store.utilizador();
      var nomeLocal = u ? u.nome : null;

      /* Combina dados locais com o ranking partilhado */
      var mapa = {};
      linhas.forEach(function (l) {
        var chave = (l.nome || '').trim().toLowerCase();
        if (!chave) return;
        if (!mapa[chave] || (l.pontos || 0) > (mapa[chave].pontos || 0)) mapa[chave] = l;
      });
      if (u) {
        var k = u.nome.trim().toLowerCase();
        var local = { nome: u.nome, pontos: u.pontos || 0, licoes: window.EF.store.progressoGeral().feitas, sequencia: window.EF.store.sequencia(u), souEu: true };
        if (!mapa[k] || (mapa[k].pontos || 0) < local.pontos) mapa[k] = local;
      }
      var lista = Object.keys(mapa).map(function (k) { return mapa[k]; })
        .sort(function (a, b) { return (b.pontos || 0) - (a.pontos || 0); })
        .slice(0, 8);

      if (!lista.length) {
        alvo.innerHTML = '<div class="vazio"><div class="vazio__ico">🏁</div>' +
          '<p class="pequeno mb-10">Ainda não há alunos no ranking. Sê o primeiro!</p>' +
          '<a class="btn btn--pequeno" href="cursos.html">Fazer a primeira aula</a></div>';
      } else {
        alvo.innerHTML = '<table class="tabela"><caption class="sr-only">Ranking de alunos por pontos</caption><thead><tr>' +
          '<th scope="col">#</th><th scope="col">Aluno</th><th scope="col">Aulas</th><th scope="col">Pontos</th></tr></thead><tbody>' +
          lista.map(function (l, i) {
            var medalha = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : (i + 1);
            var eu = nomeLocal && (l.nome || '').trim().toLowerCase() === nomeLocal.trim().toLowerCase();
            return '<tr' + (eu ? ' style="background:var(--azul-50);font-weight:700"' : '') + '>' +
              '<td>' + medalha + '</td>' +
              '<td>' + esc(l.nome || 'Aluno') + (eu ? ' <span class="badge" style="font-size:.62rem">tu</span>' : '') + '</td>' +
              '<td>' + (l.licoes || 0) + '</td>' +
              '<td><strong>' + (l.pontos || 0) + '</strong></td></tr>';
          }).join('') + '</tbody></table>';
      }

      if (alvoSeq) {
        var top = linhas.slice().sort(function (a, b) { return (b.sequencia || 0) - (a.sequencia || 0); }).slice(0, 4);
        if (!top.length && u) top = [{ nome: u.nome, sequencia: window.EF.store.sequencia(u) }];
        alvoSeq.innerHTML = top.length ? top.map(function (l) {
          return '<div class="mini-stat"><div class="mini-stat__rot">' + esc(l.nome || 'Aluno') + '</div>' +
            '<div class="mini-stat__val" style="font-size:1.3rem"><i class="fa-solid fa-fire amarelo" aria-hidden="true"></i> ' + (l.sequencia || 0) + ' dias</div></div>';
        }).join('') : '<p class="pequeno muted">Ainda sem sequências registadas.</p>';
      }
    });
  }

  function renderProgressoNiveis() {
    var alvo = document.getElementById('progressoNiveis');
    if (!alvo) return;
    alvo.innerHTML = window.EF.niveis.map(function (n) {
      var p = window.EF.store.progressoNivel(n.id);
      return '<div class="mb-20"><div class="flex-entre pequeno mb-10"><span><strong>' + esc(n.nome) + '</strong> <span class="muted">' + n.cefr + '</span></span>' +
        '<span class="muted">' + p.pct + '%</span></div>' +
        '<div class="barra-progresso"><span style="width:' + Math.max(2, p.pct) + '%;background:' + n.corHex + '"></span></div></div>';
    }).join('');
  }

  function atualizarHero() {
    var u = window.EF.store.utilizador();
    var anel = document.querySelector('[data-anel-hero]');
    var txt = document.querySelector('[data-hero-progresso]');
    var sub = document.querySelector('[data-hero-progresso-sub]');
    if (!anel || !txt) return;
    var p = window.EF.store.progressoGeral();
    anel.style.setProperty('--p', p.pct);
    anel.setAttribute('data-label', p.pct + '%');
    if (u) {
      txt.textContent = 'Olá, ' + u.nome.split(' ')[0] + '! ' + p.feitas + ' de ' + p.total + ' aulas';
      sub.textContent = p.feitas ? 'Continua — estás a ' + p.pct + '% do curso completo' : 'A tua primeira aula está à espera';
      var btn = document.getElementById('btnComecar');
      if (btn) btn.setAttribute('href', 'cursos.html');
    }
  }

  /* ---------- Formulário de contacto ---------- */
  function ligarContacto() {
    var form = document.getElementById('formContacto');
    if (!form) return;

    form.addEventListener('submit', function (ev) {
      ev.preventDefault();
      var estado = document.getElementById('ctEstado');
      var botao = document.getElementById('ctEnviar');
      var nome = document.getElementById('ctNome').value.trim();
      var email = document.getElementById('ctEmail').value.trim();
      var assunto = document.getElementById('ctAssunto').value;
      var mensagem = document.getElementById('ctMensagem').value.trim();

      estado.classList.add('escondido');

      if (nome.length < 2) {
        estado.textContent = 'Escreve o teu nome.';
        estado.classList.remove('escondido');
        return;
      }
      if (!/^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(email)) {
        estado.textContent = 'Escreve um email válido.';
        estado.classList.remove('escondido');
        return;
      }
      if (mensagem.length < 10) {
        estado.textContent = 'A mensagem precisa de pelo menos 10 caracteres.';
        estado.classList.remove('escondido');
        return;
      }

      botao.disabled = true;
      botao.innerHTML = '<i class="fa-solid fa-spinner fa-spin" aria-hidden="true"></i> A enviar…';

      fetch('tables/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nome: nome, email: email, assunto: assunto, mensagem: mensagem })
      }).then(function (r) {
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return r.json();
      }).then(function () {
        form.reset();
        botao.disabled = false;
        botao.innerHTML = '<i class="fa-solid fa-paper-plane" aria-hidden="true"></i> Enviar mensagem';
        estado.className = 'feedback feedback--ok';
        estado.innerHTML = '<i class="fa-solid fa-circle-check" aria-hidden="true"></i><div><strong>Mensagem enviada!</strong><p>Obrigado, ' + esc(nome.split(' ')[0]) + '. Respondemos em breve.</p></div>';
        window.EF.ui.toast('Mensagem enviada. Obrigado!', 'ok');
      }).catch(function () {
        botao.disabled = false;
        botao.innerHTML = '<i class="fa-solid fa-paper-plane" aria-hidden="true"></i> Enviar mensagem';
        estado.className = 'feedback feedback--erro';
        estado.textContent = 'Não foi possível enviar agora. Tenta novamente em alguns instantes.';
      });
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    window.EF.ui.iniciar('inicio');
    renderNiveis();
    renderAulasDestaque();
    renderDemo();
    renderDoDia();
    renderFaq();
    renderProgressoNiveis();
    carregarRanking();
    atualizarHero();
    ligarContacto();

    var btn = document.getElementById('atualizarRanking');
    if (btn) {
      btn.addEventListener('click', function () {
        carregarRanking();
        window.EF.ui.toast('Ranking atualizado.', 'ok');
      });
    }

    /* Assinatura por email simples no CTA, se existir */
    document.querySelectorAll('[data-abrir-login]').forEach(function (b) {
      if (!b.getAttribute('data-aba')) b.setAttribute('data-aba', 'registo');
    });
  });
})();
