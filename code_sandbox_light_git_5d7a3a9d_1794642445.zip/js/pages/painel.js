/* ============================================================
   Página do painel do aluno
   ============================================================ */
(function () {
  'use strict';

  function esc(s) { return window.EF.ui.esc(s); }
  var u = null;

  function iniciais(nome) {
    return (nome || '?').split(' ').filter(Boolean).slice(0, 2).map(function (p) { return p[0].toUpperCase(); }).join('');
  }

  function renderCabecalho() {
    var saud = document.getElementById('saudacao');
    var sub = document.getElementById('subtituloPainel');
    var acoes = document.getElementById('acoesPainel');
    if (!u) {
      if (saud) saud.textContent = 'O meu progresso';
      if (sub) sub.textContent = 'Entra ou cria conta para começar a acompanhar tudo.';
      if (acoes) acoes.innerHTML = '<button class="btn btn--amarelo" type="button" data-abrir-login data-aba="registo">Criar conta grátis</button>';
      return;
    }
    var hora = new Date().getHours();
    var s = hora < 12 ? 'Bom dia' : hora < 19 ? 'Boa tarde' : 'Boa noite';
    if (saud) saud.textContent = s + ', ' + u.nome.split(' ')[0] + '!';
    var p = window.EF.store.progressoGeral();
    if (sub) sub.textContent = 'Já concluíste ' + p.feitas + ' de ' + p.total + ' aulas (' + p.pct + '% do curso completo).';
    var prox = window.EF.store.proximaLicao();
    if (acoes) {
      acoes.innerHTML =
        (prox ? '<a class="btn btn--amarelo" href="aula.html?id=' + prox.id + '"><i class="fa-solid fa-play" aria-hidden="true"></i> Continuar a aprender</a>' : '') +
        '<a class="btn btn--claro" href="exercicios.html"><i class="fa-solid fa-dumbbell" aria-hidden="true"></i> Praticar</a>';
    }
  }

  function renderStats() {
    var p = window.EF.store.progressoGeral();
    var nv = window.EF.store.pontosDoNivel(u.pontos || 0);
    document.getElementById('valPontos').textContent = (u.pontos || 0).toLocaleString('pt-PT');
    document.getElementById('valNivelPontos').textContent = nv.atual.icone + ' ' + nv.atual.nome +
      (nv.proximo ? ' · faltam ' + Math.max(0, (nv.proximo.min - (u.pontos || 0))) + ' pts para ' + nv.proximo.nome : ' · nível máximo');
    document.getElementById('valSequencia').textContent = window.EF.store.sequencia(u) + ' dias';
    document.getElementById('valSequenciaRec').textContent = 'Recorde: ' + window.EF.store.recordeSequencia(u) + ' dias';
    document.getElementById('valAulas').textContent = p.feitas;
    document.getElementById('valAulasTotal').textContent = 'de ' + p.total + ' aulas';
    document.getElementById('valMedalhas').textContent = (u.medalhas || []).length;
    document.getElementById('valMedalhasTotal').textContent = 'de ' + (window.EF.medalhas || []).length + ' possíveis';
  }

  function renderNiveis() {
    var alvo = document.getElementById('progressoNiveisPainel');
    if (!alvo) return;
    alvo.innerHTML = window.EF.niveis.map(function (n) {
      var p = window.EF.store.progressoNivel(n.id);
      return '<div class="mb-20"><div class="flex-entre pequeno mb-10">' +
        '<span><strong>' + n.icone + ' ' + esc(n.nome) + '</strong> <span class="muted">' + n.cefr + '</span></span>' +
        '<span class="muted">' + p.feitas + '/' + p.total + ' · ' + p.pct + '%</span></div>' +
        '<div class="barra-progresso"><span style="width:' + Math.max(1, p.pct) + '%;background:' + n.corHex + '"></span></div></div>';
    }).join('');
  }

  function renderProximas() {
    var alvo = document.getElementById('proximasAulas');
    if (!alvo) return;
    var licoes = (window.EF.licoes || []);
    var doNivel = licoes.filter(function (l) { return l.nivel === u.nivel; });
    var pendentes = (doNivel.length ? doNivel : licoes).filter(function (l) { return !window.EF.store.licaoConcluida(u, l.id); }).slice(0, 4);

    if (!pendentes.length) {
      alvo.innerHTML = '<div class="feedback feedback--ok"><i class="fa-solid fa-trophy" aria-hidden="true"></i>' +
        '<div><strong>Concluíste todas as aulas deste nível!</strong><p>Muda de nível ou revê as aulas com melhor pontuação.</p></div></div>' +
        '<a class="btn btn--pequeno mt-10" href="cursos.html">Escolher outro nível</a>';
      return;
    }
    alvo.innerHTML = pendentes.map(function (l) {
      var n = window.EF.niveis.filter(function (x) { return x.id === l.nivel; })[0];
      return '<a class="aula-item" href="aula.html?id=' + l.id + '">' +
        '<span class="aula-item__num">' + l.ordem + '</span>' +
        '<span class="aula-item__corpo">' +
          '<span class="aula-item__titulo">' + l.icone + ' ' + esc(l.titulo) + '</span>' +
          '<span class="aula-item__meta"><span>' + esc(n ? n.nome : '') + '</span><span>' + l.min + ' min</span><span>' + l.exercicios.length + ' exercícios</span></span>' +
        '</span><i class="fa-solid fa-play azul pequeno" aria-hidden="true"></i></a>';
    }).join('');
  }

  function renderConcluidas() {
    var alvo = document.getElementById('listaConcluidas');
    if (!alvo) return;
    var licoes = (window.EF.licoes || []).filter(function (l) {
      var r = u.licoes && u.licoes[l.id];
      return r && r.concluida;
    });
    if (!licoes.length) {
      alvo.innerHTML = '<div class="vazio" style="padding:24px"><div class="vazio__ico">📚</div><p class="pequeno mb-10">Ainda não concluíste nenhuma aula.</p>' +
        '<a class="btn btn--pequeno" href="cursos.html">Começar a primeira aula</a></div>';
      return;
    }
    alvo.innerHTML = licoes.map(function (l) {
      var r = u.licoes[l.id];
      return '<a class="aula-item aula-item--feita" href="aula.html?id=' + l.id + '">' +
        '<span class="aula-item__num"><i class="fa-solid fa-check"></i></span>' +
        '<span class="aula-item__corpo"><span class="aula-item__titulo">' + l.icone + ' ' + esc(l.titulo) + '</span>' +
          '<span class="aula-item__meta"><span>Melhor: ' + (r.melhor || 0) + '%</span><span>' + (r.tentativas || 1) + ' tentativa(s)</span>' +
          (r.data ? '<span>' + new Date(r.data).toLocaleDateString('pt-PT') + '</span>' : '') + '</span></span></a>';
    }).join('');
  }

  function renderFavoritos() {
    var alvo = document.getElementById('listaFavoritos');
    if (!alvo) return;
    var favs = u.favoritos || [];
    if (!favs.length) {
      alvo.innerHTML = '<p class="pequeno muted mb-10">Ainda não guardaste palavras. Toca na estrela em qualquer palavra das aulas ou do dicionário.</p>' +
        '<a class="btn btn--pequeno btn--ghost" href="dicionario.html">Ir ao dicionário</a>';
      return;
    }
    alvo.innerHTML = '<div class="flex wrap gap-10">' + favs.map(function (f) {
      var entrada = (window.EF.dicionario || []).filter(function (d) { return d.en === f; })[0];
      return '<span class="palavra-chip" style="display:inline-flex;align-items:center;gap:8px">' +
        esc(f) +
        '<button class="btn-audio" type="button" data-falar="' + esc(f) + '" style="width:22px;height:22px;font-size:.6rem;background:rgba(255,255,255,.25);color:inherit" aria-label="Ouvir ' + esc(f) + '">' +
        '<i class="fa-solid fa-volume-high" aria-hidden="true"></i></button>' +
        '<button class="btn-audio" type="button" data-remover-fav="' + esc(f) + '" style="width:22px;height:22px;font-size:.6rem;background:rgba(255,255,255,.25);color:inherit" aria-label="Remover ' + esc(f) + '">' +
        '<i class="fa-solid fa-xmark" aria-hidden="true"></i></button>' +
        (entrada ? '<small style="opacity:.65;font-weight:500">' + esc(entrada.pt) + '</small>' : '') +
      '</span>';
    }).join('') + '</div>';
  }

  function renderTestes() {
    var alvo = document.getElementById('listaTestesPainel');
    if (!alvo) return;
    var testes = (u.testes || []).slice().reverse().slice(0, 8);
    if (!testes.length) {
      alvo.innerHTML = '<p class="pequeno muted mb-0">Sem testes registados. Faz um mini-teste semanal para começar.</p>' +
        '<a class="btn btn--pequeno btn--ghost mt-10" href="exercicios.html">Ir aos exercícios</a>';
      return;
    }
    alvo.innerHTML = '<div style="overflow-x:auto"><table class="tabela"><thead><tr>' +
      '<th scope="col">Tipo</th><th scope="col">Resultado</th><th scope="col">Data</th></tr></thead><tbody>' +
      testes.map(function (t) {
        var pct = t.total ? Math.round((t.acertos / t.total) * 100) : 0;
        return '<tr><td>' + esc(String(t.tipo || 'teste').replace(/-/g, ' ')) + '</td>' +
          '<td><strong class="' + (pct >= 80 ? 'verde' : pct >= 50 ? 'amarelo' : '') + '">' + pct + '%</strong> (' + t.acertos + '/' + t.total + ')</td>' +
          '<td>' + (t.data ? new Date(t.data).toLocaleDateString('pt-PT') : '—') + '</td></tr>';
      }).join('') + '</tbody></table></div>';
  }

  function renderSequencia() {
    var alvo = document.getElementById('semanaDots');
    if (!alvo) return;
    var dias = window.EF.store.ultimosSete(u);
    alvo.innerHTML = dias.map(function (d) {
      return '<div class="dia-dot' + (d.feito ? ' feito' : '') + '" title="' + d.iso + '">' + d.letra + '</div>';
    }).join('');

    var seq = window.EF.store.sequencia(u);
    var msg = document.getElementById('mensagemSequencia');
    var hoje = window.EF.store.hojeISO();
    var estudouHoje = (u.dias || []).indexOf(hoje) !== -1;
    if (msg) {
      if (!seq && !estudouHoje) msg.innerHTML = '<strong>Começa hoje.</strong> Uma aula de 5 minutos já conta para a sequência.';
      else if (estudouHoje) msg.innerHTML = '<strong>' + seq + ' dia' + (seq === 1 ? '' : 's') + ' seguido' + (seq === 1 ? '' : 's') + '!</strong> Volta amanhã para manter a chama acesa 🔥';
      else msg.innerHTML = '<strong>Ainda não estudaste hoje.</strong> Uma aula curta mantém a tua sequência de ' + seq + ' dia(s).';
    }
  }

  function renderMedalhas() {
    var alvo = document.getElementById('grelhaMedalhas');
    if (!alvo) return;
    var ganhas = u.medalhas || [];
    document.getElementById('medalhasTexto').textContent = ganhas.length + ' de ' + (window.EF.medalhas || []).length;
    alvo.innerHTML = (window.EF.medalhas || []).map(function (m) {
      var ganha = ganhas.indexOf(m.id) !== -1;
      return '<div class="medalha' + (ganha ? ' ganha' : '') + '" title="' + esc(m.desc) + '">' +
        '<div class="medalha__ico">' + m.icone + '</div>' +
        '<div class="medalha__nome">' + esc(m.nome) + '</div></div>';
    }).join('');
  }

  function renderCertificados() {
    var alvo = document.getElementById('certificadosPainel');
    if (!alvo) return;
    alvo.innerHTML = ['iniciante', 'intermediario', 'avancado'].map(function (id) {
      var n = window.EF.niveis.filter(function (x) { return x.id === id; })[0];
      var p = window.EF.store.progressoNivel(id);
      var ok = p.pct === 100;
      return '<div class="flex-entre pequeno" style="padding:8px 0;border-bottom:1px solid var(--borda)">' +
        '<span>' + n.icone + ' ' + esc(n.nome) + '<br><span class="muted" style="font-size:.78rem">' + p.feitas + '/' + p.total + ' aulas</span></span>' +
        (ok ? '<a class="btn btn--pequeno btn--amarelo" href="certificado.html?nivel=' + id + '">Ver</a>'
            : '<span class="badge badge--cinza">' + p.pct + '%</span>') +
      '</div>';
    }).join('');
  }

  function carregarRanking() {
    var alvo = document.getElementById('rankingPainel');
    if (!alvo) return;
    alvo.innerHTML = '<p class="pequeno muted">A carregar…</p>';
    window.EF.store.lerRanking(100).then(function (linhas) {
      var mapa = {};
      linhas.forEach(function (l) {
        var k = (l.nome || '').trim().toLowerCase();
        if (!k) return;
        if (!mapa[k] || (l.pontos || 0) > (mapa[k].pontos || 0)) mapa[k] = l;
      });
      var meu = u.nome.trim().toLowerCase();
      var local = { nome: u.nome, pontos: u.pontos || 0, licoes: window.EF.store.progressoGeral().feitas, sequencia: window.EF.store.sequencia(u), eu: true };
      if (!mapa[meu] || (mapa[meu].pontos || 0) < local.pontos) mapa[meu] = local;
      var lista = Object.keys(mapa).map(function (k) { return mapa[k]; })
        .sort(function (a, b) { return (b.pontos || 0) - (a.pontos || 0); });
      var pos = lista.findIndex(function (l) { return (l.nome || '').trim().toLowerCase() === meu; });
      var top = lista.slice(0, 6);
      alvo.innerHTML = '<p class="pequeno mb-10">A tua posição: <strong>' + (pos >= 0 ? '#' + (pos + 1) : '—') + '</strong> de ' + lista.length + ' alunos</p>' +
        '<table class="tabela"><thead><tr><th scope="col">#</th><th scope="col">Aluno</th><th scope="col">Pontos</th></tr></thead><tbody>' +
        top.map(function (l, i) {
          var eu = (l.nome || '').trim().toLowerCase() === meu;
          return '<tr' + (eu ? ' style="background:var(--azul-50);font-weight:700"' : '') + '><td>' + (i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : i + 1) + '</td>' +
            '<td>' + esc(l.nome) + '</td><td>' + (l.pontos || 0) + '</td></tr>';
        }).join('') + '</tbody></table>';
    });
  }

  function renderDefinicoes() {
    var sel = document.getElementById('selNivelPerfil');
    if (sel) {
      sel.value = u.nivel || 'iniciante';
      sel.addEventListener('change', function () {
        window.EF.store.atualizarNivel(sel.value);
        u = window.EF.store.utilizador();
        window.EF.ui.toast('Nível atualizado.', 'ok');
        renderProximas();
      });
    }
    var voz = document.getElementById('selVoz');
    if (voz && window.EF.audio) {
      var vozes = window.EF.audio.vozes().filter(function (v) { return /^en/i.test(v.lang); });
      if (!vozes.length) {
        var dica = document.getElementById('dicaVoz');
        if (dica) dica.textContent = 'Nenhuma voz inglesa encontrada neste navegador. O áudio usará a voz padrão do sistema.';
      } else {
        voz.innerHTML = '<option value="">Automática (recomendado)</option>' + vozes.map(function (v) {
          return '<option value="' + esc(v.name) + '"' + (window.EF.store.carregar().config.voz === v.name ? ' selected' : '') + '>' +
            esc(v.name) + ' (' + esc(v.lang) + ')</option>';
        }).join('');
        voz.addEventListener('change', function () {
          window.EF.store.configurar('voz', voz.value || null);
          window.EF.audio.falar('Hello! This is my voice.');
          window.EF.ui.toast('Voz atualizada.', 'ok');
        });
      }
    }
    var btnNot = document.getElementById('btnNotificacoes');
    if (btnNot) {
      var ativo = window.EF.store.carregar().config.notificacoes;
      var txt = document.getElementById('txtNotificacoes');
      if (txt && ativo) txt.textContent = 'Desativar lembretes de estudo';
      btnNot.addEventListener('click', function () {
        window.EF.ui.pedirNotificacoes().then(function (ok) {
          var t = document.getElementById('txtNotificacoes');
          if (t) t.textContent = ok ? 'Desativar lembretes de estudo' : 'Ativar lembretes de estudo';
        });
      });
    }
    var btnTema = document.getElementById('btnTemaPainel');
    if (btnTema) btnTema.addEventListener('click', window.EF.ui.alternarTema);

    var btnExportar = document.getElementById('btnExportar');
    if (btnExportar) {
      btnExportar.addEventListener('click', function () {
        var dados = {
          exportadoEm: new Date().toISOString(),
          perfil: { nome: u.nome, email: u.email, nivel: u.nivel, pontos: u.pontos },
          licoes: u.licoes, medalhas: u.medalhas, favoritos: u.favoritos, testes: u.testes, dias: u.dias
        };
        var blob = new Blob([JSON.stringify(dados, null, 2)], { type: 'application/json' });
        var a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = 'englishfacil-progresso.json';
        a.click();
        URL.revokeObjectURL(a.href);
        window.EF.ui.toast('Progresso exportado.', 'ok');
      });
    }

    var btnSair = document.getElementById('btnSair');
    if (btnSair) {
      btnSair.addEventListener('click', function () {
        window.EF.store.sair();
        window.EF.ui.toast('Sessão terminada.', 'ok');
        setTimeout(function () { window.location.reload(); }, 400);
      });
    }

    var btnApagar = document.getElementById('btnApagarConta');
    if (btnApagar) {
      btnApagar.addEventListener('click', function () {
        window.EF.ui.abrirModal(
          '<h2>Apagar conta?</h2>' +
          '<p class="pequeno">Isto remove a tua conta <strong>' + esc(u.email) + '</strong> e todo o progresso guardado neste dispositivo. Não pode ser desfeito.</p>' +
          '<div class="flex gap-10 mt-20"><button class="btn btn--perigo" type="button" data-confirmar>Sim, apagar</button>' +
          '<button class="btn btn--ghost" type="button" data-fechar-modal>Cancelar</button></div>'
        );
        document.querySelector('[data-confirmar]').addEventListener('click', function () {
          window.EF.store.apagarConta();
          window.EF.ui.fecharModal();
          window.EF.ui.toast('Conta apagada deste dispositivo.', 'ok');
          setTimeout(function () { window.location.reload(); }, 500);
        });
      });
    }

    var btnTrocar = document.getElementById('btnTrocarNivel');
    if (btnTrocar) {
      btnTrocar.addEventListener('click', function () {
        var sel2 = document.getElementById('selNivelPerfil');
        if (sel2) { sel2.focus(); sel2.scrollIntoView({ behavior: 'smooth', block: 'center' }); }
      });
    }
  }

  document.addEventListener('DOMContentLoaded', function () {
    window.EF.ui.iniciar('painel');
    u = window.EF.store.utilizador();
    renderCabecalho();

    var semSessao = document.getElementById('estadoSemSessao');
    var painel = document.getElementById('conteudoPainel');

    if (!u) {
      if (semSessao) semSessao.hidden = false;
      if (painel) painel.hidden = true;
      return;
    }

    if (semSessao) semSessao.hidden = true;
    if (painel) painel.hidden = false;

    renderStats();
    renderNiveis();
    renderProximas();
    renderConcluidas();
    renderFavoritos();
    renderTestes();
    renderSequencia();
    renderMedalhas();
    renderCertificados();
    carregarRanking();
    renderDefinicoes();
    window.EF.store.enviarParaRanking();

    document.addEventListener('click', function (e) {
      var rem = e.target.closest('[data-remover-fav]');
      if (rem) {
        window.EF.store.alternarFavorito(rem.getAttribute('data-remover-fav'));
        u = window.EF.store.utilizador();
        renderFavoritos();
        window.EF.ui.toast('Palavra removida.', 'ok');
      }
    });

    var btnAt = document.getElementById('btnAtualizarRanking');
    if (btnAt) btnAt.addEventListener('click', function () { carregarRanking(); window.EF.ui.toast('Ranking atualizado.', 'ok'); });

    var btnEnviar = document.getElementById('btnEnviarRanking');
    if (btnEnviar) {
      btnEnviar.addEventListener('click', function () {
        window.EF.store.enviarParaRanking(true).then(function (r) {
          if (r) { window.EF.ui.toast('Pontuação publicada no ranking.', 'ok'); carregarRanking(); }
          else window.EF.ui.toast('Ranking indisponível neste momento. Tenta mais tarde.', 'erro');
        });
      });
    }
  });
})();
