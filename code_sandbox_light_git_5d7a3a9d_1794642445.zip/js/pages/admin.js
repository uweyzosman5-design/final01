/* ============================================================
   Painel administrativo
   ============================================================ */
(function () {
  'use strict';

  function esc(s) { return window.EF.ui.esc(s); }

  var CHAVE_ADMIN = 'englishfacil:admin:v1';
  var CRED_PADRAO = { email: 'admin@englishfacil.local', hash: null, senhaPlana: 'englishfacil' };
  var filtroNivel = 'todos';
  var buscaAula = '';
  var graficos = {};

  /* ---------- Autenticação de administrador ---------- */
  function hash(txt) {
    var h = 0x811c9dc5;
    for (var i = 0; i < txt.length; i++) {
      h = (h ^ txt.charCodeAt(i)) * 16777619 >>> 0;
    }
    return ('00000000' + h.toString(16)).slice(-8) + '-' + txt.length;
  }

  function credenciais() {
    try {
      var bruto = localStorage.getItem(CHAVE_ADMIN);
      if (bruto) {
        var c = JSON.parse(bruto);
        if (c && c.email && c.hash) return c;
      }
    } catch (e) {}
    return null;
  }

  function guardarCredenciais(email, senha) {
    localStorage.setItem(CHAVE_ADMIN, JSON.stringify({ email: email, hash: hash(senha) }));
  }

  function sessaoAdmin() {
    try { return sessionStorage.getItem('englishfacil:admin:sessao') === 'ativa'; } catch (e) { return false; }
  }

  function definirSessao(ativa) {
    try {
      if (ativa) sessionStorage.setItem('englishfacil:admin:sessao', 'ativa');
      else sessionStorage.removeItem('englishfacil:admin:sessao');
    } catch (e) {}
  }

  function validar(email, senha) {
    var c = credenciais();
    if (c) return String(email).trim().toLowerCase() === c.email.toLowerCase() && hash(senha) === c.hash;
    return String(email).trim().toLowerCase() === CRED_PADRAO.email && senha === CRED_PADRAO.senhaPlana;
  }

  /* ---------- Alternância de ecrãs ---------- */
  function mostrarAdmin() {
    document.getElementById('ecraAcesso').hidden = true;
    document.getElementById('adminTopo').hidden = false;
    document.getElementById('adminCorpo').hidden = false;
    renderTudo();
  }

  function mostrarAcesso() {
    document.getElementById('ecraAcesso').hidden = false;
    document.getElementById('adminTopo').hidden = true;
    document.getElementById('adminCorpo').hidden = true;
  }

  /* ---------- Lista de aulas ---------- */
  function aulasFiltradas() {
    return (window.EF.licoes || []).filter(function (l) {
      var okNivel = filtroNivel === 'todos' || l.nivel === filtroNivel;
      var okBusca = !buscaAula || (l.titulo + ' ' + l.resumo).toLowerCase().indexOf(buscaAula) !== -1;
      return okNivel && okBusca;
    });
  }

  function renderAulas() {
    var alvo = document.getElementById('admListaAulas');
    if (!alvo) return;
    var lista = aulasFiltradas();
    var r = window.EF.conteudo.resumoAlteracoes();
    var info = document.getElementById('admInfoAlteracoes');
    if (info) {
      info.textContent = r.editadas || r.criadas || r.removidas
        ? 'Alterações locais: ' + r.editadas + ' editada(s), ' + r.criadas + ' criada(s), ' + r.removidas + ' removida(s)'
        : 'Sem alterações locais — a mostrar o conteúdo original.';
    }

    if (!lista.length) {
      alvo.innerHTML = '<div class="vazio"><div class="vazio__ico">📚</div><p>Nenhuma aula corresponde ao filtro.</p></div>';
      return;
    }

    alvo.innerHTML = lista.map(function (l) {
      var n = window.EF.niveis.filter(function (x) { return x.id === l.nivel; })[0] || { nome: l.nivel, cefr: '', corHex: '#2563eb' };
      var editada = window.EF.conteudo.dados().editadas[l.id];
      return '<div class="card" style="padding:14px 16px">' +
        '<div class="flex-entre wrap gap-10">' +
          '<div class="flex-centro gap-10" style="min-width:0;flex:1">' +
            '<span class="aula-item__num" style="width:36px;height:36px;font-size:.82rem">' + l.ordem + '</span>' +
            '<div style="min-width:0">' +
              '<strong class="pequeno" style="display:block">' + l.icone + ' ' + esc(l.titulo) + '</strong>' +
              '<span class="pequeno muted">' + esc(n.nome) + ' · ' + n.cefr + ' · ' + l.min + ' min · ' + (l.exercicios || []).length + ' exercícios' +
                (l._personalizada ? ' · <span class="badge badge--amarelo" style="font-size:.6rem">personalizada</span>' : '') +
                (editada ? ' · <span class="badge" style="font-size:.6rem">editada</span>' : '') +
              '</span>' +
            '</div>' +
          '</div>' +
          '<div class="flex gap-6 wrap">' +
            '<a class="btn btn--pequeno btn--ghost" href="aula.html?id=' + l.id + '" target="_blank" rel="noopener">Ver</a>' +
            '<button class="btn btn--pequeno" type="button" data-editar="' + l.id + '">Editar</button>' +
            '<button class="btn btn--pequeno btn--ghost" type="button" data-mover="' + l.id + '" aria-label="Alterar ordem">↕</button>' +
            '<button class="btn btn--pequeno btn--perigo" type="button" data-remover="' + l.id + '" aria-label="Remover aula"><i class="fa-solid fa-trash" aria-hidden="true"></i></button>' +
          '</div>' +
        '</div>' +
      '</div>';
    }).join('');
  }

  /* ---------- Formulário de aula ---------- */
  function abrirEditorAula(id) {
    var licao = id ? (window.EF.licoes || []).filter(function (l) { return l.id === id; })[0] : null;
    var nova = !licao;
    var l = licao || {
      id: '', nivel: 'iniciante', ordem: 99, icone: '📘', min: 15, titulo: '', resumo: '',
      objetivos: [], explicacao: [], vocabulario: [], exercicios: [], dica: '', tabela: null
    };

    var html = '<h2>' + (nova ? 'Nova aula' : 'Editar aula') + '</h2>' +
      '<p class="pequeno muted">Os campos essenciais primeiro. Linhas vazias são ignoradas.</p>' +
      '<form id="formAula">' +
        '<div class="campo"><label for="fTitulo">Título da aula *</label>' +
          '<input id="fTitulo" value="' + esc(l.titulo) + '" required placeholder="Ex.: Cumprimentos e despedidas"></div>' +
        '<div class="campo"><label for="fResumo">Resumo curto</label>' +
          '<input id="fResumo" value="' + esc(l.resumo) + '" placeholder="Uma frase que explica o foco da aula"></div>' +
        '<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">' +
          '<div class="campo"><label for="fNivel">Nível *</label><select id="fNivel">' +
            window.EF.niveis.map(function (n) {
              return '<option value="' + n.id + '"' + (l.nivel === n.id ? ' selected' : '') + '>' + n.icone + ' ' + esc(n.nome) + ' (' + n.cefr + ')</option>';
            }).join('') +
          '</select></div>' +
          '<div class="campo"><label for="fOrdem">Ordem no nível</label>' +
            '<input id="fOrdem" type="number" min="1" value="' + (l.ordem || 1) + '"></div>' +
        '</div>' +
        '<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">' +
          '<div class="campo"><label for="fIcone">Emoji / ícone</label>' +
            '<input id="fIcone" value="' + esc(l.icone) + '" maxlength="4"></div>' +
          '<div class="campo"><label for="fMin">Duração (min)</label>' +
            '<input id="fMin" type="number" min="1" value="' + (l.min || 15) + '"></div>' +
        '</div>' +
        '<div class="campo"><label for="fObjetivos">Objetivos (um por linha)</label>' +
          '<textarea id="fObjetivos" placeholder="Dizer o alfabeto&#10;Soletrar o nome">' + esc((l.objetivos || []).join('\n')) + '</textarea></div>' +
        '<div class="campo"><label for="fExplicacao">Explicação em português — formato: Título :: Texto (um bloco por linha)</label>' +
          '<textarea id="fExplicacao" style="min-height:130px" placeholder="Porque começar pelo alfabeto? :: O a não é «a», é «ei»...">' +
          esc((l.explicacao || []).map(function (b) { return b.t + ' :: ' + b.p.replace(/<[^>]+>/g, ''); }).join('\n')) +
          '</textarea></div>' +
        '<div class="campo"><label for="fDica">Dica do professor</label>' +
          '<input id="fDica" value="' + esc(l.dica || '') + '" placeholder="Uma dica prática para o aluno"></div>' +
        '<div class="campo"><label for="fVocab">Vocabulário — formato: inglês | português | pronúncia | exemplo | tradução do exemplo (um por linha)</label>' +
          '<textarea id="fVocab" style="min-height:130px" placeholder="hello | olá | re-LÔU | Hello! My name is Ana. | Olá! O meu nome é Ana.">' +
          esc((l.vocabulario || []).map(function (v) {
            return [v.en, v.pt, v.pron, v.ex || '', v.exPt || ''].join(' | ');
          }).join('\n')) +
          '</textarea></div>' +
        '<div class="campo"><label for="fTabela">Tabela (opcional) — 1ª linha: título | colunas separadas por vírgula; restantes: valores</label>' +
          '<textarea id="fTabela" style="min-height:80px" placeholder="As letras mais traiçoeiras | Letra,Diz-se,Exemplo&#10;A,ei,apple">' +
          esc(l.tabela ? [l.tabela.titulo + ' | ' + l.tabela.cabecalho.join(',')].concat(l.tabela.linhas.map(function (x) { return x.join(','); })).join('\n') : '') +
          '</textarea></div>' +
        '<div id="erroAula" class="feedback feedback--erro escondido" role="alert"></div>' +
        '<div class="flex gap-10 mt-20" style="flex-wrap:wrap">' +
          '<button class="btn" type="submit">' + (nova ? 'Criar aula' : 'Guardar alterações') + '</button>' +
          '<button class="btn btn--ghost" type="button" data-fechar-modal>Cancelar</button>' +
        '</div>' +
      '</form>';

    window.EF.ui.abrirModal(html);

    document.getElementById('formAula').addEventListener('submit', function (ev) {
      ev.preventDefault();
      var erro = document.getElementById('erroAula');
      var titulo = document.getElementById('fTitulo').value.trim();
      if (titulo.length < 3) {
        erro.textContent = 'O título precisa de pelo menos 3 caracteres.';
        erro.classList.remove('escondido');
        return;
      }

      var objetivos = document.getElementById('fObjetivos').value.split('\n').map(function (s) { return s.trim(); }).filter(Boolean);
      var explicacao = document.getElementById('fExplicacao').value.split('\n').map(function (s) { return s.trim(); }).filter(Boolean).map(function (linha) {
        var partes = linha.split('::');
        return { t: (partes[0] || '').trim() || 'Explicação', p: (partes[1] || partes[0] || '').trim() };
      });
      var vocabulario = document.getElementById('fVocab').value.split('\n').map(function (s) { return s.trim(); }).filter(Boolean).map(function (linha) {
        var c = linha.split('|').map(function (x) { return x.trim(); });
        return { en: c[0] || '', pt: c[1] || '', pron: c[2] || '', ex: c[3] || '', exPt: c[4] || '' };
      }).filter(function (v) { return v.en && v.pt; });

      var tabelaTexto = document.getElementById('fTabela').value.trim();
      var tabela = null;
      if (tabelaTexto) {
        var linhas = tabelaTexto.split('\n').map(function (s) { return s.trim(); }).filter(Boolean);
        var cab = linhas[0].split('|').map(function (s) { return s.trim(); });
        var cabecalho = (cab[1] || '').split(',').map(function (s) { return s.trim(); }).filter(Boolean);
        var corpo = linhas.slice(1).map(function (linha) {
          return linha.split(',').map(function (s) { return s.trim(); });
        }).filter(function (x) { return x.length; });
        if (cabecalho.length) tabela = { titulo: cab[0] || 'Tabela', cabecalho: cabecalho, linhas: corpo };
      }

      var dados = {
        titulo: titulo,
        resumo: document.getElementById('fResumo').value.trim(),
        nivel: document.getElementById('fNivel').value,
        ordem: parseInt(document.getElementById('fOrdem').value, 10) || 99,
        icone: document.getElementById('fIcone').value.trim() || '📘',
        min: parseInt(document.getElementById('fMin').value, 10) || 15,
        objetivos: objetivos,
        explicacao: explicacao,
        vocabulario: vocabulario,
        dica: document.getElementById('fDica').value.trim(),
        tabela: tabela
      };

      if (nova) {
        dados.id = 'custom-' + Date.now().toString(36);
        dados.exercicios = [];
        window.EF.conteudo.criar(dados);
        window.EF.ui.fecharModal();
        window.EF.ui.toast('Aula criada. Adiciona exercícios no separador «Exercícios».', 'ok');
      } else {
        window.EF.conteudo.editar(id, dados);
        window.EF.ui.fecharModal();
        window.EF.ui.toast('Aula atualizada.', 'ok');
      }
      renderAulas();
      renderStats();
    });
  }

  /* ---------- Criar exercício ---------- */
  function abrirEditorExercicio() {
    var licoes = window.EF.licoes || [];
    var html = '<h2>Criar exercício</h2>' +
      '<p class="pequeno muted">O exercício é adicionado ao fim da lista de exercícios da aula escolhida.</p>' +
      '<form id="formEx">' +
        '<div class="campo"><label for="fxAula">Aula *</label><select id="fxAula">' +
          licoes.map(function (l) {
            return '<option value="' + l.id + '">' + l.icone + ' ' + esc(l.titulo) + ' (' + (l.exercicios || []).length + ' ex.)</option>';
          }).join('') +
        '</select></div>' +
        '<div class="campo"><label for="fxTipo">Tipo *</label><select id="fxTipo">' +
          '<option value="escolha">Escolha múltipla</option>' +
          '<option value="completar">Completar frase</option>' +
          '<option value="traducao">Tradução</option>' +
          '<option value="ordenar">Ordenar palavras</option>' +
          '<option value="escuta">Listening (áudio)</option>' +
          '<option value="escrita">Writing</option>' +
          '<option value="fala">Speaking</option>' +
        '</select></div>' +
        '<div class="campo"><label for="fxPerg">Enunciado *</label>' +
          '<input id="fxPerg" placeholder="Ex.: Completa: She ___ a doctor." required></div>' +
        '<div class="campo"><label for="fxOpcoes">Opções (separadas por | — só para escolha/escuta)</label>' +
          '<input id="fxOpcoes" placeholder="am | is | are"></div>' +
        '<div class="campo"><label for="fxCorreta">Índice da resposta correta (0 = primeira)</label>' +
          '<input id="fxCorreta" type="number" min="0" value="0"></div>' +
        '<div class="campo"><label for="fxResposta">Resposta(s) aceite(s) (separadas por | — completar/tradução/ordenar)</label>' +
          '<input id="fxResposta" placeholder="she is my teacher | she is a good teacher"></div>' +
        '<div class="campo"><label for="fxPalavras">Palavras para ordenar (separadas por |)</label>' +
          '<input id="fxPalavras" placeholder="is | This | my | sister"></div>' +
        '<div class="campo"><label for="fxAudio">Texto do áudio (listening)</label>' +
          '<input id="fxAudio" placeholder="Please speak slowly."></div>' +
        '<div class="campo"><label for="fxFrase">Frase modelo (speaking)</label>' +
          '<input id="fxFrase" placeholder="Hello, my name is Ana."></div>' +
        '<div class="campo"><label for="fxExplica">Explicação da resposta (mostrada ao aluno) *</label>' +
          '<textarea id="fxExplica" placeholder="Com he/she/it usa-se «is»."></textarea></div>' +
        '<div id="erroEx" class="feedback feedback--erro escondido" role="alert"></div>' +
        '<div class="flex gap-10 mt-20" style="flex-wrap:wrap">' +
          '<button class="btn" type="submit">Guardar exercício</button>' +
          '<button class="btn btn--ghost" type="button" data-fechar-modal>Cancelar</button>' +
        '</div>' +
      '</form>';

    window.EF.ui.abrirModal(html);

    document.getElementById('formEx').addEventListener('submit', function (ev) {
      ev.preventDefault();
      var erro = document.getElementById('erroEx');
      var idAula = document.getElementById('fxAula').value;
      var tipo = document.getElementById('fxTipo').value;
      var perg = document.getElementById('fxPerg').value.trim();
      var explica = document.getElementById('fxExplica').value.trim();

      if (perg.length < 5) { erro.textContent = 'O enunciado é demasiado curto.'; erro.classList.remove('escondido'); return; }
      if (!explica) { erro.textContent = 'Escreve a explicação — é o que faz a diferença no aprendizado.'; erro.classList.remove('escondido'); return; }

      var ex = { tipo: tipo, perg: perg, explica: explica };
      var opcoes = document.getElementById('fxOpcoes').value.split('|').map(function (s) { return s.trim(); }).filter(Boolean);
      var respostas = document.getElementById('fxResposta').value.split('|').map(function (s) { return s.trim(); }).filter(Boolean);
      var palavras = document.getElementById('fxPalavras').value.split('|').map(function (s) { return s.trim(); }).filter(Boolean);

      if (tipo === 'escolha' || tipo === 'escuta') {
        if (opcoes.length < 2) { erro.textContent = 'Precisas de pelo menos 2 opções.'; erro.classList.remove('escondido'); return; }
        ex.opcoes = opcoes;
        ex.correta = Math.max(0, Math.min(opcoes.length - 1, parseInt(document.getElementById('fxCorreta').value, 10) || 0));
        if (tipo === 'escuta') {
          ex.audio = document.getElementById('fxAudio').value.trim() || opcoes[ex.correta];
          ex.correta = 0;
        }
      } else if (tipo === 'completar' || tipo === 'traducao') {
        if (!respostas.length) { erro.textContent = 'Indica pelo menos uma resposta aceite.'; erro.classList.remove('erro'); erro.classList.remove('escondido'); return; }
        ex.resposta = respostas;
        ex.frase = '';
      } else if (tipo === 'ordenar') {
        if (palavras.length < 2) { erro.textContent = 'Indica as palavras a ordenar.'; erro.classList.remove('escondido'); return; }
        ex.palavras = palavras;
        ex.resposta = respostas[0] || palavras.join(' ');
      } else if (tipo === 'fala') {
        ex.frase = document.getElementById('fxFrase').value.trim() || 'Hello, my name is Ana.';
      }

      var licao = (window.EF.licoes || []).filter(function (l) { return l.id === idAula; })[0];
      if (!licao) { erro.textContent = 'Aula não encontrada.'; erro.classList.remove('escondido'); return; }

      var lista = (licao.exercicios || []).slice();
      lista.push(ex);
      window.EF.conteudo.editar(idAula, { exercicios: lista });
      window.EF.ui.fecharModal();
      window.EF.ui.toast('Exercício adicionado a «' + licao.titulo + '».', 'ok');
      renderExercicios();
      renderAulas();
      renderStats();
    });
  }

  /* ---------- Exercícios ---------- */
  var tiposNomes = {
    escolha: 'Escolha múltipla', completar: 'Completar', traducao: 'Tradução',
    ordenar: 'Ordenar palavras', escuta: 'Listening', escrita: 'Writing', fala: 'Speaking'
  };

  function renderExercicios() {
    var alvo = document.getElementById('admDistribuicao');
    var alvo2 = document.getElementById('admExerciciosLista');
    var contagem = {};
    (window.EF.licoes || []).forEach(function (l) {
      (l.exercicios || []).forEach(function (ex) {
        contagem[ex.tipo] = (contagem[ex.tipo] || 0) + 1;
      });
    });
    var total = Object.keys(contagem).reduce(function (s, k) { return s + contagem[k]; }, 0) || 1;

    if (alvo) {
      alvo.innerHTML = Object.keys(tiposNomes).map(function (t) {
        var n = contagem[t] || 0;
        return '<div><div class="flex-entre pequeno mb-10"><span>' + tiposNomes[t] + '</span><span class="muted">' + n + '</span></div>' +
          '<div class="barra-progresso"><span style="width:' + Math.round((n / total) * 100) + '%"></span></div></div>';
      }).join('');
    }

    if (alvo2) {
      alvo2.innerHTML = (window.EF.licoes || []).filter(function (l) { return (l.exercicios || []).length; }).map(function (l) {
        return '<div class="flex-entre pequeno" style="padding:8px 0;border-bottom:1px solid var(--borda);gap:10px;flex-wrap:wrap">' +
          '<span>' + l.icone + ' ' + esc(l.titulo) + '</span>' +
          '<span class="flex-centro gap-6">' +
            '<span class="badge badge--cinza">' + (l.exercicios || []).length + ' ex.</span>' +
            '<button class="btn btn--pequeno btn--ghost" type="button" data-add-ex="' + l.id + '"><i class="fa-solid fa-plus" aria-hidden="true"></i></button>' +
          '</span></div>';
      }).join('') || '<p class="pequeno muted">Sem exercícios.</p>';
    }
  }

  /* ---------- Utilizadores ---------- */
  function renderUtilizadores() {
    var alvo = document.getElementById('admTabelaUsers');
    if (!alvo) return;
    var estado = window.EF.store._estado() || window.EF.store.carregar();
    var users = Object.keys(estado.usuarios || {}).map(function (k) { return estado.usuarios[k]; });

    if (!users.length) {
      alvo.innerHTML = '<p class="pequeno muted">Nenhuma conta registada neste dispositivo.</p>';
      return;
    }
    alvo.innerHTML = '<table class="tabela"><caption class="sr-only">Contas registadas</caption><thead><tr>' +
      '<th scope="col">Nome</th><th scope="col">Email</th><th scope="col">Nível</th><th scope="col">Pontos</th>' +
      '<th scope="col">Aulas</th><th scope="col">Criada em</th></tr></thead><tbody>' +
      users.sort(function (a, b) { return (b.pontos || 0) - (a.pontos || 0); }).map(function (u2) {
        var p = 0;
        Object.keys(u2.licoes || {}).forEach(function (k) { if (u2.licoes[k].concluida) p++; });
        return '<tr><td>' + esc(u2.nome) + '</td><td class="pequeno">' + esc(u2.email) + '</td>' +
          '<td>' + esc(u2.nivel || '—') + '</td><td><strong>' + (u2.pontos || 0) + '</strong></td>' +
          '<td>' + p + '</td><td class="pequeno">' + (u2.criadoEm ? new Date(u2.criadoEm).toLocaleDateString('pt-PT') : '—') + '</td></tr>';
      }).join('') + '</tbody></table>';
  }

  function renderRankingAdmin() {
    var alvo = document.getElementById('admTabelaRanking');
    if (!alvo) return;
    alvo.innerHTML = '<p class="pequeno muted">A carregar…</p>';
    window.EF.store.lerRanking(200).then(function (linhas) {
      if (!linhas.length) {
        alvo.innerHTML = '<p class="pequeno muted">Ainda sem registos no ranking. Os alunos enviam a pontuação ao concluir aulas.</p>';
        return;
      }
      alvo.innerHTML = '<table class="tabela"><caption class="sr-only">Ranking partilhado</caption><thead><tr>' +
        '<th scope="col">Aluno</th><th scope="col">Pontos</th><th scope="col">Aulas</th><th scope="col">Sequência</th></tr></thead><tbody>' +
        linhas.slice(0, 25).map(function (l) {
          return '<tr><td>' + esc(l.nome || '—') + '</td><td><strong>' + (l.pontos || 0) + '</strong></td>' +
            '<td>' + (l.licoes || 0) + '</td><td>' + (l.sequencia || 0) + '</td></tr>';
        }).join('') + '</tbody></table>';
    });
    var stat = document.getElementById('admRanking');
    window.EF.store.lerRanking(500).then(function (l) {
      if (stat) stat.textContent = l.length;
    });
  }

  /* ---------- Estatísticas ---------- */
  function renderEstatisticas() {
    var df = document.documentElement.getAttribute('data-tema') === 'escuro';
    var corTexto = df ? '#c3d1ea' : '#33415c';
    var corGrelha = df ? 'rgba(255,255,255,.08)' : 'rgba(13,27,52,.08)';

    var porNivel = window.EF.niveis.map(function (n) {
      return (window.EF.licoes || []).filter(function (l) { return l.nivel === n.id; }).length;
    });

    var cv1 = document.getElementById('graficoNiveis');
    if (cv1 && window.Chart) {
      if (graficos.niveis) graficos.niveis.destroy();
      graficos.niveis = new window.Chart(cv1, {
        type: 'bar',
        data: {
          labels: window.EF.niveis.map(function (n) { return n.nome; }),
          datasets: [{
            label: 'Aulas',
            data: porNivel,
            backgroundColor: window.EF.niveis.map(function (n) { return n.corHex; }),
            borderRadius: 8
          }]
        },
        options: {
          responsive: true, maintainAspectRatio: false,
          plugins: { legend: { display: false } },
          scales: {
            y: { beginAtZero: true, ticks: { precision: 0, color: corTexto }, grid: { color: corGrelha } },
            x: { ticks: { color: corTexto }, grid: { display: false } }
          }
        }
      });
    }

    var estado = window.EF.store.carregar();
    var users = Object.keys(estado.usuarios || {}).map(function (k) { return estado.usuarios[k]; });
    var contagem = {};
    users.forEach(function (u2) {
      Object.keys(u2.licoes || {}).forEach(function (k) {
        if (u2.licoes[k].concluida) contagem[k] = (contagem[k] || 0) + 1;
      });
    });
    var topConcluidas = Object.keys(contagem).sort(function (a, b) { return contagem[b] - contagem[a]; }).slice(0, 6);
    var titulos = topConcluidas.map(function (id) {
      var l = (window.EF.licoes || []).filter(function (x) { return x.id === id; })[0];
      return l ? l.titulo.slice(0, 22) : id;
    });

    var cv2 = document.getElementById('graficoConclusoes');
    if (cv2 && window.Chart) {
      if (graficos.conclusoes) graficos.conclusoes.destroy();
      graficos.conclusoes = new window.Chart(cv2, {
        type: 'doughnut',
        data: {
          labels: titulos.length ? titulos : ['Sem dados'],
          datasets: [{
            data: titulos.length ? topConcluidas.map(function (id) { return contagem[id]; }) : [1],
            backgroundColor: ['#1d4ed8', '#3b82f6', '#60a5fa', '#facc15', '#fbbf24', '#16a34a'],
            borderWidth: 0
          }]
        },
        options: {
          responsive: true, maintainAspectRatio: false,
          plugins: { legend: { position: 'bottom', labels: { color: corTexto, boxWidth: 12, font: { size: 11 } } } }
        }
      });
    }

    var resumo = document.getElementById('admResumo');
    if (resumo) {
      var totalEx = 0;
      (window.EF.licoes || []).forEach(function (l) { totalEx += (l.exercicios || []).length; });
      var totalUsers = users.length;
      var mediaPontos = totalUsers ? Math.round(users.reduce(function (s, u2) { return s + (u2.pontos || 0); }, 0) / totalUsers) : 0;
      resumo.innerHTML = [
        ['Aulas publicadas', (window.EF.licoes || []).length],
        ['Exercícios totais', totalEx],
        ['Contas no dispositivo', totalUsers],
        ['Média de pontos', mediaPontos],
        ['Entradas no dicionário', (window.EF.dicionario || []).length],
        ['Alterações locais de conteúdo', window.EF.conteudo.resumoAlteracoes().editadas]
      ].map(function (p) {
        return '<div class="mini-stat"><div class="mini-stat__rot">' + p[0] + '</div><div class="mini-stat__val">' + p[1] + '</div></div>';
      }).join('');
    }

    carregarFeedback();
  }

  function carregarFeedback() {
    var alvo = document.getElementById('admFeedback');
    if (!alvo) return;
    alvo.innerHTML = '<p class="pequeno muted">A carregar…</p>';
    fetch('tables/feedback?limit=50&sort=-created_at').then(function (r) {
      if (!r.ok) throw new Error(String(r.status));
      return r.json();
    }).then(function (d) {
      var linhas = (d && d.data) || [];
      if (!linhas.length) {
        alvo.innerHTML = '<p class="pequeno muted">Sem mensagens recebidas ainda.</p>';
        return;
      }
      alvo.innerHTML = '<table class="tabela"><caption class="sr-only">Mensagens dos alunos</caption><thead><tr>' +
        '<th scope="col">Data</th><th scope="col">Nome</th><th scope="col">Email</th><th scope="col">Mensagem</th></tr></thead><tbody>' +
        linhas.map(function (l) {
          var dt = l.created_at ? new Date(Number(l.created_at)).toLocaleDateString('pt-PT') : '—';
          return '<tr><td class="pequeno">' + dt + '</td><td>' + esc(l.nome || '—') + '</td>' +
            '<td class="pequeno">' + esc(l.email || '—') + '</td>' +
            '<td class="pequeno" style="max-width:340px">' + esc(l.mensagem || '') + '</td></tr>';
        }).join('') + '</tbody></table>';
    }).catch(function () {
      alvo.innerHTML = '<p class="pequeno muted">Mensagens indisponíveis neste ambiente.</p>';
    });
  }

  /* ---------- Definições ---------- */
  function renderDefinicoes() {
    var estado = document.getElementById('admEstadoConteudo');
    if (estado) {
      var r = window.EF.conteudo.resumoAlteracoes();
      estado.textContent = r.editadas + r.criadas + r.removidas
        ? r.editadas + ' aula(s) editada(s), ' + r.criadas + ' criada(s), ' + r.removidas + ' removida(s).'
        : 'Nenhuma alteração: a mostrar as aulas originais.';
    }
    var btn = document.getElementById('btnGuardarSenha');
    if (btn && !btn._ligado) {
      btn._ligado = true;
      btn.addEventListener('click', function () {
        var inp = document.getElementById('admNovaSenha');
        var s = inp.value.trim();
        if (s.length < 6) {
          window.EF.ui.toast('A palavra-passe precisa de pelo menos 6 caracteres.', 'erro');
          return;
        }
        var email = (credenciais() || { email: CRED_PADRAO.email }).email;
        guardarCredenciais(email, s);
        inp.value = '';
        window.EF.ui.toast('Palavra-passe de administrador atualizada.', 'ok');
      });
    }
    var btnR = document.getElementById('btnRestaurarConteudo');
    if (btnR && !btnR._ligado) {
      btnR._ligado = true;
      btnR.addEventListener('click', function () {
        window.EF.ui.abrirModal('<h2>Restaurar conteúdo original?</h2>' +
          '<p class="pequeno">Todas as aulas editadas, criadas e removidas neste dispositivo voltam ao estado original. O progresso dos alunos não é afetado.</p>' +
          '<div class="flex gap-10 mt-20"><button class="btn btn--perigo" type="button" data-conf>Restaurar</button>' +
          '<button class="btn btn--ghost" type="button" data-fechar-modal>Cancelar</button></div>');
        document.querySelector('[data-conf]').addEventListener('click', function () {
          window.EF.conteudo.restaurarTudo();
          window.EF.ui.fecharModal();
          window.EF.ui.toast('Conteúdo original restaurado.', 'ok');
          renderTudo();
        });
      });
    }
    var btnE = document.getElementById('btnExportarConteudo');
    if (btnE && !btnE._ligado) {
      btnE._ligado = true;
      btnE.addEventListener('click', function () {
        var blob = new Blob([JSON.stringify(window.EF.licoes, null, 2)], { type: 'application/json' });
        var a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = 'englishfacil-aulas.json';
        a.click();
        URL.revokeObjectURL(a.href);
        window.EF.ui.toast('Aulas exportadas.', 'ok');
      });
    }
  }

  /* ---------- Estatísticas do topo ---------- */
  function renderStats() {
    var totalEx = 0;
    (window.EF.licoes || []).forEach(function (l) { totalEx += (l.exercicios || []).length; });
    var a = document.getElementById('admAulas');
    if (a) a.textContent = (window.EF.licoes || []).length;
    var e = document.getElementById('admExercicios');
    if (e) e.textContent = totalEx;
    var estado = window.EF.store.carregar();
    var c = document.getElementById('admContas');
    if (c) c.textContent = Object.keys(estado.usuarios || {}).length;
  }

  function renderTudo() {
    renderStats();
    renderAulas();
    renderExercicios();
    renderUtilizadores();
    renderRankingAdmin();
    renderEstatisticas();
    renderDefinicoes();
  }

  /* ---------- Eventos ---------- */
  document.addEventListener('DOMContentLoaded', function () {
    window.EF.ui.iniciar('admin');

    if (sessaoAdmin()) mostrarAdmin(); else mostrarAcesso();

    document.getElementById('formAdminLogin').addEventListener('submit', function (ev) {
      ev.preventDefault();
      var email = document.getElementById('adminEmail').value;
      var senha = document.getElementById('adminSenha').value;
      var erro = document.getElementById('adminErro');
      if (validar(email, senha)) {
        definirSessao(true);
        erro.classList.add('escondido');
        mostrarAdmin();
        window.EF.ui.toast('Bem-vindo ao painel administrativo.', 'ok');
      } else {
        erro.textContent = 'Credenciais inválidas. Verifica o email e a palavra-passe.';
        erro.classList.remove('escondido');
      }
    });

    var sair = document.getElementById('btnSairAdmin');
    if (sair) sair.addEventListener('click', function () {
      definirSessao(false);
      mostrarAcesso();
      window.EF.ui.toast('Sessão de administrador terminada.', 'ok');
    });

    document.querySelectorAll('[data-seccao]').forEach(function (b) {
      b.addEventListener('click', function () {
        var sec = b.getAttribute('data-seccao');
        document.querySelectorAll('[data-seccao]').forEach(function (x) { x.classList.toggle('ativa', x === b); });
        document.querySelectorAll('[data-painel]').forEach(function (p) {
          p.hidden = p.getAttribute('data-painel') !== sec;
        });
        if (sec === 'estatisticas') setTimeout(renderEstatisticas, 60);
      });
    });

    var btnNova = document.getElementById('btnNovaAula');
    if (btnNova) btnNova.addEventListener('click', function () { abrirEditorAula(null); });

    var btnNovoEx = document.getElementById('btnNovoExercicio');
    if (btnNovoEx) btnNovoEx.addEventListener('click', abrirEditorExercicio);

    var fNivel = document.getElementById('admFiltroNivel');
    if (fNivel) fNivel.addEventListener('change', function () { filtroNivel = fNivel.value; renderAulas(); });

    var bAula = document.getElementById('admBuscaAula');
    if (bAula) bAula.addEventListener('input', function () { buscaAula = bAula.value.trim().toLowerCase(); renderAulas(); });

    document.addEventListener('click', function (ev) {
      var ed = ev.target.closest('[data-editar]');
      if (ed) { abrirEditorAula(ed.getAttribute('data-editar')); return; }

      var addEx = ev.target.closest('[data-add-ex]');
      if (addEx) {
        abrirEditorExercicio();
        setTimeout(function () {
          var sel = document.getElementById('fxAula');
          if (sel) sel.value = addEx.getAttribute('data-add-ex');
        }, 100);
        return;
      }

      var mover = ev.target.closest('[data-mover]');
      if (mover) {
        var id = mover.getAttribute('data-mover');
        var licao = (window.EF.licoes || []).filter(function (l) { return l.id === id; })[0];
        if (!licao) return;
        var doNivel = (window.EF.licoes || []).filter(function (l) { return l.nivel === licao.nivel; })
          .sort(function (a, b) { return a.ordem - b.ordem; });
        var i = doNivel.findIndex(function (l) { return l.id === id; });
        var novo = prompt('Nova posição nesta sequência (1 a ' + doNivel.length + '):', licao.ordem);
        if (novo === null) return;
        var pos = parseInt(novo, 10);
        if (isNaN(pos) || pos < 1 || pos > doNivel.length) { window.EF.ui.toast('Posição inválida.', 'erro'); return; }
        doNivel.splice(i, 1);
        doNivel.splice(pos - 1, 0, licao);
        doNivel.forEach(function (l, idx) { window.EF.conteudo.editar(l.id, { ordem: idx + 1 }); });
        window.EF.ui.toast('Ordem atualizada.', 'ok');
        renderAulas();
        return;
      }

      var rem = ev.target.closest('[data-remover]');
      if (rem) {
        var rid = rem.getAttribute('data-remover');
        var lr = (window.EF.licoes || []).filter(function (l) { return l.id === rid; })[0];
        window.EF.ui.abrirModal('<h2>Remover aula?</h2>' +
          '<p class="pequeno">«' + esc(lr ? lr.titulo : rid) + '» deixa de aparecer na plataforma neste dispositivo. Podes restaurar em «Definições».</p>' +
          '<div class="flex gap-10 mt-20"><button class="btn btn--perigo" type="button" data-conf>Remover</button>' +
          '<button class="btn btn--ghost" type="button" data-fechar-modal>Cancelar</button></div>');
        document.querySelector('[data-conf]').addEventListener('click', function () {
          window.EF.conteudo.remover(rid);
          window.EF.ui.fecharModal();
          window.EF.ui.toast('Aula removida.', 'ok');
          renderTudo();
        });
      }
    });

    document.addEventListener('ef:conteudo', function () { renderStats(); renderAulas(); });
  });
})();
