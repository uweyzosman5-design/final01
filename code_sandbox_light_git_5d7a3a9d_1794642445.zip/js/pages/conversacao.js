/* ============================================================
   Página de conversação
   ============================================================ */
(function () {
  'use strict';

  function esc(s) { return window.EF.ui.esc(s); }
  var contexto = { modo: 'livre', passo: 0 };
  var historico = [];
  var CHAVE_HIST = 'englishfacil:chat:v1';

  var perguntasRapidas = [
    'Como se diz "obrigado" em inglês?',
    'Explica o present perfect',
    'O que significa "deadline"?',
    'Quero praticar uma entrevista de emprego',
    'I go to school yesterday',
    'Como se diz "bom dia" em inglês?'
  ];

  var sugestoesIniciais = [
    'Quero praticar um diálogo no restaurante',
    'Explica a diferença entre will e going to',
    'O que significa "under the weather"?',
    'Corrige: I have 25 years'
  ];

  function carregarHistorico() {
    try {
      var bruto = sessionStorage.getItem(CHAVE_HIST);
      if (bruto) historico = JSON.parse(bruto) || [];
    } catch (e) { historico = []; }
  }

  function guardarHistorico() {
    try { sessionStorage.setItem(CHAVE_HIST, JSON.stringify(historico.slice(-40))); } catch (e) {}
  }

  function bolhaAluno(texto) {
    return '<div class="msg msg--aluno"><p>' + esc(texto) + '</p></div>';
  }

  function bolhaIA(html, opcoes) {
    var opt = opcoes || {};
    return '<div class="msg msg--ia">' + html +
      (opt.semAudio ? '' : '') + '</div>';
  }

  function mensagemBoasVindas() {
    var u = window.EF.store.utilizador();
    var nome = u ? u.nome.split(' ')[0] : '';
    return bolhaIA(
      '<p><span class="msg__en">Hello' + (nome ? ', ' + esc(nome) : '') + '! I am your English teacher.</span></p>' +
      '<p class="msg__pt">Olá! Sou o Professor Fácil. Podes escrever em português ou em inglês.</p>' +
      '<p class="msg__pt">Eu respondo em inglês com a explicação em português, corrijo os teus erros e pratico diálogos contigo. Experimenta uma das sugestões abaixo. 👇</p>'
    );
  }

  function render() {
    var alvo = document.getElementById('chatMensagens');
    if (!alvo) return;
    if (!historico.length) {
      alvo.innerHTML = mensagemBoasVindas();
      return;
    }
    alvo.innerHTML = mensagemBoasVindas() + historico.map(function (m) {
      return m.autor === 'aluno' ? bolhaAluno(m.texto) : bolhaIA(m.html);
    }).join('');
    alvo.scrollTop = alvo.scrollHeight;
  }

  function acrescentar(autor, conteudo) {
    var alvo = document.getElementById('chatMensagens');
    var el = document.createElement('div');
    if (autor === 'aluno') {
      el.innerHTML = bolhaAluno(conteudo);
    } else {
      el.innerHTML = bolhaIA(conteudo + '<div class="mt-10 flex gap-6"><button class="btn-audio" type="button" data-falar-trecho aria-label="Ouvir em inglês"><i class="fa-solid fa-volume-high" aria-hidden="true"></i></button><span class="pequeno muted" style="align-self:center">Ouvir o inglês desta resposta</span></div>');
      var trechos = conteudo.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
      var m = /([A-Z][^.!?]{4,90}[.!?])/.exec(trechos);
      var falar = el.querySelector('[data-falar-trecho]');
      if (falar) falar.setAttribute('data-falar', m ? m[1] : trechos.slice(0, 120));
    }
    alvo.appendChild(el);
    alvo.scrollTop = alvo.scrollHeight;
    historico.push({ autor: autor, texto: autor === 'aluno' ? conteudo : '', html: autor === 'aluno' ? '' : conteudo });
    guardarHistorico();
  }

  function indicadorDigitar() {
    var alvo = document.getElementById('chatMensagens');
    var el = document.createElement('div');
    el.className = 'msg msg--ia';
    el.id = 'indicadorDigitar';
    el.innerHTML = '<span class="muted pequeno">O professor está a escrever…</span>';
    alvo.appendChild(el);
    alvo.scrollTop = alvo.scrollHeight;
  }

  function removerIndicador() {
    var el = document.getElementById('indicadorDigitar');
    if (el) el.remove();
  }

  function enviar(texto) {
    var entrada = String(texto || '').trim();
    if (!entrada) return;

    var btn = document.getElementById('chatEnviar');
    if (btn) btn.disabled = true;
    acrescentar('aluno', entrada);
    indicadorDigitar();

    var u = window.EF.store.utilizador();
    var ctx = {
      modo: contexto.modo,
      passo: contexto.passo,
      nome: u ? u.nome.split(' ')[0] : null
    };

    setTimeout(function () {
      removerIndicador();
      var r = window.EF.professor.responde(entrada, ctx);
      acrescentar('ia', r.html);

      if (r.iniciarDialogo) {
        contexto.modo = r.iniciarDialogo;
        contexto.passo = 0;
        atualizarEstadoDialogo();
      } else if (r.proximoPasso != null) {
        contexto.passo = r.proximoPasso;
        if (r.concluido) {
          setTimeout(function () {
            contexto.modo = 'livre';
            contexto.passo = 0;
            atualizarEstadoDialogo();
          }, 1200);
        } else {
          atualizarEstadoDialogo();
        }
      }

      if (u) {
        var novas = window.EF.store.registarMensagemChat();
        atualizarContador();
        (novas || []).forEach(function (m) {
          var meta = window.EF.medalhas.filter(function (x) { return x.id === m; })[0];
          if (meta) window.EF.ui.toast('Medalha: ' + meta.nome + ' ' + meta.icone, 'ok');
        });
      }
      if (btn) btn.disabled = false;
      var input = document.getElementById('chatInput');
      if (input) input.focus();
    }, 550);
  }

  function atualizarContador() {
    var el = document.getElementById('contadorChat');
    if (!el) return;
    var u = window.EF.store.utilizador();
    if (!u) {
      el.textContent = ' Cria conta para guardar pontos de conversação.';
      return;
    }
    var c = window.EF.store.chatHoje();
    el.textContent = ' Mensagens hoje: ' + c.usado + ' (as primeiras ' + c.maximo + ' dão 1 ponto cada).';
  }

  function atualizarEstadoDialogo() {
    var el = document.getElementById('sugestoesChat');
    if (!el) return;
    if (contexto.modo !== 'livre' && window.EF.professor.dialogos[contexto.modo]) {
      var d = window.EF.professor.dialogos[contexto.modo];
      el.innerHTML = '<span class="sugestao-chip" style="cursor:default;background:var(--amarelo-100);border-color:var(--amarelo)">' +
        d.icone + ' Diálogo: ' + esc(d.nome) + ' — passo ' + (contexto.passo + 1) + ' de ' + d.passos.length + '</span>' +
        '<button class="sugestao-chip" type="button" data-sair-dialogo>Sair do diálogo</button>' +
        '<button class="sugestao-chip" type="button" data-dica-dialogo>Ver resposta modelo</button>';
    } else {
      el.innerHTML = sugestoesIniciais.map(function (s) {
        return '<button class="sugestao-chip" type="button" data-sugestao="' + esc(s) + '">' + esc(s) + '</button>';
      }).join('');
    }
  }

  function renderLaterais() {
    var listaD = document.getElementById('listaDialogos');
    if (listaD) {
      listaD.innerHTML = Object.keys(window.EF.professor.dialogos).map(function (k) {
        var d = window.EF.professor.dialogos[k];
        return '<button class="sugestao-chip" type="button" style="text-align:left;justify-content:flex-start" data-iniciar-dialogo="' + k + '">' +
          d.icone + ' ' + esc(d.nome) + '</button>';
      }).join('');
    }
    var listaP = document.getElementById('listaPerguntasRapidas');
    if (listaP) {
      listaP.innerHTML = perguntasRapidas.map(function (p) {
        return '<button class="sugestao-chip" type="button" style="text-align:left;justify-content:flex-start" data-sugestao="' + esc(p) + '">' + esc(p) + '</button>';
      }).join('');
    }
  }

  function iniciarDialogo(chave) {
    var d = window.EF.professor.dialogos[chave];
    if (!d) return;
    contexto.modo = chave;
    contexto.passo = 0;
    acrescentar('aluno', 'Quero praticar: ' + d.nome);
    setTimeout(function () {
      acrescentar('ia', '<p><strong>' + d.icone + ' ' + esc(d.nome) + '</strong></p>' +
        '<p class="msg__pt">Vou fazer o papel da outra pessoa. Responde em inglês — se errares, dou-te uma sugestão.</p>' +
        '<p style="margin-top:8px"><span class="msg__en">' + esc(d.passos[0].ia) + '</span></p>' +
        '<p class="msg__pt">' + esc(d.passos[0].pt) + '</p>');
      atualizarEstadoDialogo();
    }, 420);
  }

  document.addEventListener('DOMContentLoaded', function () {
    window.EF.ui.iniciar('conversacao');
    carregarHistorico();
    render();
    renderLaterais();
    atualizarEstadoDialogo();
    atualizarContador();

    var params = new URLSearchParams(window.location.search);
    if (params.get('tema')) {
      var input = document.getElementById('chatInput');
      if (input) input.placeholder = 'Pergunta sobre: ' + params.get('tema') + '…';
      setTimeout(function () {
        var alvo = document.getElementById('chatMensagens');
        var el = document.createElement('div');
        el.className = 'msg msg--ia';
        el.innerHTML = '<p class="msg__pt">Vi que vieste da aula <strong>' + esc(params.get('tema')) + '</strong>. Pergunta o que quiseres sobre ela — em português.</p>';
        alvo.appendChild(el);
      }, 300);
    }

    var form = document.getElementById('chatForm');
    if (form) {
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        var input = document.getElementById('chatInput');
        var txt = input.value;
        input.value = '';
        enviar(txt);
      });
    }

    document.addEventListener('click', function (e) {
      var s = e.target.closest('[data-sugestao]');
      if (s) { enviar(s.getAttribute('data-sugestao')); return; }

      var d = e.target.closest('[data-iniciar-dialogo]');
      if (d) { iniciarDialogo(d.getAttribute('data-iniciar-dialogo')); return; }

      if (e.target.closest('[data-sair-dialogo]')) {
        contexto = { modo: 'livre', passo: 0 };
        acrescentar('ia', '<p class="msg__pt">Saímos do diálogo. Podemos voltar a conversa livre. 🙂</p>');
        atualizarEstadoDialogo();
        return;
      }

      if (e.target.closest('[data-dica-dialogo]')) {
        var dd = window.EF.professor.dialogos[contexto.modo];
        if (dd) {
          var p = dd.passos[Math.min(contexto.passo, dd.passos.length - 1)];
          acrescentar('ia', '<p class="msg__pt">💡 Uma resposta possível:</p><p><span class="msg__en">' + esc(p.esperado) + '</span></p><p class="msg__pt">' + esc(p.dica) + '</p>');
        }
        return;
      }
    });

    var limpar = document.getElementById('btnLimparChat');
    if (limpar) {
      limpar.addEventListener('click', function () {
        historico = [];
        contexto = { modo: 'livre', passo: 0 };
        guardarHistorico();
        render();
        atualizarEstadoDialogo();
        window.EF.ui.toast('Conversa limpa.', 'ok');
      });
    }
  });
})();
