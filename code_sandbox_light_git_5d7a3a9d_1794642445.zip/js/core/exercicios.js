/* ============================================================
   English Fácil — Motor de exercícios interativos
   Tipos: escolha, completar, traducao, ordenar, escuta, escrita, fala
   ============================================================ */
window.EF = window.EF || {};

(function () {
  'use strict';

  var letras = ['A', 'B', 'C', 'D', 'E', 'F'];

  function esc(s) { return window.EF.ui.esc(s); }

  function normalizarTexto(s) {
    return String(s || '')
      .toLowerCase()
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .replace(/[.,!?;:¡¿"“”'’]/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  /* Compara respostas aceitando pequenas variações */
  function comparar(entrada, aceites) {
    var e = normalizarTexto(entrada);
    if (!e) return false;
    var lista = Array.isArray(aceites) ? aceites : [aceites];
    return lista.some(function (a) {
      var n = normalizarTexto(a);
      if (e === n) return true;
      // aceita com/sem apóstrofos expandidos e pequenas palavras extra opcionais
      if (e.replace(/\s+/g, '') === n.replace(/\s+/g, '')) return true;
      return false;
    });
  }

  function feedbackHTML(ok, explica) {
    return '<div class="feedback ' + (ok ? 'feedback--ok' : 'feedback--erro') + '" role="status">' +
      '<i class="fa-solid ' + (ok ? 'fa-circle-check' : 'fa-circle-xmark') + '" aria-hidden="true"></i>' +
      '<div><strong>' + (ok ? 'Correto!' : 'Ainda não é esta.') + '</strong>' +
      '<p>' + esc(explica || '') + '</p></div></div>';
  }

  /**
   * Renderiza um exercício dentro de `alvo`.
   * opcoes: { aoResponder(ok) , indice, total }
   */
  function render(exercicio, alvo, opcoes) {
    var opt = opcoes || {};
    var tipo = exercicio.tipo;
    var respondido = false;

    alvo.innerHTML = '';
    var card = document.createElement('div');
    card.className = 'exercicio';

    function concluir(ok) {
      if (respondido) return;
      respondido = true;
      if (typeof opt.aoResponder === 'function') opt.aoResponder(ok);
    }

    var etiqueta = {
      escolha: 'Escolha múltipla', completar: 'Completar frase', traducao: 'Tradução',
      ordenar: 'Ordenar palavras', escuta: 'Compreensão oral (listening)',
      escrita: 'Escrita (writing)', fala: 'Fala (speaking)'
    }[tipo] || 'Exercício';

    var cabec = '<div class="flex-entre mb-10" style="flex-wrap:wrap;gap:8px">' +
      '<span class="badge badge--cinza">' + etiqueta + '</span>' +
      (opt.indice != null ? '<span class="pequeno muted">Pergunta ' + (opt.indice + 1) + (opt.total ? ' de ' + opt.total : '') + '</span>' : '') +
      '</div>' +
      '<p class="exercicio__enunciado">' + esc(exercicio.perg) + '</p>';

    if (tipo === 'escolha' || tipo === 'escuta') {
      var audioHTML = '';
      if (tipo === 'escuta' && exercicio.audio) {
        audioHTML = '<div class="flex-centro gap-10 mb-10" style="flex-wrap:wrap">' +
          '<button class="btn btn--pequeno btn--ghost" type="button" data-falar="' + esc(exercicio.audio) + '">' +
          '<i class="fa-solid fa-volume-high" aria-hidden="true"></i> Ouvir outra vez</button>' +
          '<span class="pequeno muted">Ouve com atenção e escolhe a opção correta.</span></div>';
      }
      var opcoesHTML = (exercicio.opcoes || []).map(function (o, i) {
        return '<button class="opcao" type="button" data-i="' + i + '">' +
          '<span class="opcao__letra">' + letras[i] + '</span>' +
          '<span>' + esc(o) + '</span>' +
          '</button>';
      }).join('');

      card.innerHTML = cabec + audioHTML + '<div class="opcoes" role="group" aria-label="Opções de resposta">' + opcoesHTML + '</div>' +
        '<div class="zona-feedback"></div>';

      alvo.appendChild(card);

      card.querySelectorAll('.opcao').forEach(function (btn) {
        btn.addEventListener('click', function () {
          if (respondido) return;
          var escolhida = parseInt(btn.getAttribute('data-i'), 10);
          var correta = exercicio.correta;
          card.querySelectorAll('.opcao').forEach(function (b) {
            var i = parseInt(b.getAttribute('data-i'), 10);
            b.disabled = true;
            if (i === correta) b.classList.add('correta');
            if (i === escolhida && escolhida !== correta) b.classList.add('errada');
          });
          var ok = escolhida === correta;
          card.querySelector('.zona-feedback').innerHTML = feedbackHTML(ok, exercicio.explica);
          concluir(ok);
        });
      });

      if (tipo === 'escuta' && exercicio.audio) {
        setTimeout(function () {
          if (window.EF.audio.suportado()) window.EF.audio.falar(exercicio.audio);
        }, 350);
      }
      return;
    }

    if (tipo === 'completar' || tipo === 'traducao') {
      var instrucao = exercicio.frase ? '<p class="pequeno muted mb-10">' + esc(exercicio.frase) + '</p>' : '';
      var dica = exercicio.dica ? '<div class="campo__dica mt-0">💡 ' + esc(exercicio.dica) + '</div>' : '';
      card.innerHTML = cabec + instrucao +
        '<form novalidate><div class="campo"><label for="resp-' + Math.random().toString(36).slice(2, 8) + '" class="sr-only">A tua resposta</label>' +
        '<input class="resposta-texto" type="text" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="Escreve a tua resposta em inglês…" aria-label="A tua resposta">' +
        dica + '</div>' +
        '<div class="flex gap-10 wrap">' +
          '<button class="btn" type="submit">Verificar</button>' +
          '<button class="btn btn--ghost" type="button" data-ver-resposta>Ver resposta</button>' +
        '</div></form><div class="zona-feedback"></div>';

      alvo.appendChild(card);
      var form = card.querySelector('form');
      var input = card.querySelector('input');

      form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (respondido) return;
        var ok = comparar(input.value, exercicio.resposta);
        var zona = card.querySelector('.zona-feedback');
        zona.innerHTML = feedbackHTML(ok, exercicio.explica) +
          '<p class="pequeno muted">Resposta esperada: <strong>' + esc([].concat(exercicio.resposta)[0]) + '</strong></p>';
        input.disabled = true;
        card.querySelector('button[type="submit"]').disabled = true;
        concluir(ok);
      });

      card.querySelector('[data-ver-resposta]').addEventListener('click', function () {
        if (respondido) return;
        card.querySelector('.zona-feedback').innerHTML =
          '<div class="feedback feedback--erro"><i class="fa-solid fa-lightbulb" aria-hidden="true"></i>' +
          '<div><strong>Resposta correta</strong><p>' + esc([].concat(exercicio.resposta)[0]) + '</p></div></div>';
        var btn = card.querySelector('[data-ver-resposta]');
        btn.disabled = true;
        input.disabled = true;
        concluir(false);
      });
      return;
    }

    if (tipo === 'ordenar') {
      var embaralhadas = (exercicio.palavras || []).slice();
      for (var i = embaralhadas.length - 1; i > 0; i--) {
        var j = Math.floor(Math.random() * (i + 1));
        var tmp = embaralhadas[i]; embaralhadas[i] = embaralhadas[j]; embaralhadas[j] = tmp;
      }
      var chips = embaralhadas.map(function (p, idx) {
        return '<button class="palavra-chip" type="button" data-p="' + esc(p) + '">' + esc(p) + '</button>';
      }).join('');

      card.innerHTML = cabec +
        '<div class="zona-resposta" data-zona aria-live="polite" aria-label="Frase em construção"><span class="pequeno muted" data-placeholder>Toca nas palavras para formar a frase…</span></div>' +
        '<div class="palavras-soltas mt-20" data-soltas>' + chips + '</div>' +
        '<div class="flex gap-10 wrap">' +
          '<button class="btn" type="button" data-verificar disabled>Verificar</button>' +
          '<button class="btn btn--ghost" type="button" data-limpar>Limpar</button>' +
        '</div><div class="zona-feedback"></div>';

      alvo.appendChild(card);
      var zona = card.querySelector('[data-zona]');
      var soltas = card.querySelector('[data-soltas]');
      var verificar = card.querySelector('[data-verificar]');

      function atualizarZona() {
        var tem = zona.querySelectorAll('.palavra-chip').length;
        var ph = zona.querySelector('[data-placeholder]');
        if (ph) ph.style.display = tem ? 'none' : '';
        verificar.disabled = tem === 0 || respondido;
      }

      soltas.addEventListener('click', function (e) {
        var chip = e.target.closest('.palavra-chip');
        if (!chip || respondido) return;
        var novo = document.createElement('button');
        novo.className = 'palavra-chip';
        novo.type = 'button';
        novo.textContent = chip.textContent;
        novo.setAttribute('data-origem', chip.getAttribute('data-p'));
        zona.appendChild(novo);
        chip.disabled = true;
        atualizarZona();
      });

      zona.addEventListener('click', function (e) {
        var chip = e.target.closest('.palavra-chip');
        if (!chip || respondido) return;
        var origem = chip.getAttribute('data-origem');
        var btn = soltas.querySelector('[data-p="' + origem.replace(/"/g, '\\"') + '"]:not([disabled])');
        if (!btn) {
          btn = Array.prototype.filter.call(soltas.querySelectorAll('.palavra-chip'), function (b) {
            return b.getAttribute('data-p') === origem && b.disabled;
          })[0];
        }
        if (btn) btn.disabled = false;
        chip.remove();
        atualizarZona();
      });

      verificar.addEventListener('click', function () {
        if (respondido) return;
        var frase = Array.prototype.map.call(zona.querySelectorAll('.palavra-chip'), function (c) { return c.textContent; }).join(' ');
        var ok = comparar(frase, exercicio.resposta);
        card.querySelector('.zona-feedback').innerHTML = feedbackHTML(ok, exercicio.explica) +
          '<p class="pequeno muted">Frase correta: <strong>' + esc(exercicio.resposta) + '</strong></p>';
        verificar.disabled = true;
        card.querySelector('[data-limpar]').disabled = true;
        concluir(ok);
      });

      card.querySelector('[data-limpar]').addEventListener('click', function () {
        if (respondido) return;
        Array.prototype.forEach.call(zona.querySelectorAll('.palavra-chip'), function (c) { c.remove(); });
        Array.prototype.forEach.call(soltas.querySelectorAll('.palavra-chip'), function (b) { b.disabled = false; });
        atualizarZona();
      });

      atualizarZona();
      return;
    }

    if (tipo === 'escrita') {
      card.innerHTML = cabec +
        '<div class="campo"><label for="escrita-' + Math.random().toString(36).slice(2, 8) + '" class="sr-only">A tua resposta</label>' +
        '<textarea class="resposta-texto" placeholder="Escreve aqui em inglês…" aria-label="A tua resposta escrita"></textarea>' +
        '</div><div class="flex gap-10 wrap">' +
        '<button class="btn" type="button" data-verificar>Ver exemplo e dica</button>' +
        '</div><div class="zona-feedback"></div>';

      alvo.appendChild(card);
      card.querySelector('[data-verificar]').addEventListener('click', function () {
        if (respondido) return;
        var txt = card.querySelector('textarea').value.trim();
        var palavras = txt ? txt.split(/\s+/).length : 0;
        var zona = card.querySelector('.zona-feedback');
        if (!txt) {
          zona.innerHTML = '<div class="feedback feedback--erro"><i class="fa-solid fa-pen" aria-hidden="true"></i>' +
            '<div><strong>Escreve pelo menos uma frase.</strong><p>Tentar é o passo mais importante. Não há correção automática perfeita aqui — o professor virtual ajuda-te.</p></div></div>';
          return;
        }
        zona.innerHTML = '<div class="feedback feedback--ok"><i class="fa-solid fa-check" aria-hidden="true"></i>' +
          '<div><strong>Boa! Escreveste ' + palavras + ' palavra' + (palavras === 1 ? '' : 's') + '.</strong>' +
          '<p>' + esc(exercicio.explica || '') + '</p></div></div>' +
          (exercicio.exemplo ? '<div class="destaque"><strong>Exemplo de resposta:</strong><br><em>' + esc(exercicio.exemplo) + '</em></div>' : '') +
          '<a class="btn btn--pequeno btn--ghost" href="conversacao.html">Pedir correção ao professor virtual</a>';
        card.querySelector('[data-verificar]').disabled = true;
        concluir(palavras >= 3);
      });
      return;
    }

    if (tipo === 'fala') {
      card.innerHTML = cabec +
        '<div class="destaque" style="font-size:1.02rem"><strong>' + esc(exercicio.frase) + '</strong></div>' +
        (exercicio.dica ? '<p class="pequeno muted">💡 ' + esc(exercicio.dica) + '</p>' : '') +
        '<div class="flex gap-10 wrap">' +
          '<button class="btn" type="button" data-falar="' + esc(exercicio.frase) + '"><i class="fa-solid fa-volume-high" aria-hidden="true"></i> Ouvir modelo</button>' +
          '<button class="btn btn--amarelo" type="button" data-gravar><i class="fa-solid fa-microphone" aria-hidden="true"></i> Gravar a minha voz</button>' +
          '<button class="btn btn--ghost" type="button" data-ja-fiz>Já pratiquei ✓</button>' +
        '</div><div class="zona-feedback"></div>';

      alvo.appendChild(card);
      var btnGravar = card.querySelector('[data-gravar]');
      var zonaF = card.querySelector('.zona-feedback');
      var mediaRecorder = null, chunks = [], streamAtual = null, gravando = false;

      btnGravar.addEventListener('click', function () {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
          zonaF.innerHTML = '<div class="feedback feedback--erro"><i class="fa-solid fa-microphone-slash" aria-hidden="true"></i>' +
            '<div><strong>Microfone indisponível neste navegador.</strong><p>Sem problema: lê a frase em voz alta três vezes e usa o botão «Já pratiquei».</p></div></div>';
          return;
        }
        if (gravando) {
          if (mediaRecorder && mediaRecorder.state !== 'inactive') mediaRecorder.stop();
          return;
        }
        navigator.mediaDevices.getUserMedia({ audio: true }).then(function (stream) {
          streamAtual = stream;
          mediaRecorder = new MediaRecorder(stream);
          chunks = [];
          mediaRecorder.ondataavailable = function (e) { if (e.data.size) chunks.push(e.data); };
          mediaRecorder.onstop = function () {
            gravando = false;
            btnGravar.innerHTML = '<i class="fa-solid fa-microphone" aria-hidden="true"></i> Gravar a minha voz';
            btnGravar.classList.remove('btn--perigo');
            btnGravar.classList.add('btn--amarelo');
            streamAtual.getTracks().forEach(function (t) { t.stop(); });
            if (!chunks.length) return;
            var blob = new Blob(chunks, { type: 'audio/webm' });
            var url = URL.createObjectURL(blob);
            zonaF.innerHTML = '<div class="feedback feedback--ok"><i class="fa-solid fa-ear-listen" aria-hidden="true"></i>' +
              '<div><strong>Gravação concluída!</strong><p>Ouve-te e compara com o modelo. Repetir três vezes melhora a pronúncia.</p></div></div>' +
              '<audio controls src="' + url + '" style="width:100%;margin-top:10px"></audio>';
            concluir(true);
          };
          mediaRecorder.start();
          gravando = true;
          btnGravar.innerHTML = '<i class="fa-solid fa-stop" aria-hidden="true"></i> Parar gravação';
          btnGravar.classList.remove('btn--amarelo');
          btnGravar.classList.add('btn--perigo');
        }).catch(function () {
          zonaF.innerHTML = '<div class="feedback feedback--erro"><i class="fa-solid fa-microphone-slash" aria-hidden="true"></i>' +
            '<div><strong>Não foi possível aceder ao microfone.</strong><p>Autoriza o microfone nas definições do navegador, ou pratica em voz alta e clica em «Já pratiquei».</p></div></div>';
        });
      });

      card.querySelector('[data-ja-fiz]').addEventListener('click', function () {
        zonaF.innerHTML = '<div class="feedback feedback--ok"><i class="fa-solid fa-check" aria-hidden="true"></i>' +
          '<div><strong>Prática registada.</strong><p>A repetição em voz alta é o que transforma conhecimento em fala automática.</p></div></div>';
        this.disabled = true;
        concluir(true);
      });
      return;
    }

    card.innerHTML = cabec + '<p class="pequeno muted">Tipo de exercício não reconhecido.</p>';
    alvo.appendChild(card);
  }

  /**
   * Constrói um teste sequencial de exercícios.
   * container: elemento, exercicios: array, opcoes: { aoTerminar({acertos,total}) , titulo }
   */
  function criarTeste(container, exercicios, opcoes) {
    var opt = opcoes || {};
    var indice = 0;
    var acertos = 0;
    var resultados = [];

    container.innerHTML = '';

    var barra = document.createElement('div');
    barra.className = 'mb-20';
    barra.innerHTML = '<div class="flex-entre mb-10"><span class="pequeno muted" data-contador></span>' +
      '<span class="pequeno muted" data-placar></span></div>' +
      '<div class="barra-progresso"><span data-barra style="width:0%"></span></div>';
    container.appendChild(barra);

    var area = document.createElement('div');
    container.appendChild(area);

    var navegacao = document.createElement('div');
    navegacao.className = 'flex-entre mt-20';
    navegacao.style.flexWrap = 'wrap';
    navegacao.innerHTML = '<span class="pequeno muted">Responde para avançar automaticamente.</span>' +
      '<button class="btn btn--ghost btn--pequeno" type="button" data-proxima disabled>Próxima <i class="fa-solid fa-arrow-right" aria-hidden="true"></i></button>';
    container.appendChild(navegacao);

    var btnProxima = navegacao.querySelector('[data-proxima]');

    function atualizarBarra() {
      var pct = exercicios.length ? Math.round((indice / exercicios.length) * 100) : 0;
      barra.querySelector('[data-contador]').textContent = 'Pergunta ' + Math.min(indice + 1, exercicios.length) + ' de ' + exercicios.length;
      barra.querySelector('[data-placar]').textContent = 'Acertos: ' + acertos;
      barra.querySelector('[data-barra]').style.width = pct + '%';
    }

    function mostrarIndice(i) {
      indice = i;
      atualizarBarra();
      if (i >= exercicios.length) { finalizar(); return; }
      area.innerHTML = '';
      var alvo = document.createElement('div');
      area.appendChild(alvo);
      btnProxima.disabled = true;
      btnProxima.innerHTML = (i === exercicios.length - 1)
        ? 'Ver resultado <i class="fa-solid fa-flag-checkered" aria-hidden="true"></i>'
        : 'Próxima <i class="fa-solid fa-arrow-right" aria-hidden="true"></i>';

      render(exercicios[i], alvo, {
        indice: i,
        total: exercicios.length,
        aoResponder: function (ok) {
          if (ok) acertos++;
          resultados.push({ i: i, ok: ok });
          atualizarBarra();
          btnProxima.disabled = false;
          if (i === exercicios.length - 1) {
            btnProxima.classList.add('btn--amarelo');
            btnProxima.focus({ preventScroll: true });
          }
        }
      });
    }

    btnProxima.addEventListener('click', function () { mostrarIndice(indice + 1); });

    function finalizar() {
      var pct = exercicios.length ? Math.round((acertos / exercicios.length) * 100) : 0;
      var msg = pct === 100 ? 'Perfeito! Acertaste tudo.' :
        pct >= 80 ? 'Muito bem! Estás quase lá.' :
        pct >= 50 ? 'Bom esforço — revê as explicações e tenta de novo.' :
        'Não desistas. Relê a aula e volta a tentar.';
      var cor = pct >= 80 ? 'feedback--ok' : pct >= 50 ? '' : 'feedback--erro';
      area.innerHTML = '<div class="card text-center" style="padding:32px">' +
        '<div style="font-size:3rem;line-height:1">' + (pct >= 80 ? '🎉' : pct >= 50 ? '👏' : '💪') + '</div>' +
        '<h2 style="margin-top:10px">' + acertos + ' de ' + exercicios.length + ' corretas</h2>' +
        '<div class="barra-progresso barra-progresso--amarela mt-20" style="max-width:320px;margin:16px auto 0"><span style="width:' + pct + '%"></span></div>' +
        '<p class="mt-20">' + msg + '</p>' +
        '<div class="flex gap-10" style="justify-content:center;flex-wrap:wrap">' +
          '<button class="btn" type="button" data-repetir><i class="fa-solid fa-rotate-right" aria-hidden="true"></i> Repetir teste</button>' +
          '<button class="btn btn--ghost" type="button" data-rever>Rever conteúdo</button>' +
        '</div></div>';
      barra.querySelector('[data-barra]').style.width = '100%';
      navegacao.classList.add('escondido');
      area.querySelector('[data-repetir]').addEventListener('click', function () {
        acertos = 0; resultados = []; navegacao.classList.remove('escondido');
        mostrarIndice(0);
      });
      area.querySelector('[data-rever]').addEventListener('click', function () {
        var alvoSecao = document.querySelector('[data-rever-alvo]') || document.body;
        alvoSecao.scrollIntoView({ behavior: 'smooth' });
      });
      if (typeof opt.aoTerminar === 'function') {
        opt.aoTerminar({ acertos: acertos, total: exercicios.length, pct: pct, resultados: resultados, titulo: opt.titulo || 'Teste' });
      }
    }

    mostrarIndice(0);
  }

  window.EF.exercicios = {
    render: render,
    criarTeste: criarTeste,
    comparar: comparar,
    normalizarTexto: normalizarTexto
  };
})();
