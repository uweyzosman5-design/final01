/* ============================================================
   English Fácil — Camada de conteúdo editável
   Permite que o painel administrativo edite, crie e remova aulas
   sem alterar os ficheiros base. As alterações ficam guardadas
   neste dispositivo (localStorage) e são aplicadas em todas as páginas.
   ============================================================ */
window.EF = window.EF || {};

(function () {
  'use strict';

  var CHAVE = 'englishfacil:conteudo:v1';
  var dados = null;

  function vazio() {
    return { editadas: {}, criadas: [], removidas: [] };
  }

  function carregar() {
    if (dados) return dados;
    try {
      var bruto = localStorage.getItem(CHAVE);
      if (bruto) {
        var lido = JSON.parse(bruto);
        if (lido && typeof lido === 'object') {
          dados = {
            editadas: lido.editadas || {},
            criadas: Array.isArray(lido.criadas) ? lido.criadas : [],
            removidas: Array.isArray(lido.removidas) ? lido.removidas : []
          };
          return dados;
        }
      }
    } catch (e) {
      console.warn('Conteúdo editável indisponível:', e);
    }
    dados = vazio();
    return dados;
  }

  function guardar() {
    try {
      localStorage.setItem(CHAVE, JSON.stringify(dados));
      document.dispatchEvent(new CustomEvent('ef:conteudo'));
      return true;
    } catch (e) {
      console.warn('Não foi possível guardar o conteúdo:', e);
      return false;
    }
  }

  /* Aplica overrides sobre a lista base */
  function aplicar() {
    var base = window.EF.licoesBase || (window.EF.licoes || []).slice();
    window.EF.licoesBase = base;
    var d = carregar();

    var mapa = {};
    base.forEach(function (l) { mapa[l.id] = Object.assign({}, l); });

    Object.keys(d.editadas).forEach(function (id) {
      if (mapa[id]) mapa[id] = Object.assign({}, mapa[id], d.editadas[id]);
    });

    d.criadas.forEach(function (l) {
      if (l && l.id) mapa[l.id] = Object.assign({}, l, { _personalizada: true });
    });

    d.removidas.forEach(function (id) { delete mapa[id]; });

    window.EF.licoes = Object.keys(mapa).map(function (k) { return mapa[k]; })
      .sort(function (a, b) {
        var na = nivelOrdem(a.nivel), nb = nivelOrdem(b.nivel);
        if (na !== nb) return na - nb;
        return (a.ordem || 0) - (b.ordem || 0);
      });
  }

  function nivelOrdem(n) {
    return { iniciante: 1, intermediario: 2, avancado: 3, real: 4 }[n] || 9;
  }

  function editar(id, alteracoes) {
    var d = carregar();
    var base = (window.EF.licoesBase || []).filter(function (l) { return l.id === id; })[0];
    var original = d.editadas[id] || {};
    d.editadas[id] = Object.assign({}, original, alteracoes);
    guardar();
    aplicar();
    return base;
  }

  function criar(licao) {
    var d = carregar();
    var id = licao.id || ('custom-' + Date.now().toString(36));
    var nova = Object.assign({
      id: id,
      nivel: 'iniciante',
      ordem: 99,
      icone: '📘',
      min: 15,
      titulo: 'Nova aula',
      resumo: '',
      objetivos: [],
      explicacao: [],
      vocabulario: [],
      exercicios: [],
      dica: '',
      tabela: null
    }, licao, { id: id });
    d.criadas.push(nova);
    /* Se estava na lista de removidas, retira */
    d.removidas = d.removidas.filter(function (x) { return x !== id; });
    guardar();
    aplicar();
    return nova;
  }

  function remover(id) {
    var d = carregar();
    d.criadas = d.criadas.filter(function (l) { return l.id !== id; });
    delete d.editadas[id];
    var eBase = (window.EF.licoesBase || []).some(function (l) { return l.id === id; });
    if (eBase && d.removidas.indexOf(id) === -1) d.removidas.push(id);
    guardar();
    aplicar();
  }

  function restaurar(id) {
    var d = carregar();
    delete d.editadas[id];
    d.removidas = d.removidas.filter(function (x) { return x !== id; });
    guardar();
    aplicar();
  }

  function restaurarTudo() {
    dados = vazio();
    guardar();
    aplicar();
  }

  function temAlteracoes() {
    var d = carregar();
    return Object.keys(d.editadas).length > 0 || d.criadas.length > 0 || d.removidas.length > 0;
  }

  function resumoAlteracoes() {
    var d = carregar();
    return {
      editadas: Object.keys(d.editadas).length,
      criadas: d.criadas.length,
      removidas: d.removidas.length
    };
  }

  /* Aplica imediatamente ao carregar */
  if (window.EF.licoes && window.EF.licoes.length) aplicar();

  window.EF.conteudo = {
    aplicar: aplicar,
    editar: editar,
    criar: criar,
    remover: remover,
    restaurar: restaurar,
    restaurarTudo: restaurarTudo,
    temAlteracoes: temAlteracoes,
    resumoAlteracoes: resumoAlteracoes,
    dados: carregar
  };
})();
