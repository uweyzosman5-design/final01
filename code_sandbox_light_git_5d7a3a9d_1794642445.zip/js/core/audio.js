/* ============================================================
   English Fácil — Áudio e pronúncia
   Usa Web Speech API (voz en-US/en-GB) com degradação graciosa.
   ============================================================ */
window.EF = window.EF || {};

(function () {
  'use strict';

  var vozes = [];
  var pronto = false;

  function carregarVozes() {
    if (!('speechSynthesis' in window)) return;
    vozes = window.speechSynthesis.getVoices() || [];
    pronto = vozes.length > 0;
  }

  if ('speechSynthesis' in window) {
    carregarVozes();
    window.speechSynthesis.onvoiceschanged = carregarVozes;
  }

  function suportado() {
    return 'speechSynthesis' in window;
  }

  function escolherVoz() {
    if (!vozes.length) carregarVozes();
    var preferida = window.EF.store ? window.EF.store.carregar().config.voz : null;
    if (preferida) {
      var encontrada = vozes.filter(function (v) { return v.name === preferida; })[0];
      if (encontrada) return encontrada;
    }
    var candidatas = [
      function (v) { return /^en[-_]GB/i.test(v.lang) && /female|samantha|kate|serena/i.test(v.name); },
      function (v) { return /^en[-_]US/i.test(v.lang) && /female|zira|aria|jenny|samantha/i.test(v.name); },
      function (v) { return /^en[-_]GB/i.test(v.lang); },
      function (v) { return /^en[-_]US/i.test(v.lang); },
      function (v) { return /^en/i.test(v.lang); }
    ];
    for (var i = 0; i < candidatas.length; i++) {
      var v = vozes.filter(candidatas[i])[0];
      if (v) return v;
    }
    return null;
  }

  function falar(texto, opcoes) {
    if (!suportado() || !texto) return Promise.resolve(false);
    var opt = opcoes || {};
    try { window.speechSynthesis.cancel(); } catch (e) {}
    var fala = new SpeechSynthesisUtterance(String(texto));
    var voz = escolherVoz();
    if (voz) { fala.voice = voz; fala.lang = voz.lang; }
    else { fala.lang = 'en-GB'; }
    fala.rate = opt.rate || 0.88;
    fala.pitch = 1;
    fala.volume = 1;

    return new Promise(function (resolve) {
      var terminou = false;
      var fim = function (ok) { if (!terminou) { terminou = true; resolve(ok); } };
      fala.onend = function () { fim(true); };
      fala.onerror = function () { fim(false); };
      setTimeout(function () { fim(true); }, Math.max(2500, String(texto).length * 110));
      try { window.speechSynthesis.speak(fala); } catch (e) { fim(false); }
    });
  }

  function temVozIngles() {
    if (!vozes.length) carregarVozes();
    return vozes.some(function (v) { return /^en/i.test(v.lang); });
  }

  /* Delegação: qualquer elemento [data-falar] reproduz o seu texto */
  function ligarDelegacao() {
    document.addEventListener('click', function (ev) {
      var alvo = ev.target.closest('[data-falar]');
      if (!alvo) return;
      ev.preventDefault();
      ev.stopPropagation();
      var texto = alvo.getAttribute('data-falar') || alvo.textContent;
      tocarComEstado(alvo, texto);
    });
  }

  function tocarComEstado(botao, texto) {
    if (!suportado()) {
      if (window.EF.ui && window.EF.ui.toast) {
        window.EF.ui.toast('O teu navegador não suporta leitura em voz alta. Tenta no Chrome, Edge ou Safari.', 'erro');
      }
      return;
    }
    botao.classList.add('tocando');
    falar(texto).then(function () {
      setTimeout(function () { botao.classList.remove('tocando'); }, 200);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', ligarDelegacao);
  } else {
    ligarDelegacao();
  }

  window.EF.audio = {
    falar: falar,
    suportado: suportado,
    temVozIngles: temVozIngles,
    vozes: function () { return vozes.length ? vozes : (carregarVozes(), vozes); }
  };
})();
