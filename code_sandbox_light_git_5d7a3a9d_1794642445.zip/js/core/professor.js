/* ============================================================
   English Fácil — Professor virtual (tutor determinístico)
   Motor de regras: tradução, gramática, correção, diálogos guiados.
   Funciona 100% no navegador, sem serviços externos pagos.
   ============================================================ */
window.EF = window.EF || {};

(function () {
  'use strict';

  function norm(s) {
    return String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
  }

  /* =========================================================
     1. Base de gramática
     ========================================================= */
  var gramatica = [
    {
      chaves: ['present perfect', 'presente perfeito', 'have been', 'has been'],
      titulo: 'Present Perfect (have/has + particípio)',
      explicacao: 'Usa-se para ações que aconteceram sem dizer quando, ou que continuam no presente. Estrutura: <strong>have/has + particípio passado</strong>.',
      exemplos: [
        { en: 'I have visited London.', pt: 'Já visitei Londres.' },
        { en: 'She has finished her work.', pt: 'Ela terminou o trabalho (e o resultado ainda importa).' },
        { en: 'I have lived here since 2020.', pt: 'Vivo aqui desde 2020 (e continuo).' }
      ],
      nota: 'A diferença com o passado simples: se dizes o momento exato → passado simples («I saw him yesterday»). Se não dizes quando → present perfect («I have seen him»).'
    },
    {
      chaves: ['past simple', 'passado simples', 'passado', 'simple past'],
      titulo: 'Past Simple (passado simples)',
      explicacao: 'Descreve ações terminadas no passado. Regulares: verbo + <strong>-ed</strong>. Irregulares: forma própria (go → went, have → had). Negativa e pergunta usam <strong>did</strong> + verbo no infinitivo.',
      exemplos: [
        { en: 'I worked all day yesterday.', pt: 'Trabalhei todo o dia ontem.' },
        { en: 'She went to the market.', pt: 'Ela foi ao mercado.' },
        { en: 'Did you see him? — No, I did not.', pt: 'Viste-o? — Não.' }
      ],
      nota: 'Erro clássico: «I didn\'t went». Depois de did/didn\'t o verbo fica no presente: «I didn\'t go».'
    },
    {
      chaves: ['verbo to be', 'to be', 'am is are', 'ser estar'],
      titulo: 'Verbo to be (am / is / are)',
      explicacao: 'O verbo mais usado do inglês. Serve para «ser» e «estar». <strong>I am</strong>, <strong>you are</strong>, <strong>he/she/it is</strong>, <strong>we/they are</strong>.',
      exemplos: [
        { en: 'I am a student.', pt: 'Sou estudante.' },
        { en: 'They are at home.', pt: 'Eles estão em casa.' },
        { en: 'She is not a doctor.', pt: 'Ela não é médica.' }
      ],
      nota: 'Idade usa to be, não have: «I am 25 years old» (nunca «I have 25 years»).'
    },
    {
      chaves: ['artigo', 'a an the', 'artigos', 'quando usar the'],
      titulo: 'Artigos: a / an / the',
      explicacao: '<strong>a</strong> antes de som de consoante (a book), <strong>an</strong> antes de som de vogal (an apple, an hour). <strong>the</strong> para algo específico ou já mencionado.',
      exemplos: [
        { en: 'I need a pen.', pt: 'Preciso de uma caneta (qualquer).' },
        { en: 'She is an engineer.', pt: 'Ela é engenheira (som de vogal).' },
        { en: 'The pen on the table is mine.', pt: 'A caneta na mesa é minha (específica).' }
      ],
      nota: 'Profissões levam artigo em inglês: «I am a teacher», não «I am teacher».'
    },
    {
      chaves: ['plural', 'plurais', 'plural irregular'],
      titulo: 'Plurais regulares e irregulares',
      explicacao: 'Regra geral: <strong>+s</strong>. Terminados em -s, -sh, -ch, -x, -o: <strong>+es</strong>. Consoante + y: <strong>-ies</strong>.',
      exemplos: [
        { en: 'book → books', pt: 'livro → livros' },
        { en: 'watch → watches', pt: 'relógio → relógios' },
        { en: 'child → children / man → men / woman → women', pt: 'irregulares a memorizar' }
      ],
      nota: '«People» já é plural: nunca «peoples» quando significa pessoas.'
    },
    {
      chaves: ['preposicao', 'preposicoes', 'in on at', 'in at on'],
      titulo: 'Preposições in / on / at',
      explicacao: '<strong>in</strong>: espaços fechados e períodos longos (in the box, in 2020, in May). <strong>on</strong>: superfícies e dias (on the table, on Monday). <strong>at</strong>: pontos exatos, horas e locais específicos (at 7 o\'clock, at the door, at work).',
      exemplos: [
        { en: 'The class starts at nine.', pt: 'A aula começa às nove.' },
        { en: 'I was born in 1995.', pt: 'Nasci em 1995.' },
        { en: 'We meet on Fridays.', pt: 'Encontramo-nos às sextas.' }
      ],
      nota: '«At night» (à noite) é exceção: usa at, não in.'
    },
    {
      chaves: ['presente continuo', 'present continuous', 'ing', 'gerundio'],
      titulo: 'Present Continuous (am/is/are + -ing)',
      explicacao: 'Ações a acontecer agora ou planos futuros já marcados. Estrutura: <strong>am/is/are + verbo-ing</strong>.',
      exemplos: [
        { en: 'I am studying English now.', pt: 'Estou a estudar inglês agora.' },
        { en: 'She is working at the moment.', pt: 'Ela está a trabalhar neste momento.' },
        { en: 'We are meeting the client tomorrow.', pt: 'Vamos encontrar o cliente amanhã (marcado).' }
      ],
      nota: 'Verbos de estado (know, want, like, need) raramente vão para -ing: «I want», não «I am wanting».'
    },
    {
      chaves: ['condicional', 'condicionais', 'if', 'would'],
      titulo: 'Condicionais (if)',
      explicacao: '1º: <strong>If + presente, will + verbo</strong> (futuro possível). 2º: <strong>If + passado, would + verbo</strong> (hipótese irreal). 3º: <strong>If + had + particípio, would have + particípio</strong> (arrependimento).',
      exemplos: [
        { en: 'If it rains, I will stay home.', pt: 'Se chover, fico em casa.' },
        { en: 'If I had money, I would travel.', pt: 'Se tivesse dinheiro, viajaria.' },
        { en: 'If I had studied, I would have passed.', pt: 'Se tivesse estudado, teria passado.' }
      ],
      nota: 'Nunca uses «would» na parte com «if»: «If I would have money» está errado.'
    },
    {
      chaves: ['phrasal verb', 'phrasal verbs'],
      titulo: 'Phrasal verbs',
      explicacao: 'Verbo + partícula com significado novo. Aprende o bloco inteiro, nunca palavra a palavra: <em>give up</em> = desistir, <em>look for</em> = procurar.',
      exemplos: [
        { en: 'I am looking for my keys.', pt: 'Estou à procura das minhas chaves.' },
        { en: 'Do not give up.', pt: 'Não desistas.' },
        { en: 'Please turn off the light.', pt: 'Por favor, desliga a luz.' }
      ],
      nota: 'Há mais de 300 phrasal verbs em uso comum — aprende 5 por semana com uma frase tua.'
    },
    {
      chaves: ['pronome', 'pronomes', 'possessivo', 'his her'],
      titulo: 'Pronomes e possessivos',
      explicacao: 'Sujeito: I, you, he, she, it, we, they. Objeto: me, you, him, her, it, us, them. Possessivo: my, your, his, her, its, our, their.',
      exemplos: [
        { en: 'This is my brother. His name is Paulo.', pt: 'Este é o meu irmão. O nome dele é Paulo.' },
        { en: 'This is my sister. Her name is Ana.', pt: 'Esta é a minha irmã. O nome dela é Ana.' },
        { en: 'Give it to them.', pt: 'Dá-lho a eles.' }
      ],
      nota: 'His = dele, her = dela. O possessivo depende do dono, não do objeto.'
    },
    {
      chaves: ['comparativo', 'superlativo', 'more most'],
      titulo: 'Comparativos e superlativos',
      explicacao: 'Curtos: <strong>+er / +est</strong> (fast → faster → the fastest). Longos: <strong>more / the most</strong> (important → more important → the most important). Irregulares: good → better → the best; bad → worse → the worst.',
      exemplos: [
        { en: 'English is easier than I thought.', pt: 'O inglês é mais fácil do que eu pensava.' },
        { en: 'This is the most interesting lesson.', pt: 'Esta é a lição mais interessante.' },
        { en: 'My English is getting better.', pt: 'O meu inglês está a melhorar.' }
      ],
      nota: 'Nunca juntes as duas formas: «more easier» está errado.'
    },
    {
      chaves: ['voz passiva', 'passiva', 'passive'],
      titulo: 'Voz passiva',
      explicacao: 'Estrutura: <strong>be + particípio passado</strong>. Usa-se quando a ação importa mais do que quem a faz.',
      exemplos: [
        { en: 'English is spoken worldwide.', pt: 'O inglês é falado em todo o mundo.' },
        { en: 'The school was built in 1990.', pt: 'A escola foi construída em 1990.' },
        { en: 'The results will be announced tomorrow.', pt: 'Os resultados serão anunciados amanhã.' }
      ],
      nota: 'Em português dizemos «construiu-se»; em inglês prefere-se a passiva sem agente.'
    },
    {
      chaves: ['pronuncia', 'pronunciacao', 'sotaque', 'accent'],
      titulo: 'Pronúncia: por onde começar',
      explicacao: 'Prioriza três coisas: (1) sons que não existem em português (th, r, w, v/h), (2) o <strong>-s</strong> final do plural e do verbo, (3) terminações <strong>-ed</strong>. O sotaque pode ficar — o que atrapalha é comer as terminações.',
      exemplos: [
        { en: 'three / tree / free', pt: 'th / t / f — sons diferentes no início.' },
        { en: 'works, studies, watches', pt: 'O -s final é essencial.' },
        { en: 'worked, played, wanted', pt: '-ed com três sons: /t/, /d/, /ɪd/.' }
      ],
      nota: 'Objetivo real: ser compreendido por qualquer pessoa, não parecer nativo.'
    },
    {
      chaves: ['vocabulario', 'como aprender palavras', 'memorizar'],
      titulo: 'Como memorizar vocabulário de forma eficaz',
      explicacao: 'A memória guarda contexto, não listas. Para cada palavra nova: (1) escreve uma frase tua, (2) diz em voz alta 3 vezes, (3) revê 24h depois e 7 dias depois.',
      exemplos: [
        { en: '«improve» → My English is improving every week.', pt: 'Frase própria.' },
        { en: '«deadline» → The deadline is next Friday.', pt: 'Contexto real.' }
      ],
      nota: '10 palavras por dia com frases próprias vence 100 palavras por dia numa lista.'
    },
    {
      chaves: ['will going to', 'futuro', 'will', 'going to'],
      titulo: 'Futuro: will vs going to',
      explicacao: '<strong>will</strong>: decisão tomada no momento, promessa, previsão. <strong>going to</strong>: plano já decidido, previsão com evidência.',
      exemplos: [
        { en: 'I will help you.', pt: 'Eu ajudo-te (agora, decidido).' },
        { en: 'I am going to visit my parents.', pt: 'Vou visitar os meus pais (já planeado).' },
        { en: 'Look at those clouds — it is going to rain.', pt: 'Olha as nuvens — vai chover (evidência).' }
      ],
      nota: 'Na dúvida, «will» raramente está errado.'
    }
  ];

  /* =========================================================
     2. Diálogos guiados (situações reais)
     ========================================================= */
  var dialogos = {
    restaurante: {
      nome: 'No restaurante',
      icone: '🍽️',
      passos: [
        { ia: 'Good evening! Welcome to our restaurant. How many people?', pt: 'Boa noite! Bem-vindo ao nosso restaurante. Quantas pessoas?', esperado: 'Table for two, please.', dica: 'Responde com «Table for + número, please».' },
        { ia: 'Of course. Here is the menu. Would you like something to drink?', pt: 'Claro. Aqui está a ementa. Gostaria de algo para beber?', esperado: 'Yes, a glass of water, please.', dica: 'Podes pedir: «A coffee, please» ou «Just water, thank you».' },
        { ia: 'And what would you like to eat?', pt: 'E o que gostaria de comer?', esperado: 'I would like grilled chicken, please.', dica: '«I would like» é mais educado do que «I want».' },
        { ia: 'Excellent choice. Is everything all right?', pt: 'Excelente escolha. Está tudo bem?', esperado: 'Yes, it is delicious, thank you.', dica: 'Elogiar a comida é cultura: «It is delicious».' },
        { ia: 'Would you like anything else?', pt: 'Gostaria de mais alguma coisa?', esperado: 'The bill, please.', dica: 'Britânico: «the bill». Americano: «the check».' }
      ]
    },
    aeroporto: {
      nome: 'No aeroporto',
      icone: '✈️',
      passos: [
        { ia: 'Good morning. May I see your passport, please?', pt: 'Bom dia. Posso ver o seu passaporte, por favor?', esperado: 'Here it is.', dica: '«Here it is» ou «Here you are» — ao entregar algo.' },
        { ia: 'Are you checking any bags?', pt: 'Vai despachar alguma bagagem?', esperado: 'Yes, one suitcase.', dica: '«Yes, one bag» / «No, just hand luggage».' },
        { ia: 'Would you prefer a window or an aisle seat?', pt: 'Prefere lugar à janela ou no corredor?', esperado: 'A window seat, please.', dica: 'window seat / aisle seat.' },
        { ia: 'Your gate is B12. Boarding starts at ten thirty.', pt: 'A sua porta é B12. O embarque começa às dez e meia.', esperado: 'Thank you. Where is gate B12?', dica: 'Perguntar o caminho: «Where is gate B12?»' },
        { ia: 'Is this your first flight to London?', pt: 'É a sua primeira viagem a Londres?', esperado: 'Yes, it is my first time.', dica: '«It is my first time» — resposta natural.' }
      ]
    },
    entrevista: {
      nome: 'Entrevista de emprego',
      icone: '💼',
      passos: [
        { ia: 'Good morning. Please, tell me about yourself.', pt: 'Bom dia. Fale-me de si.', esperado: 'I have three years of experience in customer service.', dica: '3 frases: formação, experiência, motivação.' },
        { ia: 'Why do you want to work with us?', pt: 'Porque quer trabalhar connosco?', esperado: 'I am interested in this company because it values teamwork.', dica: '«I am interested in ... because ...»' },
        { ia: 'What are your main strengths?', pt: 'Quais são os seus pontos fortes?', esperado: 'My main strength is problem solving.', dica: 'Escolhe 2 forças e dá um exemplo.' },
        { ia: 'Tell me about a difficult situation you solved.', pt: 'Fale de uma situação difícil que resolveu.', esperado: 'Last year I solved a problem with a client.', dica: 'Estrutura STAR: situação, tarefa, ação, resultado.' },
        { ia: 'Do you have any questions for us?', pt: 'Tem alguma pergunta para nós?', esperado: 'Yes, what are the next steps?', dica: 'Nunca digas não. Pergunta sobre os próximos passos.' }
      ]
    },
    hotel: {
      nome: 'No hotel',
      icone: '🏨',
      passos: [
        { ia: 'Good afternoon. Welcome to Hotel Central. How can I help you?', pt: 'Boa tarde. Bem-vindo ao Hotel Central. Como posso ajudar?', esperado: 'I have a reservation under the name Silva.', dica: '«I have a reservation under the name ...»' },
        { ia: 'Yes, I found it. Two nights, is that correct?', pt: 'Sim, encontrei. Duas noites, correto?', esperado: 'Yes, that is correct.', dica: 'Confirmar: «Yes, that is correct».' },
        { ia: 'Is breakfast included?', pt: 'O pequeno-almoço está incluído?', esperado: 'Yes, breakfast is included.', dica: 'Basta repetir a estrutura na afirmativa.' },
        { ia: 'What time is check-out?', pt: 'A que horas é o check-out?', esperado: 'Check-out is at eleven.', dica: 'Horas: «at eleven».' },
        { ia: 'Could I have a wake-up call at seven?', pt: 'Poderia dar-me um alarme às sete?', esperado: 'Yes, of course.', dica: '«Yes, of course» ou «Certainly».' }
      ]
    },
    medico: {
      nome: 'No médico',
      icone: '🏥',
      passos: [
        { ia: 'Good morning. What seems to be the problem?', pt: 'Bom dia. Qual é o problema?', esperado: 'I have a headache and a sore throat.', dica: 'Sintomas: headache, sore throat, fever.' },
        { ia: 'How long have you had these symptoms?', pt: 'Há quanto tempo tem estes sintomas?', esperado: 'For three days.', dica: 'Duração usa «for»: for three days.' },
        { ia: 'Do you have a fever?', pt: 'Tem febre?', esperado: 'Yes, I have a fever.', dica: 'Resposta curta e clara.' },
        { ia: 'Are you allergic to any medicine?', pt: 'É alérgico a algum medicamento?', esperado: 'I am allergic to penicillin.', dica: '«I am allergic to ...»' },
        { ia: 'I will give you a prescription. Take it twice a day.', pt: 'Vou dar-lhe uma receita. Tome duas vezes por dia.', esperado: 'Thank you, doctor.', dica: 'Confirma sempre a dose: «How often should I take it?»' }
      ]
    },
    social: {
      nome: 'Conversa social',
      icone: '🎉',
      passos: [
        { ia: 'Hi! Lovely day, isn\'t it?', pt: 'Olá! Está um dia bonito, não está?', esperado: 'Yes, it is lovely.', dica: 'Concordar com o comentário é o protocolo.' },
        { ia: 'Is this your first time here?', pt: 'É a primeira vez que está aqui?', esperado: 'Yes, it is my first time here.', dica: 'Ou «No, I come here often».' },
        { ia: 'Where are you from originally?', pt: 'De onde é originalmente?', esperado: 'I am from Mozambique.', dica: '«I am from + país/cidade».' },
        { ia: 'What do you do in your free time?', pt: 'O que faz no seu tempo livre?', esperado: 'I am into music and football.', dica: '«I am into ...» = gosto muito de.' },
        { ia: 'It was lovely talking to you!', pt: 'Foi ótimo falar consigo!', esperado: 'It was lovely talking to you too.', dica: 'Devolver a frase + «too».' }
      ]
    },
    loja: {
      nome: 'Nas compras',
      icone: '🛍️',
      passos: [
        { ia: 'Hello! Can I help you find something?', pt: 'Olá! Posso ajudar a encontrar algo?', esperado: 'Yes, I am looking for a blue shirt.', dica: '«I am looking for ...»' },
        { ia: 'What size do you need?', pt: 'Que tamanho precisa?', esperado: 'Medium, please.', dica: 'small / medium / large / extra large.' },
        { ia: 'Here you are. Would you like to try it on?', pt: 'Aqui tem. Gostaria de experimentar?', esperado: 'Yes, where is the fitting room?', dica: 'fitting room = provador.' },
        { ia: 'How was it?', pt: 'Como ficou?', esperado: 'It is perfect. How much is it?', dica: '«How much is it?» = quanto custa.' },
        { ia: 'It is 25 dollars. How would you like to pay?', pt: 'São 25 dólares. Como gostaria de pagar?', esperado: 'By card, please.', dica: '«By card» ou «In cash».' }
      ]
    }
  };

  /* =========================================================
     3. Correções automáticas (erros típicos de lusófonos)
     ========================================================= */
  var regrasCorrecao = [
    { re: /\bi\s+(?:have|has)\s+(\d+)\s+years?\b/i, sub: 'I am $1 years old', nota: 'A idade em inglês usa o verbo <strong>to be</strong>, não «have».' },
    { re: /\bi\s+am\s+agree\b/i, sub: 'I agree', nota: '«Agree» é verbo: diz-se «I agree» (não «I am agree»).' },
    { re: /\bhe\s+don'?t\b/i, sub: "he doesn't", nota: 'Com he/she/it usa-se <strong>doesn\'t</strong>, não «don\'t».' },
    { re: /\bi\s+didn'?t\s+went\b/i, sub: "I didn't go", nota: 'Depois de <strong>didn\'t</strong> o verbo fica no presente.' },
    { re: /\bi\s+didn'?t\s+saw\b/i, sub: "I didn't see", nota: 'Depois de <strong>didn\'t</strong> usa-se o verbo base: see.' },
    { re: /\bmore\s+(\w+er)\b/i, sub: '$1', nota: 'Não combines «more» com comparativo em -er.' },
    { re: /\bpeoples\b/i, sub: 'people', nota: '«People» já é plural — não leva -s.' },
    { re: /\beverybody\s+are\b/i, sub: 'everybody is', nota: '«Everybody/everyone» leva verbo no singular: is.' },
    { re: /\binformations\b/i, sub: 'information', nota: '«Information» é incontável em inglês — não tem plural.' },
    { re: /\badvices\b/i, sub: 'advice', nota: '«Advice» é incontável. Para contar: «a piece of advice».' },
    { re: /\bexplain me\b/i, sub: 'explain to me', nota: '«Explain» pede «to»: «explain to me».' },
    { re: /\bdepends of\b/i, sub: 'depends on', nota: '«Depend» pede «on»: «it depends on».' },
    { re: /\bmake\s+(?:a\s+)?photos?\b/i, sub: 'take photos', nota: 'Em inglês diz-se «take a photo», não «make».' },
    { re: /\bwait\s+me\b/i, sub: 'wait for me', nota: '«Wait» pede «for»: «wait for me».' },
    { re: /\bI\s+go\s+to\s+\w+\s+yesterday\b/i, sub: 'I went ... yesterday', nota: '«Yesterday» exige passado: «I went», não «I go».' },
    { re: /\bhave\s+(\d+)\s+years\s+old\b/i, sub: 'be $1 years old', nota: 'Idade: «I am 20 years old».' },
    { re: /\bshe\s+don'?t\b/i, sub: "she doesn't", nota: 'Com she usa-se <strong>doesn\'t</strong>.' },
    { re: /\bit\s+don'?t\b/i, sub: "it doesn't", nota: 'Com it usa-se <strong>doesn\'t</strong>.' },
    { re: /\bI\s+no\s+know\b/i, sub: "I don't know", nota: 'Negativa pede auxiliar: «I don\'t know».' },
    { re: /\bI\s+no\s+understand\b/i, sub: "I don't understand", nota: 'Negativa pede auxiliar: «I don\'t understand».' },
    { re: /\bhow\s+is\s+your\s+name\b/i, sub: 'what is your name', nota: 'Em inglês pergunta-se «What is your name?», não «How is your name?».' },
    { re: /\bI\s+am\s+\d+\s+years\b(?!\s*old)/i, sub: 'I am ... years old', nota: 'Falta «old» no fim: «I am 25 years old».' }
  ];

  function corrigirFrase(texto) {
    var resultado = { original: texto, corrigida: texto, notas: [] };
    regrasCorrecao.forEach(function (r) {
      var m = texto.match(r.re);
      if (m) {
        var novo = texto.replace(r.re, r.sub);
        if (novo !== resultado.corrigida) {
          resultado.corrigida = novo;
          resultado.notas.push({ nota: r.nota, antes: m[0], depois: novo });
        }
      }
    });

    /* Avisos gerais heurísticos */
    var palavras = texto.trim().split(/\s+/);
    if (palavras.length >= 2) {
      if (/^[a-z]/.test(texto.trim())) {
        resultado.notas.push({ nota: 'Em inglês, a primeira letra da frase leva maiúscula.', antes: '', depois: '' });
      }
      if (!/[.!?]$/.test(texto.trim())) {
        resultado.notas.push({ nota: 'Falta a pontuação final (. ? ou !). Pequeno detalhe, mas conta na escrita.', antes: '', depois: '' });
      }
      var terceira = /\b(he|she|it)\s+([a-z]+)\b/i.exec(texto);
      if (terceira && !/(is|was|has|does|doesn't|don't|can|will|would|should|must|may|might|could|did|do)$/i.test(terceira[2])) {
        var verbo = terceira[2].toLowerCase();
        var invariantes = ['go', 'do', 'have', 'be', 'can', 'will', 'would', 'could', 'should', 'must', 'may', 'might', 'not', 'is', 'are', 'was', 'were', 'does', 'did', 'to'];
        if (invariantes.indexOf(verbo) === -1 && /[a-z]$/.test(verbo) && !/(ed|ing)$/.test(verbo) && texto.indexOf(terceira[0]) === texto.lastIndexOf(terceira[0])) {
          var sugestao = verbo.endsWith('y') ? verbo.slice(0, -1) + 'ies'
            : /(s|sh|ch|x|o)$/.test(verbo) ? verbo + 'es' : verbo + 's';
          resultado.notas.push({
            nota: 'Terceira pessoa do singular no presente pede <strong>-' + (sugestao.slice(verbo.length)) + '</strong>: «' + terceira[1] + ' ' + sugestao + '».',
            antes: terceira[0], depois: terceira[1] + ' ' + sugestao
          });
          if (!resultado.sugestaoAuto) resultado.sugestaoAuto = texto.replace(terceira[0], terceira[1] + ' ' + sugestao);
        }
      }
    }
    if (resultado.sugestaoAuto && resultado.corrigida === resultado.original) {
      resultado.corrigida = resultado.sugestaoAuto;
    }
    return resultado;
  }

  /* =========================================================
     4. Tradução / vocabulário a partir do dicionário e aulas
     ========================================================= */
  function basePalavras() {
    var base = [];
    (window.EF.dicionario || []).forEach(function (d) {
      base.push({ en: d.en, pt: d.pt, pron: d.pron, ex: d.ex, exPt: d.exPt, sin: d.sin, ant: d.ant, classe: d.classe, cat: d.cat });
    });
    (window.EF.licoes || []).forEach(function (l) {
      (l.vocabulario || []).forEach(function (v) {
        base.push({ en: v.en, pt: v.pt, pron: v.pron, ex: v.ex, exPt: v.exPt, classe: '', cat: l.titulo });
      });
    });
    return base;
  }

  var _base = null;
  function base() { return _base || (_base = basePalavras()); }

  function procurarPalavra(termo) {
    var t = norm(termo).replace(/^(o|a|os|as|um|uma)\s+/, '');
    if (!t) return null;
    var lista = base();
    var exata = lista.filter(function (d) {
      return norm(d.en) === t || norm(d.pt).split(/,|\//).map(function (x) { return norm(x); }).indexOf(t) !== -1;
    });
    if (exata.length) return exata[0];
    var parcial = lista.filter(function (d) {
      return norm(d.en).indexOf(t) !== -1 || norm(d.pt).indexOf(t) !== -1;
    });
    return parcial.length ? parcial[0] : null;
  }

  function procurarRelacionadas(termo) {
    var t = norm(termo);
    return base().filter(function (d) {
      return norm(d.en).indexOf(t) !== -1 || norm(d.pt).indexOf(t) !== -1;
    }).slice(0, 4);
  }

  /* =========================================================
     5. Respostas
     ========================================================= */
  function respostaTraducao(entrada) {
    /* "como se diz X em ingles" / "traduz X" / "X em ingles" */
    var m = /(?:como\s+(?:se\s+)?diz|como\s+falo|traduz(?:ir)?|traducao\s+de|em\s+ingles\s+(?:se\s+diz)?)\s*[:\-]?\s*["“']?([^"”'?]+?)["”']?(?:\s+em\s+ingles|\s+para\s+ingles|\s+em\s+portugues)?\s*\??$/i.exec(entrada);
    if (!m) {
      m = /^["“']?([^"”'?]+)["”']?\s+(?:em\s+ingles|in\s+english)\s*\??$/i.exec(entrada);
    }
    if (!m) return null;
    var termo = m[1].trim();
    if (!termo || termo.split(/\s+/).length > 6) return null;

    var achado = procurarPalavra(termo);
    if (achado) {
      return {
        en: achado.en,
        pt: achado.pt,
        pron: achado.pron,
        extra: 'Exemplo: <em>' + esc(achado.ex) + '</em><br><span class="msg__pt">' + esc(achado.exPt) + '</span>' +
          (achado.sin && achado.sin.length ? '<br><span class="msg__pt">Sinónimos: ' + esc(achado.sin.join(', ')) + '</span>' : '') +
          (achado.ant && achado.ant.length ? '<br><span class="msg__pt">Antónimos: ' + esc(achado.ant.join(', ')) + '</span>' : '')
      };
    }
    var rel = procurarRelacionadas(termo);
    if (rel.length) {
      return {
        en: rel.map(function (r) { return r.en; }).join(' / '),
        pt: rel.map(function (r) { return r.pt; }).join(' / '),
        pron: rel[0].pron,
        extra: 'Encontrei estas opções relacionadas. Se procuravas outra coisa, escreve a frase completa (ex.: «Como se diz <em>bom dia</em> em inglês?»).' +
          rel.map(function (r) { return '<br><em>' + esc(r.ex) + '</em> <span class="msg__pt">(' + esc(r.exPt) + ')</span>'; }).join('')
      };
    }
    return null;
  }

  function respostaSignificado(entrada) {
    var m = /(?:o\s+que\s+significa|que\s+significa|significado\s+de|what\s+does\s+(.+?)\s+mean|que\s+quer\s+dizer)\s*[:\-]?\s*["“']?([^"”'?]+?)["”']?\s*\??$/i.exec(entrada);
    if (!m) return null;
    var termo = (m[2] || m[1] || '').trim();
    if (!termo) return null;
    var achado = procurarPalavra(termo);
    if (achado) {
      return {
        en: achado.en,
        pt: achado.pt,
        pron: achado.pron,
        extra: 'Classe: ' + esc(achado.classe || '—') + ' · Exemplo: <em>' + esc(achado.ex) + '</em><br><span class="msg__pt">' + esc(achado.exPt) + '</span>'
      };
    }
    var rel = procurarRelacionadas(termo);
    if (rel.length) {
      return {
        en: rel[0].en, pt: rel[0].pt, pron: rel[0].pron,
        extra: 'Talvez procures: ' + rel.map(function (r) { return '<strong>' + esc(r.en) + '</strong> (' + esc(r.pt) + ')'; }).join(', ') + '.'
      };
    }
    return null;
  }

  function respostaGramatica(entrada) {
    var t = norm(entrada);
    for (var i = 0; i < gramatica.length; i++) {
      for (var j = 0; j < gramatica[i].chaves.length; j++) {
        if (t.indexOf(norm(gramatica[i].chaves[j])) !== -1) return gramatica[i];
      }
    }
    return null;
  }

  function parecePortugues(texto) {
    var t = ' ' + norm(texto) + ' ';
    var marcadores = [' que ', ' nao ', ' com ', ' para ', ' voce ', ' voce', ' eu ', ' meu ', ' minha ', ' isso ', ' esta ', ' estou ', ' obrigado', ' quero ', ' preciso ', ' explicar', ' como ', ' onde ', ' quando ', ' porque', ' gosto', ' hoje', ' amanha'];
    var achados = marcadores.filter(function (m) { return t.indexOf(m) !== -1; }).length;
    var ingles = [' the ', ' is ', ' are ', ' was ', ' have ', ' i ', ' you ', ' my ', ' and ', ' to ', ' of ', ' in ', ' this ', ' it '];
    var ing = ingles.filter(function (m) { return t.indexOf(m) !== -1; }).length;
    return achados > ing;
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  /* =========================================================
     6. Motor principal
     ========================================================= */
  /**
   * responde(texto, contexto) → { html, dica }
   * contexto: { modo: 'livre' | id do diálogo, passo, nomeUsuario }
   */
  function responde(texto, contexto) {
    var ctx = contexto || {};
    var entrada = String(texto || '').trim();
    var t = norm(entrada);

    if (!entrada) {
      return { html: '<p>Escreve uma pergunta ou uma frase em inglês. Estou aqui para isso. 🙂</p>' };
    }

    /* Diálogo guiado ativo */
    if (ctx.modo && ctx.modo !== 'livre' && dialogos[ctx.modo]) {
      var d = dialogos[ctx.modo];
      var passo = d.passos[Math.min(ctx.passo || 0, d.passos.length - 1)];
      var avaliacao = avaliarRespostaDialogo(entrada, passo);
      var proximo = (ctx.passo || 0) + 1;
      var fim = proximo >= d.passos.length;
      var html = '<p><span class="msg__en">' + esc(passo.ia) + '</span></p>' +
        '<p class="msg__pt">' + esc(passo.pt) + '</p>';
      if (avaliacao.ok) {
        html += '<p style="margin-top:8px">✅ <strong>Boa resposta!</strong> ' + (avaliacao.comentario || 'Está natural.') + '</p>';
      } else {
        html += '<div class="msg__correcao">💡 <strong>Sugestão:</strong> «' + esc(passo.esperado) + '».<br>' + esc(passo.dica) + '</div>';
      }
      if (fim) {
        html += '<p style="margin-top:10px"><strong>🎉 Diálogo concluído!</strong> Fizeste os ' + d.passos.length + ' passos da situação «' + d.nome + '». Repete com outras palavras para automatizar.</p>';
      } else {
        html += '<p style="margin-top:8px"><span class="msg__pt">A seguir (passo ' + (proximo + 1) + ' de ' + d.passos.length + '):</span></p>' +
          '<p><span class="msg__en">' + esc(d.passos[proximo].ia) + '</span></p>' +
          '<p class="msg__pt">' + esc(d.passos[proximo].pt) + '</p>';
      }
      return { html: html, proximoPasso: proximo, concluido: fim };
    }

    /* Saudações e small talk */
    if (/^(ola|oi|olá|bom dia|boa tarde|boa noite|hello|hi|hey|e ai|e ai!|eai)\b/.test(t) && t.length < 30) {
      var hora = new Date().getHours();
      var saud = hora < 12 ? 'Good morning' : hora < 18 ? 'Good afternoon' : 'Good evening';
      return {
        html: '<p><span class="msg__en">' + saud + (ctx.nome ? ', ' + esc(ctx.nome) : '') + '! Nice to see you.</span></p>' +
          '<p class="msg__pt">' + (hora < 12 ? 'Bom dia' : hora < 18 ? 'Boa tarde' : 'Boa noite') + '! Que bom ver-te. Vamos praticar?</p>' +
          '<p class="msg__pt">Podes: (1) pedir uma tradução — «Como se diz <em>obrigado</em> em inglês?», (2) pedir gramática — «Explica o present perfect», (3) escrever uma frase em inglês para eu corrigir.</p>'
      };
    }

    if (/(quem es tu|quem es voce|o que es tu|what are you|es um robo)/.test(t)) {
      return {
        html: '<p>Sou o <strong>Professor Fácil</strong>, o tutor virtual do English Fácil. 🤖</p>' +
          '<p class="msg__pt">Funciono com uma base de conhecimento de inglês criada para quem fala português: explicações de gramática, traduções, correções de erros típicos e diálogos de situações reais.</p>' +
          '<p class="msg__pt">Não sou uma pessoa e não tenho acesso à internet. Para dúvidas muito específicas, o melhor é falar com um professor humano.</p>'
      };
    }

    if (/(obrigad|valeu|thanks|thank you)/.test(t) && t.length < 40) {
      return {
        html: '<p><span class="msg__en">You are welcome! Keep practising.</span></p>' +
          '<p class="msg__pt">De nada! Continua a praticar. Lembra-te: <em>You are welcome</em> é a resposta padrão a «thank you».</p>'
      };
    }

    /* Pedido de diálogo */
    var pedidoDialogo = /(dialogo|diálogo|praticar|simular|situacao|situação|roleplay)/i.test(entrada);
    if (pedidoDialogo) {
      var chave = null;
      Object.keys(dialogos).forEach(function (k) {
        var dd = dialogos[k];
        if (t.indexOf(norm(k)) !== -1 || t.indexOf(norm(dd.nome).replace(/^(no|na|nas|nos)\s+/, '')) !== -1) chave = k;
      });
      if (!chave) {
        if (/restaurante|comer|comida/.test(t)) chave = 'restaurante';
        else if (/aeroporto|aviao|viagem|voo/.test(t)) chave = 'aeroporto';
        else if (/entrevista|emprego|trabalho/.test(t)) chave = 'entrevista';
        else if (/hotel|reserva/.test(t)) chave = 'hotel';
        else if (/medico|doente|hospital|saude/.test(t)) chave = 'medico';
        else if (/festa|amigos|social|conversa/.test(t)) chave = 'social';
        else if (/compras|loja|roupa/.test(t)) chave = 'loja';
      }
      if (chave) {
        var dd = dialogos[chave];
        return {
          html: '<p><strong>' + dd.icone + ' Vamos praticar: ' + esc(dd.nome) + '</strong></p>' +
            '<p class="msg__pt">Eu faço o papel da outra pessoa. Responde em inglês — se errares, dou-te a sugestão.</p>' +
            '<p style="margin-top:8px"><span class="msg__en">' + esc(dd.passos[0].ia) + '</span></p>' +
            '<p class="msg__pt">' + esc(dd.passos[0].pt) + '</p>',
          iniciarDialogo: chave
        };
      }
      return {
        html: '<p class="msg__pt">Tenho estes diálogos prontos:</p><p>' +
          Object.keys(dialogos).map(function (k) { return dialogos[k].icone + ' <strong>' + esc(dialogos[k].nome) + '</strong>'; }).join('<br>') +
          '</p><p class="msg__pt">Escreve, por exemplo: «Quero praticar uma entrevista de emprego».</p>'
      };
    }

    /* Tradução */
    var trad = respostaTraducao(entrada);
    if (trad) {
      return {
        html: '<p><span class="msg__en">' + esc(trad.en) + '</span></p>' +
          '<p class="msg__pt">' + esc(trad.pt) + '</p>' +
          (trad.pron ? '<p class="msg__pt">Pronúncia aproximada: <strong>' + esc(trad.pron) + '</strong></p>' : '') +
          (trad.extra ? '<p class="msg__pt">' + trad.extra + '</p>' : '')
      };
    }

    /* Significado */
    var sig = respostaSignificado(entrada);
    if (sig) {
      return {
        html: '<p><span class="msg__en">' + esc(sig.en) + '</span> → ' + esc(sig.pt) + '</p>' +
          (sig.pron ? '<p class="msg__pt">Pronúncia: <strong>' + esc(sig.pron) + '</strong></p>' : '') +
          (sig.extra ? '<p class="msg__pt">' + sig.extra + '</p>' : '')
      };
    }

    /* Gramática */
    var gram = respostaGramatica(entrada);
    if (gram) {
      return {
        html: '<p><strong>' + gram.titulo + '</strong></p>' +
          '<p class="msg__pt">' + gram.explicacao + '</p>' +
          '<p class="msg__pt" style="margin-top:8px"><strong>Exemplos:</strong></p>' +
          gram.exemplos.map(function (e) {
            return '<p class="msg__pt"><span class="msg__en">' + esc(e.en) + '</span><br>' + esc(e.pt) + '</p>';
          }).join('') +
          '<div class="msg__correcao">⚠️ ' + gram.nota + '</div>'
      };
    }

    /* Pedido explícito de correção */
    var pedidoCorrecao = /(esta correto|esta certo|corrige|corrija|correcao|verifica|revisa|posso dizer|posso falar)/i.test(entrada);
    if (pedidoCorrecao) {
      var fraseAlvo = entrada.replace(/^(.+?)(esta correto|esta certo|corrige|corrija|correcao de|verifica|revisa|posso dizer|posso falar)[:\s]*/i, '').replace(/[?]+$/, '').trim();
      if (fraseAlvo && fraseAlvo.split(/\s+/).length >= 2 && !parecePortugues(fraseAlvo)) {
        var c = corrigirFrase(fraseAlvo);
        return { html: htmlCorrecao(c) };
      }
      return {
        html: '<p class="msg__pt">Escreve a frase em inglês que queres verificar. Por exemplo:</p>' +
          '<p><span class="msg__en">I go to school yesterday.</span></p>' +
          '<p class="msg__pt">Eu corrijo e explico o motivo de cada alteração.</p>'
      };
    }

    /* Frase em inglês → avaliar/corrigir */
    if (!parecePortugues(entrada) && entrada.split(/\s+/).length >= 2) {
      var corr = corrigirFrase(entrada);
      if (corr.notas.length) return { html: htmlCorrecao(corr) };
      /* Sem erros detetados: elogiar + responder ao conteúdo */
      var resposta = responderConteudo(entrada, t);
      return {
        html: '<p>✅ <strong>Boa frase!</strong> Não encontrei erros.</p>' +
          '<p class="msg__pt">Estrutura reconhecida. ' + resposta + '</p>' +
          '<p class="msg__pt">Continua a escrever — quanto mais frases fizeres, mais rápido automatizas.</p>'
      };
    }

    /* Perguntas em português sem padrão reconhecido */
    if (/(como|onde|quando|porque|por que|qual|quais|quanto|quantos)\b/.test(t)) {
      var rel2 = procurarRelacionadas(t.replace(/[?]/g, '').split(/\s+/).filter(function (w) { return w.length > 4; })[0] || '');
      if (rel2.length) {
        return {
          html: '<p class="msg__pt">Não percebi a pergunta exatamente, mas pode ser sobre isto:</p>' +
            rel2.map(function (r) {
              return '<p class="msg__pt"><span class="msg__en">' + esc(r.en) + '</span> — ' + esc(r.pt) + '<br><em>' + esc(r.ex) + '</em></p>';
            }).join('') +
            '<p class="msg__pt">Tenta ser mais específico: «Como se diz <em>agradecer</em> em inglês?» ou «Explica o past simple».</p>'
        };
      }
    }

    /* Fallback com ajuda */
    return {
      html: '<p class="msg__pt">Ainda estou a aprender a responder a tudo, mas posso ajudar-te de várias formas:</p>' +
        '<ul class="msg__pt" style="padding-left:18px;margin:8px 0">' +
          '<li>«Como se diz <em>bom dia</em> em inglês?»</li>' +
          '<li>«O que significa <em>deadline</em>?»</li>' +
          '<li>«Explica o present perfect»</li>' +
          '<li>«Quero praticar uma entrevista»</li>' +
          '<li>Escreve uma frase em inglês e eu corrijo</li>' +
        '</ul><p class="msg__pt">Ou tenta reformular a tua pergunta com outras palavras.</p>'
    };
  }

  function htmlCorrecao(c) {
    var html = '<p>📝 <strong>Vamos verificar:</strong></p>' +
      '<p class="msg__pt" style="text-decoration:line-through;opacity:.65">' + esc(c.original) + '</p>' +
      '<p><span class="msg__en">' + esc(c.corrigida) + '</span></p>';
    c.notas.slice(0, 4).forEach(function (n) {
      html += '<div class="msg__correcao">' +
        (n.antes ? '«' + esc(n.antes) + '» → «' + esc(n.depois) + '»<br>' : '') + n.nota + '</div>';
    });
    html += '<p class="msg__pt">Pequenos erros são normais. O importante é que já estás a construir frases.</p>';
    return html;
  }

  function responderConteudo(entrada, t) {
    if (/how are you/i.test(entrada)) return 'Respondo também: I am fine, thank you. And you?';
    if (/my name is|i am from|i live in/i.test(entrada)) return 'Apresentação clara e correta. Muito bem!';
    if (/\?$/.test(entrada)) return 'Pergunta bem formulada. Em inglês, a entonação sobe no fim de perguntas de sim/não.';
    return 'Continua: acrescenta um detalhe (onde, quando, porquê) para tornar a frase mais rica.';
  }

  /* Avalia resposta dentro de um diálogo */
  function avaliarRespostaDialogo(entrada, passo) {
    var e = norm(entrada);
    var esperado = norm(passo.esperado);
    var palavrasEsperadas = esperado.split(/\s+/).filter(function (w) { return w.length > 3; });
    var acertos = palavrasEsperadas.filter(function (w) { return e.indexOf(w) !== -1; }).length;
    var racio = palavrasEsperadas.length ? acertos / palavrasEsperadas.length : 0;

    var corr = corrigirFrase(entrada);
    if (corr.notas.length && /(i go|didn'?t went|i have \d+ years|he don'?t|she don'?t)/i.test(entrada)) {
      return { ok: false, comentario: 'Atenção à gramática: ' + corr.notas[0].nota };
    }
    if (racio >= 0.4) return { ok: true, comentario: racio >= 0.8 ? 'Quase idêntico à resposta modelo.' : 'Comunica bem o essencial.' };
    return { ok: false };
  }

  window.EF.professor = {
    responde: responde,
    corrigirFrase: corrigirFrase,
    dialogos: dialogos,
    gramatica: gramatica,
    procurarPalavra: procurarPalavra
  };
})();
