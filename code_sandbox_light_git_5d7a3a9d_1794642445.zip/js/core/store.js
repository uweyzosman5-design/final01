/* ============================================================
   English Fácil — Núcleo de dados (contas, progresso, gamificação)
   Persistência local por dispositivo + ranking partilhado via Table API.
   ============================================================ */
window.EF = window.EF || {};

(function () {
  'use strict';

  var CHAVE = 'englishfacil:v1';
  var MAX_CHAT_DIA = 10;

  var estadoInicial = function () {
    return {
      versao: 1,
      usuarios: {},
      sessaoId: null,
      config: { tema: 'claro', notificacoes: false, voz: null },
      rankingEnviado: {}
    };
  };

  var estado = null;

  /* ---------- Persistência ---------- */
  function carregar() {
    if (estado) return estado;
    try {
      var bruto = localStorage.getItem(CHAVE);
      if (bruto) {
        var lido = JSON.parse(bruto);
        if (lido && typeof lido === 'object' && lido.usuarios) {
          estado = Object.assign(estadoInicial(), lido);
          estado.config = Object.assign({ tema: 'claro', notificacoes: false, voz: null }, lido.config || {});
          return estado;
        }
      }
    } catch (e) {
      console.warn('Falha ao ler dados locais:', e);
    }
    estado = estadoInicial();
    return estado;
  }

  function guardar() {
    try {
      localStorage.setItem(CHAVE, JSON.stringify(estado));
      document.dispatchEvent(new CustomEvent('ef:estado'));
      return true;
    } catch (e) {
      console.warn('Falha ao guardar dados locais:', e);
      return false;
    }
  }

  /* ---------- Hash de palavra-passe ---------- */
  function hashSimples(texto) {
    var h1 = 0x811c9dc5, h2 = 0x01000193;
    for (var i = 0; i < texto.length; i++) {
      var c = texto.charCodeAt(i);
      h1 = (h1 ^ c) * 16777619 >>> 0;
      h2 = ((h2 << 5) + h2 + c) >>> 0;
    }
    return ('00000000' + h1.toString(16)).slice(-8) + ('00000000' + h2.toString(16)).slice(-8);
  }

  function derivarHash(senha, salt) {
    var texto = salt + '::' + senha + '::englishfacil';
    if (window.crypto && window.crypto.subtle && window.crypto.subtle.digest) {
      return window.crypto.subtle.digest('SHA-256', new TextEncoder().encode(texto)).then(function (buf) {
        return Array.prototype.map.call(new Uint8Array(buf), function (b) {
          return ('0' + b.toString(16)).slice(-2);
        }).join('');
      }).catch(function () { return hashSimples(texto); });
    }
    return Promise.resolve(hashSimples(texto));
  }

  function novoId() {
    if (window.crypto && window.crypto.randomUUID) return window.crypto.randomUUID();
    return 'u' + Date.now().toString(36) + Math.random().toString(36).slice(2, 9);
  }

  function hojeISO() {
    var d = new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  }

  function diasEntre(a, b) {
    var pa = a.split('-').map(Number), pb = b.split('-').map(Number);
    var da = new Date(pa[0], pa[1] - 1, pa[2]);
    var db = new Date(pb[0], pb[1] - 1, pb[2]);
    return Math.round((db - da) / 86400000);
  }

  /* ---------- Contas ---------- */
  function normalizarEmail(e) { return String(e || '').trim().toLowerCase(); }

  function registar(nome, email, senha, nivel) {
    carregar();
    var mail = normalizarEmail(email);
    if (!nome || nome.trim().length < 2) return Promise.reject(new Error('Escreve o teu nome (mínimo 2 letras).'));
    if (!/^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(mail)) return Promise.reject(new Error('Email inválido.'));
    if (!senha || senha.length < 4) return Promise.reject(new Error('A palavra-passe precisa de pelo menos 4 caracteres.'));
    var existe = Object.keys(estado.usuarios).some(function (k) { return estado.usuarios[k].email === mail; });
    if (existe) return Promise.reject(new Error('Já existe uma conta com este email neste dispositivo.'));

    var salt = novoId();
    return derivarHash(senha, salt).then(function (hash) {
      var id = novoId();
      var user = {
        id: id,
        nome: nome.trim(),
        email: mail,
        salt: salt,
        hash: hash,
        nivel: nivel || 'iniciante',
        criadoEm: Date.now(),
        pontos: 0,
        licoes: {},
        favoritos: [],
        medalhas: [],
        testes: [],
        dias: [],
        chat: 0,
        chatDia: { data: hojeISO(), n: 0 },
        notificacoesVistas: [],
        enviosRanking: {}
      };
      estado.usuarios[id] = user;
      estado.sessaoId = id;
      guardar();
      return user;
    });
  }

  function entrar(email, senha) {
    carregar();
    var mail = normalizarEmail(email);
    var user = Object.keys(estado.usuarios).map(function (k) { return estado.usuarios[k]; })
      .filter(function (u) { return u.email === mail; })[0];
    if (!user) return Promise.reject(new Error('Não encontrámos nenhuma conta com este email neste dispositivo.'));
    return derivarHash(senha, user.salt).then(function (hash) {
      if (hash !== user.hash) throw new Error('Palavra-passe incorreta.');
      estado.sessaoId = user.id;
      guardar();
      return user;
    });
  }

  function sair() {
    carregar();
    estado.sessaoId = null;
    guardar();
  }

  function utilizador() {
    carregar();
    return estado.sessaoId ? estado.usuarios[estado.sessaoId] || null : null;
  }

  function atualizar(mutacao) {
    var u = utilizador();
    if (!u) return null;
    mutacao(u);
    guardar();
    return u;
  }

  /* ---------- Pontos, sequência e medalhas ---------- */
  function pontosDoNivel(pontos) {
    return (window.EF.nivelDePontos ? window.EF.nivelDePontos(pontos) : { atual: { nome: 'Curioso', icone: '🌱' }, proximo: null });
  }

  function adicionarPontos(n) {
    return atualizar(function (u) { u.pontos = Math.max(0, (u.pontos || 0) + n); });
  }

  function marcarDia() {
    var hoje = hojeISO();
    return atualizar(function (u) {
      if (!Array.isArray(u.dias)) u.dias = [];
      if (u.dias.indexOf(hoje) === -1) u.dias.push(hoje);
      u.dias = u.dias.slice(-400);
    });
  }

  function sequencia(u) {
    if (!u || !Array.isArray(u.dias) || !u.dias.length) return 0;
    var ordenados = u.dias.slice().sort();
    var ultimo = ordenados[ordenados.length - 1];
    var hoje = hojeISO();
    var diff = diasEntre(ultimo, hoje);
    if (diff > 1) return 0;
    var total = 1;
    for (var i = ordenados.length - 1; i > 0; i--) {
      if (diasEntre(ordenados[i - 1], ordenados[i]) === 1) total++;
      else break;
    }
    return total;
  }

  function recordeSequencia(u) {
    if (!u || !Array.isArray(u.dias) || !u.dias.length) return 0;
    var ordenados = u.dias.slice().sort();
    var melhor = 1, atual = 1;
    for (var i = 1; i < ordenados.length; i++) {
      if (diasEntre(ordenados[i - 1], ordenados[i]) === 1) atual++;
      else atual = 1;
      if (atual > melhor) melhor = atual;
    }
    return melhor;
  }

  function ultimosSete(u) {
    var dias = (u && u.dias) || [];
    var out = [];
    for (var i = 6; i >= 0; i--) {
      var d = new Date();
      d.setDate(d.getDate() - i);
      var iso = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
      out.push({ iso: iso, feito: dias.indexOf(iso) !== -1, letra: ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'][d.getDay()] });
    }
    return out;
  }

  function licaoConcluida(u, id) {
    return !!(u && u.licoes && u.licoes[id] && u.licoes[id].concluida);
  }

  function concluirLicao(id, acertos, total) {
    var ganhos = 0;
    var novasMedalhas = [];
    atualizar(function (u) {
      var licoes = window.EF.licoes || [];
      var licao = licoes.filter(function (l) { return l.id === id; })[0];
      if (!licao) return;
      if (!u.licoes[id]) u.licoes[id] = { concluida: false, tentativas: 0, melhor: 0 };
      var reg = u.licoes[id];
      var primeira = !reg.concluida;
      reg.tentativas = (reg.tentativas || 0) + 1;
      reg.concluida = true;
      reg.data = Date.now();
      var pct = total ? Math.round((acertos / total) * 100) : 100;
      reg.melhor = Math.max(reg.melhor || 0, pct);
      if (primeira) {
        ganhos = 20 + Math.round(pct / 10); // 20 base + até 10 de bónus
        u.pontos = (u.pontos || 0) + ganhos;
      }
      if (!Array.isArray(u.dias)) u.dias = [];
      var hoje = hojeISO();
      if (u.dias.indexOf(hoje) === -1) u.dias.push(hoje);
      novasMedalhas = avaliarMedalhas(u);
    });
    return { pontos: ganhos, medalhas: novasMedalhas };
  }

  function registarTeste(resultado) {
    var novas = [];
    atualizar(function (u) {
      if (!Array.isArray(u.testes)) u.testes = [];
      u.testes.push(resultado);
      u.testes = u.testes.slice(-60);
      var hoje = hojeISO();
      if (!Array.isArray(u.dias)) u.dias = [];
      if (u.dias.indexOf(hoje) === -1) u.dias.push(hoje);
      novas = avaliarMedalhas(u);
    });
    return novas;
  }

  function avaliarMedalhas(u) {
    if (!window.EF.medalhas) return [];
    var licoes = window.EF.licoes || [];
    var feitas = Object.keys(u.licoes || {}).filter(function (k) { return u.licoes[k].concluida; });
    var ganhas = [];
    var tem = function (id) { return (u.medalhas || []).indexOf(id) !== -1; };
    var dar = function (id) {
      if (!tem(id)) { u.medalhas = u.medalhas || []; u.medalhas.push(id); ganhas.push(id); }
    };

    if (feitas.length >= 1) dar('primeiro-passo');
    if (feitas.length >= 5) dar('cinco-aulas');
    if (feitas.length >= 10) dar('dez-aulas');
    if ((u.pontos || 0) >= 100) dar('cem-pontos');
    if ((u.pontos || 0) >= 1000) dar('mil-pontos');
    if ((u.favoritos || []).length >= 10) dar('dicionario');
    if ((u.chat || 0) >= 10) dar('conversador');
    if ((u.testes || []).some(function (t) { return t.total && t.acertos === t.total; })) dar('teste-perfeito');

    var seq = sequencia(u);
    if (seq >= 3) dar('sequencia-3');
    if (seq >= 7) dar('sequencia-7');
    if (seq >= 30) dar('sequencia-30');

    ['iniciante', 'intermediario', 'avancado'].forEach(function (niv) {
      var doNivel = licoes.filter(function (l) { return l.nivel === niv; });
      if (doNivel.length && doNivel.every(function (l) { return licoes && u.licoes[l.id] && u.licoes[l.id].concluida; })) {
        dar('todas-' + niv);
      }
    });
    return ganhas;
  }

  /* ---------- Favoritos ---------- */
  function alternarFavorito(palavra) {
    var resultado = { ativo: false };
    atualizar(function (u) {
      if (!Array.isArray(u.favoritos)) u.favoritos = [];
      var i = u.favoritos.indexOf(palavra);
      if (i === -1) { u.favoritos.push(palavra); resultado.ativo = true; }
      else { u.favoritos.splice(i, 1); resultado.ativo = false; }
      resultado.medalhas = avaliarMedalhas(u);
    });
    return resultado;
  }

  function ehFavorito(palavra) {
    var u = utilizador();
    return !!(u && Array.isArray(u.favoritos) && u.favoritos.indexOf(palavra) !== -1);
  }

  /* ---------- Progresso ---------- */
  function progressoNivel(nivelId) {
    var u = utilizador();
    var licoes = (window.EF.licoes || []).filter(function (l) { return l.nivel === nivelId; });
    var feitas = licoes.filter(function (l) { return licaoConcluida(u, l.id); }).length;
    return { feitas: feitas, total: licoes.length, pct: licoes.length ? Math.round((feitas / licoes.length) * 100) : 0 };
  }

  function progressoGeral() {
    var u = utilizador();
    var licoes = window.EF.licoes || [];
    var feitas = licoes.filter(function (l) { return licaoConcluida(u, l.id); }).length;
    return { feitas: feitas, total: licoes.length, pct: licoes.length ? Math.round((feitas / licoes.length) * 100) : 0 };
  }

  function proximaLicao() {
    var u = utilizador();
    var licoes = window.EF.licoes || [];
    var doNivel = licoes.filter(function (l) { return l.nivel === (u && u.nivel ? u.nivel : 'iniciante'); });
    var lista = doNivel.length ? doNivel : licoes;
    for (var i = 0; i < lista.length; i++) {
      if (!licaoConcluida(u, lista[i].id)) return lista[i];
    }
    for (var j = 0; j < licoes.length; j++) {
      if (!licaoConcluida(u, licoes[j].id)) return licoes[j];
    }
    return licoes[0] || null;
  }

  /* ---------- Configuração ---------- */
  function tema() { return carregar().config.tema || 'claro'; }
  function definirTema(t) { estado.config.tema = t; guardar(); }
  function configurar(chave, valor) { estado.config[chave] = valor; guardar(); }

  function chatHoje() {
    var u = utilizador();
    if (!u) return { usado: 0, maximo: MAX_CHAT_DIA };
    if (!u.chatDia || u.chatDia.data !== hojeISO()) { u.chatDia = { data: hojeISO(), n: 0 }; guardar(); }
    return { usado: u.chatDia.n, maximo: MAX_CHAT_DIA };
  }

  function registarMensagemChat() {
    var novas = [];
    atualizar(function (u) {
      if (!u.chatDia || u.chatDia.data !== hojeISO()) u.chatDia = { data: hojeISO(), n: 0 };
      u.chatDia.n += 1;
      u.chat = (u.chat || 0) + 1;
      if (u.chatDia.n <= MAX_CHAT_DIA) {
        u.pontos = (u.pontos || 0) + 1;
      }
      var hoje = hojeISO();
      if (!Array.isArray(u.dias)) u.dias = [];
      if (u.dias.indexOf(hoje) === -1) u.dias.push(hoje);
      novas = avaliarMedalhas(u);
    });
    return novas;
  }

  /* ---------- Ranking partilhado (Table API) ---------- */
  function enviarParaRanking(forcar) {
    var u = utilizador();
    if (!u) return Promise.resolve(null);
    var ja = estado.rankingEnviado && estado.rankingEnviado[u.id];
    if (!forcar && ja && (Date.now() - ja) < 1000 * 60 * 5) return Promise.resolve(null);
    var corpo = {
      nome: u.nome,
      pontos: u.pontos || 0,
      nivel: u.nivel || 'iniciante',
      licoes: progressoGeral().feitas,
      sequencia: sequencia(u)
    };
    return fetch('tables/ranking', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(corpo)
    }).then(function (r) {
      if (!r.ok) throw new Error('ranking ' + r.status);
      estado.rankingEnviado[u.id] = Date.now();
      guardar();
      return r.json();
    }).catch(function (e) {
      console.warn('Ranking não disponível:', e.message);
      return null;
    });
  }

  function lerRanking(limite) {
    var n = limite || 100;
    /* Tenta com ordenação; se a API não suportar, recorre sem sort e ordena no cliente. */
    return fetch('tables/ranking?limit=' + n + '&sort=-pontos').then(function (r) {
      if (r.ok) return r.json();
      return fetch('tables/ranking').then(function (r2) {
        if (!r2.ok) throw new Error('ranking ' + r2.status);
        return r2.json();
      });
    }).then(function (dados) {
      var linhas = (dados && dados.data) || [];
      return linhas.slice().sort(function (a, b) { return (b.pontos || 0) - (a.pontos || 0); });
    }).catch(function (e) {
      console.warn('Ranking indisponível:', e.message);
      return [];
    });
  }

  function atualizarNivel(nivel) {
    return atualizar(function (u) { u.nivel = nivel; });
  }

  function apagarConta() {
    var u = utilizador();
    if (!u) return false;
    delete estado.usuarios[u.id];
    estado.sessaoId = null;
    guardar();
    return true;
  }

  window.EF.store = {
    carregar: carregar,
    guardar: guardar,
    registar: registar,
    entrar: entrar,
    sair: sair,
    utilizador: utilizador,
    atualizar: atualizar,
    adicionarPontos: adicionarPontos,
    marcarDia: marcarDia,
    sequencia: sequencia,
    recordeSequencia: recordeSequencia,
    ultimosSete: ultimosSete,
    licaoConcluida: licaoConcluida,
    concluirLicao: concluirLicao,
    registarTeste: registarTeste,
    avaliarMedalhas: avaliarMedalhas,
    alternarFavorito: alternarFavorito,
    ehFavorito: ehFavorito,
    progressoNivel: progressoNivel,
    progressoGeral: progressoGeral,
    proximaLicao: proximaLicao,
    pontosDoNivel: pontosDoNivel,
    tema: tema,
    definirTema: definirTema,
    configurar: configurar,
    chatHoje: chatHoje,
    registarMensagemChat: registarMensagemChat,
    enviarParaRanking: enviarParaRanking,
    lerRanking: lerRanking,
    atualizarNivel: atualizarNivel,
    apagarConta: apagarConta,
    hojeISO: hojeISO,
    MAX_CHAT_DIA: MAX_CHAT_DIA,
    _estado: function () { return estado; }
  };
})();
