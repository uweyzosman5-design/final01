/* ============================================================
   English Fácil — UI partilhada: cabeçalho, rodapé, modal, toast
   ============================================================ */
window.EF = window.EF || {};

(function () {
  'use strict';

  var links = [
    { href: 'index.html', txt: 'Início', chave: 'inicio' },
    { href: 'cursos.html', txt: 'Cursos', chave: 'cursos' },
    { href: 'exercicios.html', txt: 'Exercícios', chave: 'exercicios' },
    { href: 'conversacao.html', txt: 'Conversação', chave: 'conversacao' },
    { href: 'dicionario.html', txt: 'Dicionário', chave: 'dicionario' },
    { href: 'painel.html', txt: 'Meu Progresso', chave: 'painel' }
  ];

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function logoHTML() {
    return '<a class="logo" href="index.html" aria-label="English Fácil — página inicial">' +
      '<span class="logo__marca" aria-hidden="true"><span>EF</span></span>' +
      '<span class="logo__txt">English Fácil<small>Aprende inglês</small></span></a>';
  }

  function construirCabecalho(pagina) {
    var nav = links.map(function (l) {
      return '<a class="nav__link" href="' + l.href + '"' + (l.chave === pagina ? ' aria-current="page"' : '') + '>' + l.txt + '</a>';
    }).join('');

    var u = window.EF.store.utilizador();
    var acao = u
      ? '<a class="btn btn--pequeno btn--entrar" href="painel.html"><i class="fa-regular fa-user" aria-hidden="true"></i> ' + esc(u.nome.split(' ')[0]) + '</a>'
      : '<button class="btn btn--pequeno btn--entrar" type="button" data-abrir-login>Entrar</button>';

    var acaoMobile = u
      ? ''
      : '<button class="btn btn--entrar-mobile btn--bloco" type="button" data-abrir-login>Entrar / Criar conta</button>';

    return '<header class="cabecalho"><div class="container cabecalho__inner">' +
      logoHTML() +
      '<nav class="nav" id="navPrincipal" aria-label="Navegação principal">' + nav + acaoMobile + '</nav>' +
      '<div class="cabecalho__acoes">' +
        '<button class="btn-icone" type="button" id="btnTema" aria-label="Alternar modo escuro" title="Modo escuro">' +
          '<i class="fa-solid fa-moon" aria-hidden="true"></i></button>' +
        acao +
        '<button class="btn-icone menu-mobile" type="button" id="btnMenu" aria-label="Abrir menu" aria-expanded="false" aria-controls="navPrincipal">' +
          '<i class="fa-solid fa-bars" aria-hidden="true"></i></button>' +
      '</div></div></header>';
  }

  function construirRodape() {
    return '<footer class="rodape"><div class="container">' +
      '<div class="rodape__grelha">' +
        '<div>' + logoHTML() +
          '<p class="mt-10">Plataforma gratuita para aprender inglês do zero ao avançado, pensada para quem fala português de Moçambique, Portugal e Brasil.</p>' +
        '</div>' +
        '<div><h4>Aprender</h4>' +
          '<a href="cursos.html?nivel=iniciante">Nível Iniciante (A1–A2)</a>' +
          '<a href="cursos.html?nivel=intermediario">Nível Intermédio (B1–B2)</a>' +
          '<a href="cursos.html?nivel=avancado">Nível Avançado (C1–C2)</a>' +
          '<a href="cursos.html?nivel=real">Situações reais</a>' +
        '</div>' +
        '<div><h4>Praticar</h4>' +
          '<a href="exercicios.html">Exercícios interativos</a>' +
          '<a href="conversacao.html">Professor virtual</a>' +
          '<a href="dicionario.html">Dicionário</a>' +
          '<a href="painel.html">O meu progresso</a>' +
        '</div>' +
        '<div><h4>Sobre</h4>' +
          '<a href="index.html#vantagens">Porquê o English Fácil</a>' +
          '<a href="index.html#depoimentos">Alunos</a>' +
          '<a href="admin.html">Administração</a>' +
          '<a href="index.html#faq">Perguntas frequentes</a>' +
        '</div>' +
      '</div>' +
      '<div class="rodape__base"><span>© ' + new Date().getFullYear() + ' English Fácil. Feito para quem fala português.</span>' +
      '<span>Estudar 15 minutos por dia muda tudo.</span></div>' +
      '</div></footer>';
  }

  /* ---------- Toasts ---------- */
  function toast(mensagem, tipo) {
    var caixa = document.getElementById('toasts');
    if (!caixa) {
      caixa = document.createElement('div');
      caixa.id = 'toasts';
      caixa.setAttribute('role', 'status');
      caixa.setAttribute('aria-live', 'polite');
      document.body.appendChild(caixa);
    }
    var el = document.createElement('div');
    el.className = 'toast' + (tipo ? ' toast--' + tipo : '');
    var icone = tipo === 'ok' ? 'fa-circle-check' : tipo === 'erro' ? 'fa-circle-exclamation' : 'fa-circle-info';
    el.innerHTML = '<i class="fa-solid ' + icone + '" aria-hidden="true"></i><span>' + esc(mensagem) + '</span>';
    caixa.appendChild(el);
    setTimeout(function () {
      el.style.transition = 'opacity .3s, transform .3s';
      el.style.opacity = '0';
      el.style.transform = 'translateX(30px)';
      setTimeout(function () { el.remove(); }, 320);
    }, 3800);
  }

  /* ---------- Modal genérico ---------- */
  function fecharModal() {
    var m = document.querySelector('.modal-fundo');
    if (m) m.remove();
    document.body.style.overflow = '';
  }

  function abrirModal(html, opcoes) {
    fecharModal();
    var opt = opcoes || {};
    var fundo = document.createElement('div');
    fundo.className = 'modal-fundo';
    fundo.setAttribute('role', 'dialog');
    fundo.setAttribute('aria-modal', 'true');
    fundo.innerHTML = '<div class="modal" style="position:relative">' +
      '<button class="btn-icone modal__fechar" type="button" aria-label="Fechar janela" data-fechar-modal>' +
      '<i class="fa-solid fa-xmark" aria-hidden="true"></i></button>' + html + '</div>';
    document.body.appendChild(fundo);
    document.body.style.overflow = 'hidden';
    fundo.addEventListener('click', function (e) {
      if (e.target === fundo || e.target.closest('[data-fechar-modal]')) fecharModal();
    });
    document.addEventListener('keydown', function escuta(ev) {
      if (ev.key === 'Escape') { fecharModal(); document.removeEventListener('keydown', escuta); }
    });
    var primeiro = fundo.querySelector('input, select, textarea, button:not(.modal__fechar)');
    if (primeiro && opt.focar !== false) setTimeout(function () { primeiro.focus(); }, 80);
    return fundo;
  }

  /* ---------- Login / Registo ---------- */
  function abrirLogin(aba) {
    var html = '<h2 id="tituloLogin">Bem-vindo de volta</h2>' +
      '<p class="pequeno muted mb-20">Guarda o teu progresso, medalhas e palavras favoritas.</p>' +
      '<div class="abas" role="tablist">' +
        '<button class="aba' + (aba !== 'registo' ? ' ativa' : '') + '" type="button" data-aba="entrar" role="tab">Entrar</button>' +
        '<button class="aba' + (aba === 'registo' ? ' ativa' : '') + '" type="button" data-aba="registo" role="tab">Criar conta</button>' +
      '</div>' +
      '<form id="formAuth" novalidate>' +
        '<div class="campo escondido" data-campo="nome">' +
          '<label for="authNome">Como te chamas?</label>' +
          '<input id="authNome" name="nome" type="text" autocomplete="name" placeholder="Ex.: Ana Silva">' +
        '</div>' +
        '<div class="campo"><label for="authEmail">Email</label>' +
          '<input id="authEmail" name="email" type="email" autocomplete="email" placeholder="o.teu@email.com" required></div>' +
        '<div class="campo"><label for="authSenha">Palavra-passe</label>' +
          '<input id="authSenha" name="senha" type="password" autocomplete="current-password" placeholder="Mínimo 4 caracteres" required>' +
          '<div class="campo__dica">Fica guardada neste dispositivo, protegida por hash.</div></div>' +
        '<div class="campo escondido" data-campo="nivel">' +
          '<label for="authNivel">Qual é o teu nível de inglês?</label>' +
          '<select id="authNivel" name="nivel">' +
            '<option value="iniciante">Iniciante — estou a começar do zero</option>' +
            '<option value="intermediario">Intermédio — já entendo algumas coisas</option>' +
            '<option value="avancado">Avançado — quero refinar</option>' +
            '<option value="real">Situações reais — quero usar já</option>' +
          '</select></div>' +
        '<div id="authErro" class="feedback feedback--erro escondido" role="alert"></div>' +
        '<button class="btn btn--bloco mt-10" type="submit" id="authEnviar">Entrar</button>' +
      '</form>' +
      '<p class="pequeno muted text-center mt-20 mb-0">As tuas contas são guardadas apenas neste dispositivo. O ranking é partilhado.</p>';

    var modal = abrirModal(html);
    var modo = aba === 'registo' ? 'registo' : 'entrar';

    function sincronizarModo() {
      modal.querySelectorAll('.aba').forEach(function (b) {
        b.classList.toggle('ativa', b.getAttribute('data-aba') === modo);
      });
      modal.querySelector('[data-campo="nome"]').classList.toggle('escondido', modo !== 'registo');
      modal.querySelector('[data-campo="nivel"]').classList.toggle('escondido', modo !== 'registo');
      modal.querySelector('#tituloLogin').textContent = modo === 'registo' ? 'Cria a tua conta' : 'Bem-vindo de volta';
      modal.querySelector('#authEnviar').textContent = modo === 'registo' ? 'Criar conta grátis' : 'Entrar';
      modal.querySelector('#authSenha').setAttribute('autocomplete', modo === 'registo' ? 'new-password' : 'current-password');
    }
    sincronizarModo();

    modal.querySelectorAll('.aba').forEach(function (b) {
      b.addEventListener('click', function () { modo = b.getAttribute('data-aba'); sincronizarModo(); });
    });

    modal.querySelector('#formAuth').addEventListener('submit', function (ev) {
      ev.preventDefault();
      var erro = modal.querySelector('#authErro');
      var botao = modal.querySelector('#authEnviar');
      erro.classList.add('escondido');
      botao.disabled = true;
      var nome = modal.querySelector('#authNome').value;
      var email = modal.querySelector('#authEmail').value;
      var senha = modal.querySelector('#authSenha').value;
      var nivel = modal.querySelector('#authNivel').value;

      var promessa = modo === 'registo'
        ? window.EF.store.registar(nome, email, senha, nivel)
        : window.EF.store.entrar(email, senha);

      promessa.then(function (u) {
        fecharModal();
        toast(modo === 'registo' ? 'Conta criada! Bem-vindo, ' + u.nome.split(' ')[0] + '.' : 'Sessão iniciada. Bom estudo!', 'ok');
        window.EF.store.marcarDia();
        setTimeout(function () { window.location.reload(); }, 450);
      }).catch(function (e) {
        erro.textContent = e.message;
        erro.classList.remove('escondido');
        botao.disabled = false;
      });
    });
  }

  /* ---------- Tema ---------- */
  function aplicarTema() {
    var t = window.EF.store.tema();
    document.documentElement.setAttribute('data-tema', t);
    var btn = document.getElementById('btnTema');
    if (btn) {
      btn.innerHTML = '<i class="fa-solid fa-' + (t === 'escuro' ? 'sun' : 'moon') + '" aria-hidden="true"></i>';
      btn.setAttribute('aria-label', t === 'escuro' ? 'Ativar modo claro' : 'Ativar modo escuro');
    }
  }

  function alternarTema() {
    var novo = window.EF.store.tema() === 'escuro' ? 'claro' : 'escuro';
    window.EF.store.definirTema(novo);
    aplicarTema();
  }

  /* ---------- Inicialização ---------- */
  function iniciar(pagina) {
    var cab = document.getElementById('cabecalho');
    if (cab) cab.outerHTML = construirCabecalho(pagina);
    var rod = document.getElementById('rodape');
    if (rod) rod.outerHTML = construirRodape();

    aplicarTema();

    var btnTema = document.getElementById('btnTema');
    if (btnTema) btnTema.addEventListener('click', alternarTema);

    var btnMenu = document.getElementById('btnMenu');
    var nav = document.getElementById('navPrincipal');
    if (btnMenu && nav) {
      btnMenu.addEventListener('click', function () {
        var aberto = nav.classList.toggle('aberto');
        btnMenu.setAttribute('aria-expanded', aberto ? 'true' : 'false');
        btnMenu.innerHTML = '<i class="fa-solid fa-' + (aberto ? 'xmark' : 'bars') + '" aria-hidden="true"></i>';
      });
      nav.addEventListener('click', function (e) {
        if (e.target.closest('.nav__link') && nav.classList.contains('aberto')) {
          nav.classList.remove('aberto');
          btnMenu.setAttribute('aria-expanded', 'false');
          btnMenu.innerHTML = '<i class="fa-solid fa-bars" aria-hidden="true"></i>';
        }
      });
    }

    document.addEventListener('click', function (e) {
      var alvo = e.target.closest('[data-abrir-login]');
      if (alvo) {
        e.preventDefault();
        abrirLogin(alvo.getAttribute('data-aba') || 'entrar');
      }
    });

    /* Animação de entrada por scroll */
    if ('IntersectionObserver' in window) {
      var obs = new IntersectionObserver(function (entradas) {
        entradas.forEach(function (en) {
          if (en.isIntersecting) { en.target.classList.add('visivel'); obs.unobserve(en.target); }
        });
      }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
      document.querySelectorAll('.reveal').forEach(function (el) { obs.observe(el); });
    } else {
      document.querySelectorAll('.reveal').forEach(function (el) { el.classList.add('visivel'); });
    }

    /* Contadores animados */
    document.querySelectorAll('[data-contar]').forEach(function (el) {
      var alvo = parseFloat(el.getAttribute('data-contar')) || 0;
      var sufixo = el.getAttribute('data-sufixo') || '';
      var inicio = performance.now();
      var dur = 1400;
      function passo(t) {
        var p = Math.min(1, (t - inicio) / dur);
        var eased = 1 - Math.pow(1 - p, 3);
        var val = Math.round(alvo * eased);
        el.textContent = val.toLocaleString('pt-PT') + sufixo;
        if (p < 1) requestAnimationFrame(passo);
      }
      requestAnimationFrame(passo);
    });

    /* Notificações de estudo */
    agendarNotificacoes();

    document.dispatchEvent(new CustomEvent('ef:ui-pronto'));
  }

  function agendarNotificacoes() {
    var u = window.EF.store.utilizador();
    if (!u) return;
    var cfg = window.EF.store.carregar().config;
    if (!cfg.notificacoes) return;
    if (!('Notification' in window) || Notification.permission !== 'granted') return;
    var hoje = window.EF.store.hojeISO();
    var estudou = (u.dias || []).indexOf(hoje) !== -1;
    if (!estudou) {
      setTimeout(function () {
        try {
          new Notification('English Fácil', { body: 'Ainda não estudaste hoje. Cinco minutos contam!', icon: 'favicon.svg' });
        } catch (e) {}
      }, 4000);
    }
  }

  function pedirNotificacoes() {
    if (!('Notification' in window)) {
      toast('O teu navegador não suporta notificações.', 'erro');
      return Promise.resolve(false);
    }
    if (Notification.permission === 'granted') {
      var atual = !window.EF.store.carregar().config.notificacoes;
      window.EF.store.configurar('notificacoes', atual);
      toast(atual ? 'Lembretes de estudo ativados.' : 'Lembretes desativados.', 'ok');
      return Promise.resolve(atual);
    }
    return Notification.requestPermission().then(function (p) {
      var ok = p === 'granted';
      window.EF.store.configurar('notificacoes', ok);
      toast(ok ? 'Lembretes de estudo ativados.' : 'Sem permissão para notificações.', ok ? 'ok' : 'erro');
      return ok;
    });
  }

  window.EF.ui = {
    esc: esc,
    iniciar: iniciar,
    toast: toast,
    abrirModal: abrirModal,
    fecharModal: fecharModal,
    abrirLogin: abrirLogin,
    alternarTema: alternarTema,
    aplicarTema: aplicarTema,
    pedirNotificacoes: pedirNotificacoes,
    logoHTML: logoHTML
  };
})();
