/* ============================================================
   English Fácil — Currículo: Nível Avançado (C1–C2)
   ============================================================ */
window.EF = window.EF || {};
window.EF.licoes = window.EF.licoes || [];

window.EF.licoes.push(
{
  id: "c1-01", nivel: "avancado", ordem: 1, icone: "🎩", min: 24,
  titulo: "Inglês profissional e formal",
  resumo: "Emails, reuniões e apresentações com o tom certo.",
  objetivos: ["Escrever emails profissionais", "Usar linguagem formal vs informal", "Participar em reuniões com segurança"],
  explicacao: [
    { t: "Formal vs informal", p: "Informal: <em>Hi, thanks a lot, can you send it?</em> Formal: <em>Dear Mr. Silva, Thank you for your message. Could you please send the document?</em> A diferença está em três coisas: saudação, modais de cortesia e ausência de contrações." },
    { t: "Fórmulas de email", p: "Abertura: <strong>I hope this email finds you well.</strong> Objetivo: <strong>I am writing to inquire about...</strong> Pedido: <strong>I would appreciate it if you could...</strong> Fecho: <strong>Kind regards / Best regards,</strong> + nome." },
    { t: "Reuniões", p: "<strong>Could we go over the agenda?</strong> (podemos rever a agenda?), <strong>May I add something?</strong> (posso acrescentar?), <strong>To sum up...</strong> (resumindo), <strong>Let's circle back to that later.</strong> (voltamos a isso depois)." },
    { t: "Hedging — suavizar afirmações", p: "O inglês profissional evita afirmações brutas: <em>I think there might be a small issue</em> em vez de <em>You are wrong</em>. Palavras-chave: <strong>perhaps, possibly, it seems that, I would suggest, to some extent</strong>." }
  ],
  tabela: {
    titulo: "Informal → formal",
    cabecalho: ["Informal", "Formal"],
    linhas: [["Hi", "Dear Mr./ Ms. + apelido"], ["Thanks", "Thank you very much"], ["Can you...?", "Would you be able to...?"], ["Sorry for the delay", "I apologise for the delay"], ["Cheers", "Kind regards"], ["I want to know", "I would like to inquire"]]
  },
  vocabulario: [
    { en: "to inquire", pt: "indagar, perguntar", pron: "tu in-KUÁI-âr", ex: "I am writing to inquire about the position.", exPt: "Escrevo para perguntar sobre a vaga." },
    { en: "deadline", pt: "prazo", pron: "DÉD-lain", ex: "The deadline is next Friday.", exPt: "O prazo é na próxima sexta-feira." },
    { en: "to attend", pt: "comparecer, assistir", pron: "tu â-TÉND", ex: "I will attend the meeting.", exPt: "Vou comparecer à reunião." },
    { en: "agenda", pt: "ordem de trabalhos", pron: "â-DJÉN-dâ", ex: "Let us review the agenda.", exPt: "Vamos rever a agenda." },
    { en: "stakeholder", pt: "parte interessada", pron: "STÉIK-rôul-dâr", ex: "We must inform the stakeholders.", exPt: "Temos de informar as partes interessadas." },
    { en: "to follow up", pt: "dar seguimento", pron: "tu FÓ-lôu âp", ex: "I am following up on my last email.", exPt: "Estou a dar seguimento ao meu último email." },
    { en: "kind regards", pt: "com os melhores cumprimentos", pron: "kaind ri-GÁRDZ", ex: "Kind regards, Ana Silva", exPt: "Com os melhores cumprimentos, Ana Silva" },
    { en: "to schedule", pt: "agendar", pron: "tu SKÉ-djuul", ex: "Let us schedule a call.", exPt: "Vamos agendar uma chamada." }
  ],
  dica: "Em emails profissionais, use <strong>Could you please...</strong> em vez de <em>Can you...</em>. Custa a mesma letra e muda completamente a perceção de educação.",
  exercicios: [
    { tipo: "escolha", perg: "Qual é a abertura mais adequada para um email formal?", opcoes: ["Hey there!", "Dear Mr. Santos,", "Hi buddy,"], correta: 1, explica: "'Dear + título + apelido' é o padrão formal." },
    { tipo: "escolha", perg: "Qual pedido é mais educado?", opcoes: ["Send me the file.", "Would you be able to send me the file?", "I need the file now."], correta: 1, explica: "O modal 'would' suaviza o pedido — hedging profissional." },
    { tipo: "completar", perg: "Completa:", frase: "I am writing to ___ about the position. (indagar)", resposta: ["inquire", "enquire", "ask"], explica: "'Inquire/enquire about' é o verbo formal para perguntar." },
    { tipo: "traducao", perg: "Traduz para inglês formal: Agradeço a vossa resposta.", resposta: ["thank you for your reply", "i thank you for your reply", "thank you for your response"], explica: "Evite 'thanks' em contexto formal. 'Thank you for your reply' é o padrão." },
    { tipo: "ordenar", perg: "Organiza o fecho do email:", palavras: ["regards", "Kind", "Ana", "Silva"], resposta: "Kind regards Ana Silva", explica: "Fecho + vírgula + nome, em duas linhas no email real." },
    { tipo: "escrita", perg: "Escreve um email formal de 4 linhas a pedir uma reunião.", exemplo: "Dear Ms. Costa, I hope this email finds you well. I would like to schedule a meeting to discuss the project. Would you be available next Tuesday at 10 a.m.? Kind regards, Ana Silva.", explica: "Inclua: saudação, contexto, pedido com modal, fecho formal." }
  ]
},
{
  id: "c1-02", nivel: "avancado", ordem: 2, icone: "💬", min: 24,
  titulo: "Expressões idiomáticas do dia a dia",
  resumo: "Idioms que aparecem em filmes, reuniões e conversas reais.",
  objetivos: ["Reconhecer 18 expressões idiomáticas", "Usar idioms em contexto adequado", "Evitar traduções literais"],
  explicacao: [
    { t: "Porque são difíceis", p: "Uma expressão idiomática não se traduz. <em>It is raining cats and dogs</em> não tem gatos nem cães: significa 'chove a cântaros'. A única forma é aprender o bloco com uma situação." },
    { t: "As mais frequentes", p: "<strong>break the ice</strong> (quebrar o gelo), <strong>piece of cake</strong> (muito fácil), <strong>under the weather</strong> (indisposto), <strong>hit the books</strong> (estudar a sério), <strong>once in a blue moon</strong> (raramente), <strong>cost an arm and a leg</strong> (muito caro)." },
    { t: "No trabalho", p: "<strong>on the same page</strong> (alinhados), <strong>think outside the box</strong> (pensar de forma criativa), <strong>get the ball rolling</strong> (começar algo), <strong>touch base</strong> (contactar brevemente), <strong>back to the drawing board</strong> (recomeçar do zero)." },
    { t: "Cuidado com o registo", p: "Idioms são informais. Nunca use 'piece of cake' num relatório formal ou numa entrevista muito conservadora. Use-os em conversa, apresentações e emails casuais." }
  ],
  tabela: {
    titulo: "Idioms prontos a usar",
    cabecalho: ["Expressão", "Significado", "Exemplo"],
    linhas: [["piece of cake", "muito fácil", "The test was a piece of cake."], ["under the weather", "indisposto", "I am a bit under the weather today."], ["on the same page", "alinhados", "Let's make sure we are on the same page."], ["break the ice", "quebrar o gelo", "He told a joke to break the ice."], ["once in a blue moon", "raramente", "I eat out once in a blue moon."]]
  },
  vocabulario: [
    { en: "piece of cake", pt: "muito fácil", pron: "piis ov KÉIK", ex: "The exam was a piece of cake.", exPt: "O exame foi muito fácil." },
    { en: "to break the ice", pt: "quebrar o gelo", pron: "tu bréik dhi AIS", ex: "She told a story to break the ice.", exPt: "Ela contou uma história para quebrar o gelo." },
    { en: "under the weather", pt: "indisposto", pron: "ÂN-dâr dhi UÉ-dhâr", ex: "I am feeling under the weather.", exPt: "Estou a sentir-me indisposto." },
    { en: "on the same page", pt: "alinhados", pron: "on dhi seim PÉIDJ", ex: "We need to be on the same page.", exPt: "Precisamos de estar alinhados." },
    { en: "to hit the books", pt: "estudar com afinco", pron: "tu rit dhi BUKS", ex: "I have to hit the books tonight.", exPt: "Tenho de estudar a sério hoje à noite." },
    { en: "once in a blue moon", pt: "raramente", pron: "uâns in â bluu MUUN", ex: "He calls me once in a blue moon.", exPt: "Ele liga-me raramente." },
    { en: "to cost an arm and a leg", pt: "ser muito caro", pron: "tu kost én arm and â leg", ex: "That watch costs an arm and a leg.", exPt: "Aquele relógio custa uma fortuna." },
    { en: "to think outside the box", pt: "pensar de forma criativa", pron: "tu think aut-SAID dhi BOKS", ex: "We need someone who thinks outside the box.", exPt: "Precisamos de alguém criativo." }
  ],
  dica: "Aprenda 1 idiom por dia e use-o na mesma semana numa conversa real. Um idiom usado fica memorizado; dez lidos esquecem-se.",
  exercicios: [
    { tipo: "escolha", perg: "O que significa 'The test was a piece of cake'?", opcoes: ["O teste foi muito difícil", "O teste foi muito fácil", "O teste foi sobre bolos"], correta: 1, explica: "'Piece of cake' = algo muito fácil." },
    { tipo: "escolha", perg: "Se dizes 'I am under the weather', estás:", opcoes: ["indisposto", "a chover", "atrasado"], correta: 0, explica: "'Under the weather' significa sentir-se mal, indisposto." },
    { tipo: "completar", perg: "Completa a expressão:", frase: "We need to be on the same ___. (alinhados)", resposta: ["page"], explica: "'On the same page' = pensar da mesma forma, alinhados." },
    { tipo: "traducao", perg: "Traduz livremente: Esse carro custa uma fortuna.", resposta: ["that car costs an arm and a leg", "this car costs an arm and a leg"], explica: "Equivalente idiomático de 'custar uma fortuna'." },
    { tipo: "ordenar", perg: "Organiza a expressão:", palavras: ["the", "break", "ice", "Let's"], resposta: "Let's break the ice", explica: "'Let's' = vamos. Usa-se para sugerir algo em conjunto." },
    { tipo: "fala", perg: "Usa 'piece of cake' e 'under the weather' em duas frases próprias.", frase: "The exercise was a piece of cake. Yesterday I was under the weather, so I stayed home.", dica: "Idioms precisam de contexto para ficarem naturais." }
  ]
},
{
  id: "c1-03", nivel: "avancado", ordem: 3, icone: "✍️", min: 26,
  titulo: "Escrita avançada: ensaios e argumentação",
  resumo: "Estruturar opiniões com clareza, coesão e vocabulário preciso.",
  objetivos: ["Estruturar um ensaio em 4 partes", "Usar conectores avançados", "Escrever com coesão e variedade"],
  explicacao: [
    { t: "Estrutura de 4 blocos", p: "1) <strong>Introdução</strong>: contexto + tese clara. 2) <strong>Argumento 1</strong>: ideia + explicação + exemplo. 3) <strong>Contra-argumento</strong> (opcional, mas valoriza muito): 'Critics argue that... However...'. 4) <strong>Conclusão</strong>: retomar a tese + implicação." },
    { t: "Conectores avançados", p: "<strong>Nevertheless, nonetheless, furthermore, consequently, in contrast, whereas, provided that, insofar as, by and large, arguably</strong>. Use 3 a 4 por ensaio — mais do que isso torna o texto pesado." },
    { t: "Variedade sintática", p: "Alterne frases curtas e longas. Comece algumas com advérbio: <em>Arguably, the most effective approach is...</em> Use relativas: <em>a policy which addresses inequality</em>. Evite repetir 'I think' — use <em>It is widely believed, In my view, From my perspective</em>." },
    { t: "Precisão lexical", p: "Em vez de 'very big problem' → <em>a significant challenge</em>. Em vez de 'good thing' → <em>a valuable outcome</em>. Substitua adjetivos fracos: big, good, bad, nice → significant, beneficial, detrimental, appropriate." }
  ],
  tabela: {
    titulo: "Substituições que elevam o texto",
    cabecalho: ["Básico", "Avançado"],
    linhas: [["very important", "crucial / paramount"], ["a lot of people", "a considerable number of people"], ["I think", "In my view / Arguably"], ["bad effect", "detrimental impact"], ["good result", "favourable outcome"], ["because of this", "consequently / as a result"]]
  },
  vocabulario: [
    { en: "nevertheless", pt: "não obstante", pron: "né-vâr-dhâ-LÉS", ex: "Nevertheless, the results were positive.", exPt: "Não obstante, os resultados foram positivos." },
    { en: "furthermore", pt: "além disso", pron: "fâr-dhâr-MÔR", ex: "Furthermore, the cost is low.", exPt: "Além disso, o custo é baixo." },
    { en: "arguably", pt: "possivelmente, discutivelmente", pron: "ÁR-gju-â-bli", ex: "Arguably, this is the best option.", exPt: "Possivelmente, é a melhor opção." },
    { en: "detrimental", pt: "prejudicial", pron: "de-trâ-MÉN-tâl", ex: "It has a detrimental impact.", exPt: "Tem um impacto prejudicial." },
    { en: "to address", pt: "abordar, tratar", pron: "tu â-DRÉS", ex: "We must address this issue.", exPt: "Temos de abordar esta questão." },
    { en: "evidence", pt: "evidência", pron: "É-vi-dâns", ex: "There is strong evidence for this.", exPt: "Há fortes evidências disto." },
    { en: "to conclude", pt: "concluir", pron: "tu kân-KLÚUD", ex: "To conclude, education matters.", exPt: "Para concluir, a educação importa." },
    { en: "framework", pt: "estrutura, quadro", pron: "FRÉIM-uârk", ex: "We need a clear framework.", exPt: "Precisamos de uma estrutura clara." }
  ],
  dica: "Um ensaio forte tem uma tese que cabe numa frase. Se não consegues resumir a tua opinião numa frase, ainda não sabes o que defendes.",
  exercicios: [
    { tipo: "escolha", perg: "Qual é o melhor substituto de 'very important'?", opcoes: ["very very important", "crucial", "big important"], correta: 1, explica: "'Crucial' é o registo avançado de 'very important'." },
    { tipo: "escolha", perg: "Qual conector introduz uma conclusão?", opcoes: ["Furthermore", "To conclude", "Whereas"], correta: 1, explica: "'To conclude' sinaliza a conclusão do texto." },
    { tipo: "completar", perg: "Completa:", frase: "There is strong ___ that reading improves vocabulary. (evidência)", resposta: ["evidence"], explica: "'Evidence' é incontável em inglês: never 'evidences'." },
    { tipo: "traducao", perg: "Traduz para inglês formal: Na minha opinião, isto é prejudicial.", resposta: ["in my opinion this is detrimental", "in my view this is detrimental", "from my perspective this is detrimental"], explica: "Use adjetivos precisos ('detrimental') em vez de 'bad'." },
    { tipo: "ordenar", perg: "Organiza:", palavras: ["we", "this", "must", "issue", "address"], resposta: "We must address this issue", explica: "Sujeito + modal + verbo + objeto." },
    { tipo: "escrita", perg: "Escreve uma introdução de ensaio (3 frases) sobre aprender inglês na infância.", exemplo: "English has become a fundamental skill in the global economy. Some argue that children should start learning it as early as possible. In my view, an early start provides significant long-term advantages.", explica: "Contexto → opinião contrária → tese. Três frases, três funções." }
  ]
},
{
  id: "c2-01", nivel: "avancado", ordem: 4, icone: "🎙️", min: 25,
  titulo: "Conversação fluente e natural",
  resumo: "Sondar opiniões, discordar com elegância, manter conversa viva.",
  objetivos: ["Usar fillers naturais", "Discordar sem ofender", "Manter o ritmo de uma conversa real"],
  explicacao: [
    { t: "Fillers — o que os nativos dizem a pensar", p: "<strong>Well..., You know..., I mean..., Actually..., Let me think..., That's a good question.</strong> Pausas preenchidas soam mais naturais do que silêncio. Use 1 a cada 3 frases, não mais." },
    { t: "Concordar com intensidade", p: "<strong>Absolutely. Exactly. I couldn't agree more. That's a fair point. You have a point there.</strong> Reagir é metade de uma boa conversa." },
    { t: "Discordar com elegância", p: "<strong>I see what you mean, but...</strong> / <strong>I'm not sure I agree, to be honest.</strong> / <strong>That may be true, however...</strong> / <strong>I'd argue the opposite, actually.</strong> Evite 'You are wrong' — é considerado agressivo." },
    { t: "Manter a conversa", p: "Devolva perguntas: <em>What about you? How do you see it? Have you experienced that?</em> Uma conversa fluente é 40% falar e 60% reagir e perguntar." }
  ],
  tabela: {
    titulo: "Frases de conversa real",
    cabecalho: ["Função", "Frases"],
    linhas: [["Ganhar tempo", "Well... / Let me think... / That's a good question."], ["Concordar", "Exactly. / I couldn't agree more. / Fair enough."], ["Discordar", "I see your point, but... / I'm not convinced that..."], ["Clarificar", "What do you mean by...? / Could you elaborate?"], ["Encerrar", "Anyway, I should get going. / It was great talking to you."]]
  },
  vocabulario: [
    { en: "to be honest", pt: "para ser sincero", pron: "tu bi Ó-nâst", ex: "To be honest, I disagree.", exPt: "Para ser sincero, discordo." },
    { en: "I see your point", pt: "entendo o teu ponto", pron: "ai sii iór pôint", ex: "I see your point, but I think otherwise.", exPt: "Entendo o teu ponto, mas penso de outra forma." },
    { en: "to elaborate", pt: "desenvolver, detalhar", pron: "tu i-LÉ-bâ-reit", ex: "Could you elaborate on that?", exPt: "Podes detalhar isso?" },
    { en: "fair enough", pt: "justo, aceito", pron: "fér i-NÂF", ex: "Fair enough, let's do it your way.", exPt: "Justo, vamos fazer à tua maneira." },
    { en: "to get going", pt: "ir embora, começar a andar", pron: "tu guét GÔU-ing", ex: "Anyway, I should get going.", exPt: "Enfim, tenho de ir." },
    { en: "in other words", pt: "por outras palavras", pron: "in Â-dhâr uârdz", ex: "In other words, it is not possible.", exPt: "Por outras palavras, não é possível." },
    { en: "to point out", pt: "salientar", pron: "tu pôint ÁUT", ex: "I would like to point out one thing.", exPt: "Gostaria de salientar uma coisa." },
    { en: "actually", pt: "na verdade", pron: "ÉK-tchu-â-li", ex: "Actually, I live in Maputo.", exPt: "Na verdade, moro em Maputo." }
  ],
  dica: "'Actually' não significa 'atualmente'. Significa 'na verdade'. 'Currently' é que significa 'atualmente'. Confundir os dois muda o sentido da frase.",
  exercicios: [
    { tipo: "escolha", perg: "O que significa 'actually'?", opcoes: ["atualmente", "na verdade", "finalmente"], correta: 1, explica: "'Actually' = na verdade. 'Currently' = atualmente." },
    { tipo: "escolha", perg: "Qual é a forma mais elegante de discordar?", opcoes: ["You are wrong.", "I see your point, but I'm not sure I agree.", "No, that's nonsense."], correta: 1, explica: "Reconhecer o ponto do outro e suavizar com 'not sure' mantém a conversa saudável." },
    { tipo: "completar", perg: "Completa:", frase: "Could you ___ on that? (detalhar)", resposta: ["elaborate"], explica: "'Elaborate on' = detalhar um ponto." },
    { tipo: "traducao", perg: "Traduz: Para ser sincero, não concordo.", resposta: ["to be honest i do not agree", "to be honest i don't agree", "to be honest i disagree"], explica: "'To be honest' é o filler mais usado para introduzir opinião franca." },
    { tipo: "ordenar", perg: "Organiza:", palavras: ["should", "I", "going", "get", "Anyway"], resposta: "Anyway I should get going", explica: "Frase fixa para encerrar uma conversa com naturalidade." },
    { tipo: "fala", perg: "Grava-te a responder: 'Do you think English is important for your career?' Use 2 fillers e 1 conector.", frase: "Well, to be honest, I think English is essential. I mean, most companies now work internationally. So, yes, it is very important for my career.", dica: "Bem + opinião + reformulação + conclusão. Este é o padrão de uma resposta fluente." }
  ]
},
{
  id: "c2-02", nivel: "avancado", ordem: 5, icone: "🧠", min: 24,
  titulo: "Voz passiva, inversão e estruturas avançadas",
  resumo: "As estruturas que fazem o teu inglês soar culto e preciso.",
  objetivos: ["Usar a voz passiva em contexto", "Aplicar inversão para ênfase", "Usar cleft sentences"],
  explicacao: [
    { t: "Voz passiva", p: "<strong>be + particípio</strong>. <em>The report was written by the team.</em> Usa-se quando a ação importa mais do que o agente, ou quando o agente é desconhecido: <em>English is spoken worldwide.</em> Em textos académicos e notícias é predominante." },
    { t: "Inversão para ênfase", p: "Depois de advérbios negativos no início, invertem-se sujeito e auxiliar: <em>Never have I seen such a thing.</em> / <em>Rarely does he complain.</em> / <em>Not only did she pass, but she also got the highest mark.</em>" },
    { t: "Cleft sentences — destacar", p: "<em>It was Maria who called you.</em> (foi a Maria que...) / <em>What I need is more practice.</em> (o que eu preciso é...). Servem para colocar ênfase na informação importante." },
    { t: "Participios irregulares a rever", p: "<em>write → written, speak → spoken, break → broken, choose → chosen, take → taken, give → given, drive → driven, know → known</em>. A voz passiva depende deles." }
  ],
  tabela: {
    titulo: "Ativa → passiva",
    cabecalho: ["Ativa", "Passiva"],
    linhas: [["They built the school in 1990.", "The school was built in 1990."], ["Someone stole my bag.", "My bag was stolen."], ["They speak English here.", "English is spoken here."], ["They will announce the results.", "The results will be announced."]]
  },
  vocabulario: [
    { en: "to be built", pt: "ser construído", pron: "tu bi bilt", ex: "The bridge was built in 2005.", exPt: "A ponte foi construída em 2005." },
    { en: "to be spoken", pt: "ser falado", pron: "tu bi SPÔU-kân", ex: "Portuguese is spoken in Mozambique.", exPt: "Português é falado em Moçambique." },
    { en: "rarely", pt: "raramente", pron: "RÉR-li", ex: "Rarely does he arrive late.", exPt: "Raramente ele chega tarde." },
    { en: "not only", pt: "não só", pron: "not ÔUN-li", ex: "Not only did he come, but he also helped.", exPt: "Não só veio, como também ajudou." },
    { en: "emphasis", pt: "ênfase", pron: "ÉM-fâ-sis", ex: "The emphasis is on practice.", exPt: "A ênfase está na prática." },
    { en: "to announce", pt: "anunciar", pron: "tu â-NÁUNS", ex: "The results were announced yesterday.", exPt: "Os resultados foram anunciados ontem." },
    { en: "worldwide", pt: "em todo o mundo", pron: "UÂRLD-uaid", ex: "English is used worldwide.", exPt: "O inglês é usado em todo o mundo." },
    { en: "to be required", pt: "ser exigido", pron: "tu bi ri-KUÁI-ârd", ex: "A visa is required.", exPt: "É exigido um visto." }
  ],
  dica: "A voz passiva não é 'mais formal por ser difícil' — é uma escolha de foco. Se o importante é a ação, passa o agente para o fim ou omite-o.",
  exercicios: [
    { tipo: "escolha", perg: "Transforma: 'They built the school in 1990.'", opcoes: ["The school was built in 1990.", "The school is built in 1990.", "The school built in 1990."], correta: 0, explica: "Passado passivo: was + particípio (built)." },
    { tipo: "escolha", perg: "Completa a inversão: 'Never ___ I seen such a film.'", opcoes: ["have", "did", "was"], correta: 0, explica: "Com 'never' no início, inverte-se: Never have I seen." },
    { tipo: "completar", perg: "Completa no passivo:", frase: "English ___ spoken in many countries. (presente)", resposta: ["is"], explica: "Presente passivo: is + particípio." },
    { tipo: "traducao", perg: "Traduz: A reunião foi cancelada.", resposta: ["the meeting was cancelled", "the meeting was canceled"], explica: "Passado passivo: was + cancelled. Ortografia britânica e americana diferem." },
    { tipo: "ordenar", perg: "Organiza (cleft sentence):", palavras: ["is", "What", "practice", "I", "need"], resposta: "What I need is practice", explica: "Cleft: What + sujeito + verbo + is + foco." },
    { tipo: "escrita", perg: "Reescreve na passiva: 'They will announce the results tomorrow.'", exemplo: "The results will be announced tomorrow.", explica: "will be + particípio. O agente 'they' desaparece por ser genérico." }
  ]
},
{
  id: "c2-03", nivel: "avancado", ordem: 6, icone: "🌐", min: 22,
  titulo: "Inglês global: sotaques e inteligibilidade",
  resumo: "Entender inglês britânico, americano, africano e asiático.",
  objetivos: ["Reconhecer diferenças entre sotaques", "Evitar mal-entendidos culturais", "Escolher o sotaque que queres treinar"],
  explicacao: [
    { t: "Não existe um 'inglês certo'", p: "Existe inglês britânico (Received Pronunciation), americano (General American), e variantes africanas e asiáticas. Todas são legítimas. O objetivo não é eliminar o teu sotaque — é ser <strong>inteligível</strong>." },
    { t: "Diferenças que importam", p: "Britânico vs americano: <em>schedule</em> (XÉ-djuul / SKÉ-djuul), <em>advertisement</em>, <em>water</em> (o 't' americano soa quase 'd'). Vocabulário: <em>lorry/truck, flat/apartment, mobile/cell phone, holiday/vacation, queue/line</em>." },
    { t: "Inglês africano", p: "Em Moçambique, o inglês é normalmente aprendido como terceira língua (após línguas bantu e português). Particularidades: pronúncia mais silábica, ritmo diferente. Isso é uma vantagem de clareza — não um defeito." },
    { t: "Inteligibilidade", p: "O que atrapalha a compreensão: falar baixo, comer as sílabas finais, não marcar o plural, ritmo apressado. O que não atrapalha: sotaque. Foque em clareza, volume e terminações." }
  ],
  tabela: {
    titulo: "Britânico vs Americano",
    cabecalho: ["Português", "Britânico", "Americano"],
    linhas: [["autocarro", "bus / coach", "bus"], ["telemóvel", "mobile phone", "cell phone"], ["apartamento", "flat", "apartment"], ["férias", "holiday", "vacation"], ["fila", "queue", "line"], ["camião", "lorry", "truck"]]
  },
  vocabulario: [
    { en: "accent", pt: "sotaque", pron: "ÉK-sânt", ex: "Everyone has an accent.", exPt: "Todos têm um sotaque." },
    { en: "clear", pt: "claro, nítido", pron: "kliir", ex: "Speak in a clear voice.", exPt: "Fala com voz clara." },
    { en: "to pronounce", pt: "pronunciar", pron: "tu prâ-NÁUNS", ex: "How do you pronounce this word?", exPt: "Como se pronuncia esta palavra?" },
    { en: "fluent", pt: "fluente", pron: "FLÚU-ânt", ex: "She is fluent in three languages.", exPt: "Ela é fluente em três línguas." },
    { en: "misunderstanding", pt: "mal-entendido", pron: "mis-ân-dâr-STÂN-ding", ex: "It was just a misunderstanding.", exPt: "Foi apenas um mal-entendido." },
    { en: "native speaker", pt: "falante nativo", pron: "NÊI-tiv SPÍI-kâr", ex: "You do not need to sound like a native speaker.", exPt: "Não precisas de soar como um nativo." },
    { en: "confidence", pt: "confiança", pron: "KÔN-fi-dâns", ex: "Confidence matters more than perfection.", exPt: "A confiança importa mais que a perfeição." },
    { en: "worldwide", pt: "em todo o mundo", pron: "UÂRLD-uaid", ex: "English is a worldwide language.", exPt: "O inglês é uma língua mundial." }
  ],
  dica: "Objetivo realista: não 'falar como um nativo', mas ser compreendido por qualquer pessoa em qualquer país. Isso conquista-se em meses, não em anos.",
  exercicios: [
    { tipo: "escolha", perg: "Qual palavra é americana para 'flat'?", opcoes: ["apartment", "house", "room"], correta: 0, explica: "Britânico: flat. Americano: apartment." },
    { tipo: "escolha", perg: "O que mais prejudica a compreensão?", opcoes: ["Ter sotaque", "Não pronunciar as terminações das palavras", "Falar devagar"], correta: 1, explica: "Comer o fim das palavras (o -s do plural, o -ed) cria ambiguidade real." },
    { tipo: "completar", perg: "Completa:", frase: "How do you ___ this word? (pronunciar)", resposta: ["pronounce"], explica: "Não confundir 'pronounce' (verbo) com 'pronunciation' (substantivo)." },
    { tipo: "traducao", perg: "Traduz: Todos têm sotaque, até os nativos.", resposta: ["everyone has an accent even native speakers", "everybody has an accent even native speakers"], explica: "Usa-se 'everyone/everybody' com verbo no singular: has." },
    { tipo: "escuta", perg: "Ouve e escolhe a variante usada:", audio: "I will take the lift to my flat.", opcoes: ["britânico", "americano", "australiano"], correta: 0, explica: "'Lift' e 'flat' são termos britânicos (americano: elevator, apartment)." },
    { tipo: "fala", perg: "Diz esta frase em voz clara, sem comer o fim das palavras:", frase: "She works in a hospital and studies English every day.", dica: "Exagere as terminações: works, studies, day." }
  ]
}
);
