/* ============================================================
   English Fácil — Currículo: Nível Iniciante (A1–A2)
   ============================================================ */
window.EF = window.EF || {};
window.EF.licoes = window.EF.licoes || [];

window.EF.licoes.push(
{
  id: "a1-01", nivel: "iniciante", ordem: 1, icone: "🔤", min: 12,
  titulo: "O alfabeto e os sons do inglês",
  resumo: "As 26 letras, como se dizem e os sons que mais confundem quem fala português.",
  objetivos: ["Dizer o alfabeto em inglês", "Soletrar o seu nome", "Reconhecer os sons que não existem em português"],
  explicacao: [
    { t: "Porque começar pelo alfabeto?", p: "Em inglês, as letras não se pronunciam como em português. O <strong>a</strong> não é 'a', é <strong>ei</strong>. O <strong>e</strong> não é 'é', é <strong>i</strong>. Saber isto evita 80% dos erros de pronúncia desde o primeiro dia." },
    { t: "O truque mais importante", p: "Quando alguém não entende o seu nome, você soletra: <em>'My name is Ana: A-N-A'</em>. Vai ouvir esta pergunta muitas vezes: <strong>How do you spell your name?</strong> (Como se soletra o seu nome?)." },
    { t: "Sons que o português não tem", p: "O <strong>th</strong> (como em <em>think</em> e <em>this</em>) não existe em português. A ponta da língua toca levemente nos dentes de cima. Treine devagar: <em>think, this, three, mother</em>. Ninguém aprende isto a primeira vez — precisa de repetição." }
  ],
  tabela: {
    titulo: "As letras mais traiçoeiras",
    cabecalho: ["Letra", "Diz-se", "Exemplo"],
    linhas: [["A", "ei", "apple"], ["E", "i", "egg"], ["I", "ai", "ice"], ["G", "dji", "green"], ["H", "eitch", "house"], ["J", "djei", "job"], ["R", "ar", "red"], ["W", "dâbôl-iu", "water"], ["Y", "uai", "yes"]]
  },
  vocabulario: [
    { en: "hello", pt: "olá", pron: "re-LÔU", ex: "Hello! My name is Ana.", exPt: "Olá! O meu nome é Ana." },
    { en: "spell", pt: "soletrar", pron: "SPEL", ex: "Can you spell your name?", exPt: "Podes soletrar o teu nome?" },
    { en: "letter", pt: "letra", pron: "LÉ-râr", ex: "The letter A is pronounced 'ei'.", exPt: "A letra A pronuncia-se 'ei'." },
    { en: "word", pt: "palavra", pron: "UÂRD", ex: "This word is easy.", exPt: "Esta palavra é fácil." },
    { en: "name", pt: "nome", pron: "NEIM", ex: "My name is John.", exPt: "O meu nome é John." },
    { en: "again", pt: "de novo, outra vez", pron: "â-GUÉN", ex: "Please say it again.", exPt: "Por favor, diz de novo." },
    { en: "slowly", pt: "devagar", pron: "SLÔU-li", ex: "Please speak slowly.", exPt: "Por favor, fala devagar." },
    { en: "understand", pt: "entender", pron: "ân-dâr-STÂND", ex: "I understand a little English.", exPt: "Entendo um pouco de inglês." }
  ],
  dica: "Se não entender, não fique calado. Diga: <strong>Sorry, I do not understand. Can you repeat slowly?</strong> (Desculpe, não entendo. Pode repetir devagar?) — esta frase abre todas as portas.",
  exercicios: [
    { tipo: "escolha", perg: "Como se pronuncia a letra H em inglês?", opcoes: ["agá", "eitch", "erre"], correta: 1, explica: "Em inglês o H diz-se 'eitch'. Em português dizemos 'agá' — são coisas diferentes." },
    { tipo: "escolha", perg: "Qual destas palavras começa com o som 'th' (ponta da língua nos dentes)?", opcoes: ["tree", "three", "free"], correta: 1, explica: "'Three' tem o som 'th'. 'Tree' começa com 't' e 'free' com 'f' — para um português, os três parecem iguais no início, mas são diferentes." },
    { tipo: "completar", perg: "Completa com o verbo correto:", frase: "I ___ not understand.", resposta: ["do"], dica: "Verbo auxiliar para negativas no presente.", explica: "Com 'I', a negativa do presente simples usa 'do': 'I do not understand'." },
    { tipo: "traducao", perg: "Traduz para inglês: O meu nome é Carlos.", resposta: ["my name is carlos"], explica: "Estrutura base: My name is + nome. Note que em inglês o possessivo vem antes: 'my name', não 'the name my'." },
    { tipo: "ordenar", perg: "Organiza as palavras para formar uma frase:", palavras: ["name", "My", "is", "Ana"], resposta: "My name is Ana", explica: "Ordem do inglês: sujeito + verbo + complemento. Igual ao português nesta frase." },
    { tipo: "escuta", perg: "Ouve e escolhe o que foi dito:", audio: "Please speak slowly.", opcoes: ["Please speak slowly.", "Please spell your name.", "Please say it again."], correta: 0, explica: "'Speak slowly' = falar devagar. Ouviu 'speak' e 'slowly'." },
    { tipo: "fala", perg: "Diz em voz alta (o microfone pode não estar disponível):", frase: "Hello, my name is Ana. Nice to meet you.", dica: "Liga o som e compara com o áudio." },
    { tipo: "escrita", perg: "Escreve em inglês: Desculpe, não entendo. Pode falar devagar?", exemplo: "Sorry, I do not understand. Can you speak slowly?", explica: "Não precisa ser perfeito. O importante é comunicar: 'Sorry, I do not understand' já resolve." }
  ]
},
{
  id: "a1-02", nivel: "iniciante", ordem: 2, icone: "🔢", min: 14,
  titulo: "Números, horas e dinheiro",
  resumo: "De 0 a 1 milhão, dizer as horas, preços e quantidades.",
  objetivos: ["Contar de 0 a 100", "Perguntar e dizer as horas", "Falar de preços e dinheiro"],
  explicacao: [
    { t: "Os números até 20", p: "Memorize primeiro <strong>one, two, three, four, five, six, seven, eight, nine, ten</strong>. Depois <strong>eleven, twelve, thirteen, fourteen, fifteen, sixteen, seventeen, eighteen, nineteen, twenty</strong>. Repare no padrão: de 13 a 19 acrescenta-se <strong>-teen</strong>." },
    { t: "As dezenas", p: "twenty (20), thirty (30), forty (40 — sem 'u'!), fifty (50), sixty (60), seventy (70), eighty (80), ninety (90), one hundred (100). Junta-se com hífen: <strong>twenty-one</strong> (21), <strong>forty-five</strong> (45)." },
    { t: "As horas", p: "Existem duas formas. A simples: <strong>It is seven thirty</strong> (são sete e trinta). A formal: <strong>It is half past seven</strong>. Use <strong>o'clock</strong> só para horas exatas: <strong>It is seven o'clock</strong>. Para perguntar: <strong>What time is it?</strong> (Que horas são?)" },
    { t: "Dinheiro", p: "Preço: <strong>It costs ten dollars</strong>. Pergunta: <strong>How much is it?</strong> (Quanto custa?). Cuidado: <em>how much</em> para coisas incontáveis e preços; <em>how many</em> para coisas contáveis." }
  ],
  tabela: {
    titulo: "Números essenciais",
    cabecalho: ["Número", "Inglês", "Pronúncia"],
    linhas: [["13", "thirteen", "thâr-TÍIN"], ["30", "thirty", "THÂR-ti"], ["15", "fifteen", "fif-TÍIN"], ["50", "fifty", "FIF-ti"], ["100", "one hundred", "uân RÂN-drâd"], ["1000", "one thousand", "uân THÂU-zând"]]
  },
  vocabulario: [
    { en: "one / two / three", pt: "um / dois / três", pron: "uân / tu / thrii", ex: "I have two brothers.", exPt: "Tenho dois irmãos." },
    { en: "time", pt: "hora, tempo", pron: "TAIM", ex: "What time is it?", exPt: "Que horas são?" },
    { en: "hour", pt: "hora (duração)", pron: "ÁU-âr", ex: "The class is one hour long.", exPt: "A aula dura uma hora." },
    { en: "money", pt: "dinheiro", pron: "MÂ-ni", ex: "I need some money.", exPt: "Preciso de algum dinheiro." },
    { en: "price", pt: "preço", pron: "PRAIS", ex: "The price is very good.", exPt: "O preço é muito bom." },
    { en: "cheap", pt: "barato", pron: "TCHIIP", ex: "This book is cheap.", exPt: "Este livro é barato." },
    { en: "expensive", pt: "caro", pron: "eks-PEN-siv", ex: "That car is expensive.", exPt: "Aquele carro é caro." },
    { en: "today", pt: "hoje", pron: "tâ-DÊI", ex: "Today is Monday.", exPt: "Hoje é segunda-feira." }
  ],
  dica: "Para dizer um preço com segurança: <strong>How much is this?</strong> Depois só precisa de entender o número. Peça sempre: <strong>Can you write it, please?</strong>",
  exercicios: [
    { tipo: "escolha", perg: "Como se escreve 40 em inglês?", opcoes: ["fourty", "forty", "fourteen"], correta: 1, explica: "40 escreve-se 'forty', sem 'u'. Já 'fourteen' é 14 — um erro clássico." },
    { tipo: "escolha", perg: "São 7:30. Como se diz de forma simples?", opcoes: ["It is seven thirty.", "It is seven thirteen.", "It is thirty seven."], correta: 0, explica: "Hora + minutos: 'seven thirty'. 'Half past seven' é a forma mais formal, também correta." },
    { tipo: "completar", perg: "Completa:", frase: "___ much is this book?", resposta: ["how"], dica: "Usa-se para perguntar preço.", explica: "'How much' = quanto (preço/quantidade incontável)." },
    { tipo: "traducao", perg: "Traduz: Este carro é caro.", resposta: ["this car is expensive", "this car is very expensive"], explica: "'This' = este. 'Expensive' = caro. O adjetivo vem antes do substantivo em inglês." },
    { tipo: "ordenar", perg: "Organiza:", palavras: ["time", "is", "What", "it"], resposta: "What time is it", explica: "Perguntas com 'what' começam pela palavra interrogativa." },
    { tipo: "escuta", perg: "Ouve o número e escolhe:", audio: "fifteen", opcoes: ["fifty", "fifteen", "five"], correta: 1, explica: "'Fifteen' tem a ênfase no fim (-TEEN); 'fifty' tem no início (FIF-)." }
  ]
},
{
  id: "a1-03", nivel: "iniciante", ordem: 3, icone: "👋", min: 13,
  titulo: "Cumprimentos e despedidas",
  resumo: "Olá, bom dia, até logo — e o que responder em cada situação.",
  objetivos: ["Cumprimentar de manhã, tarde e noite", "Perguntar como a pessoa está", "Despedir-se de forma natural"],
  explicacao: [
    { t: "Três cumprimentos, três momentos", p: "<strong>Good morning</strong> (bom dia, até ao meio-dia), <strong>Good afternoon</strong> (boa tarde, do meio-dia às ~18h), <strong>Good evening</strong> (boa noite, ao chegar). Para sair à noite: <strong>Good night</strong> — só se usa para se despedir, nunca para cumprimentar." },
    { t: "Como estás?", p: "Formal: <strong>How are you?</strong> Informal: <strong>How are you doing?</strong> ou <strong>How is it going?</strong> Respostas: <em>I am fine, thank you</em>, <em>I am good</em>, <em>Not bad</em>. Em inglês é natural responder e devolver a pergunta: <strong>And you?</strong>" },
    { t: "Despedidas", p: "<strong>Goodbye</strong> (formal), <strong>Bye</strong> (informal), <strong>See you later</strong> (até logo), <strong>See you tomorrow</strong> (até amanhã), <strong>Have a nice day!</strong> (tem um bom dia)." },
    { t: "O famoso 'fine'", p: "Em Moçambique, Portugal e Brasil, 'fine' traduz-se por 'bem'. Mas atenção ao tom: 'I am fine' dito de forma seca pode soar frio. Acrescente sempre <em>thanks</em> ou <em>and you?</em> para soar simpático." }
  ],
  vocabulario: [
    { en: "Good morning", pt: "Bom dia", pron: "gud MÔR-ning", ex: "Good morning! How are you today?", exPt: "Bom dia! Como estás hoje?" },
    { en: "Good afternoon", pt: "Boa tarde", pron: "gud af-târ-NUN", ex: "Good afternoon, madam.", exPt: "Boa tarde, senhora." },
    { en: "Good evening", pt: "Boa noite (ao chegar)", pron: "gud ÍIV-ning", ex: "Good evening! Welcome.", exPt: "Boa noite! Bem-vindo." },
    { en: "How are you?", pt: "Como estás?", pron: "RÁU ar iú", ex: "Hello, Maria. How are you?", exPt: "Olá, Maria. Como estás?" },
    { en: "I am fine, thanks", pt: "Estou bem, obrigado", pron: "ai am FAIN, thénks", ex: "I am fine, thanks. And you?", exPt: "Estou bem, obrigado. E tu?" },
    { en: "Nice to meet you", pt: "Prazer em conhecer-te", pron: "NAIS tu MÍIT iú", ex: "Nice to meet you, Mr. Silva.", exPt: "Prazer em conhecê-lo, Sr. Silva." },
    { en: "See you later", pt: "Até logo", pron: "SII iú LÊI-târ", ex: "See you later, teacher!", exPt: "Até logo, professor!" },
    { en: "Have a nice day", pt: "Tem um bom dia", pron: "rév â NAIS dêi", ex: "Thank you. Have a nice day!", exPt: "Obrigado. Tem um bom dia!" }
  ],
  dica: "Em inglês, 'please' e 'thank you' são usados muito mais do que 'por favor' e 'obrigado' em português. Sem eles, o inglês soa agressivo, mesmo quando a frase é educada.",
  exercicios: [
    { tipo: "escolha", perg: "São 20h e entras num restaurante. O que dizes?", opcoes: ["Good night", "Good evening", "Good afternoon"], correta: 1, explica: "'Good evening' é o cumprimento à noite. 'Good night' serve apenas para se despedir." },
    { tipo: "escolha", perg: "Alguém diz 'Nice to meet you'. Qual é a melhor resposta?", opcoes: ["Nice to meet you too.", "I am fine, thanks.", "You are welcome."], correta: 0, explica: "Devolve-se o cumprimento: 'Nice to meet you too' (igualmente)." },
    { tipo: "completar", perg: "Completa a resposta:", frase: "I am fine, thanks. ___ you?", resposta: ["and"], explica: "'And you?' = e tu/você? É a forma natural de devolver a pergunta." },
    { tipo: "ordenar", perg: "Organiza:", palavras: ["to", "Nice", "meet", "you"], resposta: "Nice to meet you", explica: "Frase fixa de apresentação." },
    { tipo: "traducao", perg: "Traduz: Boa tarde, como está?", resposta: ["good afternoon how are you", "good afternoon how are you doing"], explica: "Em contexto formal pode usar 'How are you?'. Estrutura: cumprimento + pergunta." },
    { tipo: "escuta", perg: "Ouve e escolhe a tradução:", audio: "Have a nice day!", opcoes: ["Bom dia!", "Tem um bom dia!", "Boa noite!"], correta: 1, explica: "'Have a nice day' é uma despedida simpática, usada em lojas e escritórios." }
  ]
},
{
  id: "a1-04", nivel: "iniciante", ordem: 4, icone: "🙋", min: 15,
  titulo: "Apresentações e o verbo 'to be'",
  resumo: "I am, you are, he is — a base de metade do inglês que vais falar.",
  objetivos: ["Conjugar o verbo to be", "Apresentar-se e apresentar alguém", "Fazer frases negativas e perguntas"],
  explicacao: [
    { t: "O verbo mais usado do inglês", p: "<strong>I am</strong>, <strong>you are</strong>, <strong>he / she / it is</strong>, <strong>we are</strong>, <strong>they are</strong>. Em português dizemos 'sou', 'estou', 'é' — em inglês é sempre o mesmo verbo: <em>to be</em>. Isto simplifica muito." },
    { t: "Contrações (essenciais para soar natural)", p: "I am → <strong>I'm</strong>, you are → <strong>you're</strong>, he is → <strong>he's</strong>, she is → <strong>she's</strong>, we are → <strong>we're</strong>, they are → <strong>they're</strong>. Na fala, quase ninguém diz 'I am' completo — mas na escrita formal prefere-se a forma completa." },
    { t: "Negativa e pergunta", p: "Negativa: acrescenta <strong>not</strong>: <em>I am not a teacher</em>. Pergunta: inverte a ordem: <em>Are you a student?</em> Resposta curta: <em>Yes, I am</em> / <em>No, I am not</em>." },
    { t: "Apresentar outra pessoa", p: "<strong>This is my friend Paulo.</strong> (Este é o meu amigo Paulo.) <strong>He is from Mozambique.</strong> Repare: usa-se <em>this is</em> e não 'he is' para apresentar." }
  ],
  tabela: {
    titulo: "Verbo to be — presente",
    cabecalho: ["Pessoa", "Forma", "Contração"],
    linhas: [["I", "am", "I'm"], ["You", "are", "you're"], ["He / She / It", "is", "he's / she's / it's"], ["We", "are", "we're"], ["They", "are", "they're"]]
  },
  vocabulario: [
    { en: "I am a student", pt: "Sou estudante", pron: "ai am â STIÚ-dânt", ex: "I am a student at the university.", exPt: "Sou estudante na universidade." },
    { en: "teacher", pt: "professor(a)", pron: "TÍI-tchâr", ex: "She is a teacher.", exPt: "Ela é professora." },
    { en: "friend", pt: "amigo(a)", pron: "FREND", ex: "He is my friend.", exPt: "Ele é meu amigo." },
    { en: "from", pt: "de (origem)", pron: "from", ex: "I am from Maputo.", exPt: "Sou de Maputo." },
    { en: "married", pt: "casado(a)", pron: "MÉ-rid", ex: "I am married.", exPt: "Sou casado." },
    { en: "age", pt: "idade", pron: "EIDJ", ex: "What is your age?", exPt: "Qual é a sua idade?" },
    { en: "job", pt: "trabalho, emprego", pron: "DJOB", ex: "My job is interesting.", exPt: "O meu trabalho é interessante." },
    { en: "welcome", pt: "bem-vindo(a)", pron: "UÉL-kâm", ex: "Welcome to our class!", exPt: "Bem-vindo à nossa aula!" }
  ],
  dica: "Não diga <s>I have 25 years</s>. Em inglês a idade usa o verbo to be: <strong>I am 25 years old</strong>. Traduzir literalmente 'tenho 25 anos' é o erro número um de quem fala português.",
  exercicios: [
    { tipo: "escolha", perg: "Completa: She ___ a doctor.", opcoes: ["am", "is", "are"], correta: 1, explica: "Com he/she/it usa-se 'is': She is a doctor." },
    { tipo: "escolha", perg: "Como se diz 'Tenho 30 anos'?", opcoes: ["I have 30 years.", "I am 30 years old.", "My years are 30."], correta: 1, explica: "Idade em inglês usa 'to be': I am 30 years old." },
    { tipo: "completar", perg: "Completa com o verbo to be:", frase: "They ___ from Brazil.", resposta: ["are"], explica: "'They' leva sempre 'are'." },
    { tipo: "traducao", perg: "Traduz: Ela é a minha professora.", resposta: ["she is my teacher", "she's my teacher"], explica: "She + is. O possessivo 'my' vem antes do substantivo." },
    { tipo: "ordenar", perg: "Organiza a pergunta:", palavras: ["you", "Are", "a", "student"], resposta: "Are you a student", explica: "Pergunta com to be: verbo no início + sujeito." },
    { tipo: "escrita", perg: "Escreve uma apresentação de 3 frases sobre ti (nome, origem, profissão).", exemplo: "My name is Ana. I am from Beira. I am a nurse.", explica: "Não precisa de virgulas perfeitas — preocupe-se em usar 'I am' corretamente." }
  ]
},
{
  id: "a1-05", nivel: "iniciante", ordem: 5, icone: "🌍", min: 13,
  titulo: "Países, nacionalidades e profissões",
  resumo: "De onde vens, o que fazes — e as preposições certas.",
  objetivos: ["Falar da origem e nacionalidade", "Nomear profissões comuns", "Usar in / from / at corretamente"],
  explicacao: [
    { t: "Origem: from", p: "<strong>Where are you from?</strong> (De onde és?) → <strong>I am from Mozambique.</strong> Note que países levam maiúscula, mas nacionalidades em inglês também: <em>Mozambican, Portuguese, Brazilian</em>." },
    { t: "Nacionalidades em -ese, -ian, -ish", p: "Muitas terminam em <strong>-ese</strong> (Chinese, Japanese, Portuguese), <strong>-ian</strong> (Brazilian, Italian, Canadian), <strong>-ish</strong> (English, Spanish, Irish) e <strong>-an</strong> (American, Mexican, German)." },
    { t: "Viver e trabalhar: in / at", p: "<strong>I live in Portugal</strong> (país/cidade), <strong>I work at a hospital</strong> (local específico), <strong>I work in a bank</strong> (setor). É uma diferença pequena mas nota-se." },
    { t: "Profissões e artigos", p: "Em inglês usa-se sempre o artigo: <strong>I am a driver</strong> (não 'I am driver'). Com 'a/an': <em>an engineer</em>, <em>an artist</em> — 'an' antes de som de vogal." }
  ],
  tabela: {
    titulo: "País → nacionalidade",
    cabecalho: ["País", "Nacionalidade", "Língua"],
    linhas: [["Mozambique", "Mozambican", "Portuguese"], ["Portugal", "Portuguese", "Portuguese"], ["Brazil", "Brazilian", "Portuguese"], ["England", "English", "English"], ["The USA", "American", "English"]]
  },
  vocabulario: [
    { en: "Where are you from?", pt: "De onde és?", pron: "uér ar iú from", ex: "Where are you from? I am from Nampula.", exPt: "De onde és? Sou de Nampula." },
    { en: "country", pt: "país", pron: "KÂN-tri", ex: "Mozambique is a beautiful country.", exPt: "Moçambique é um país bonito." },
    { en: "city", pt: "cidade", pron: "SÍ-ti", ex: "Maputo is a big city.", exPt: "Maputo é uma cidade grande." },
    { en: "to live", pt: "morar, viver", pron: "tu LIV", ex: "I live in Lisbon.", exPt: "Moro em Lisboa." },
    { en: "to work", pt: "trabalhar", pron: "tu UÂRK", ex: "I work at a school.", exPt: "Trabalho numa escola." },
    { en: "engineer", pt: "engenheiro(a)", pron: "en-dji-NÍIR", ex: "She is an engineer.", exPt: "Ela é engenheira." },
    { en: "nurse", pt: "enfermeiro(a)", pron: "NÂRS", ex: "He is a nurse.", exPt: "Ele é enfermeiro." },
    { en: "business", pt: "negócio, empresa", pron: "BÍZ-nâs", ex: "I work in business.", exPt: "Trabalho em negócios." }
  ],
  dica: "Nunca digas <s>I am from Mozambique country</s>. Basta: <strong>I am from Mozambique</strong>. E lembre-se: nacionalidades escrevem-se com maiúscula em inglês — diferente do português.",
  exercicios: [
    { tipo: "escolha", perg: "Completa: I work ___ a hospital.", opcoes: ["in", "at", "on"], correta: 1, explica: "Para um local específico de trabalho usa-se 'at': at a hospital, at a school." },
    { tipo: "escolha", perg: "Qual é a nacionalidade de quem nasce em Portugal?", opcoes: ["Portugalian", "Portuguese", "Portugish"], correta: 1, explica: "Portuguese — terminação -ese, como Chinese e Japanese." },
    { tipo: "completar", perg: "Completa:", frase: "I ___ in Maputo.", resposta: ["live"], explica: "'Live' = morar. Com 'I' não se acrescenta -s." },
    { tipo: "traducao", perg: "Traduz: Sou de Moçambique e trabalho numa escola.", resposta: ["i am from mozambique and i work at a school", "i am from mozambique and i work in a school", "i'm from mozambique and i work at a school"], explica: "Duas frases ligadas por 'and'. 'At a school' é a forma mais precisa." },
    { tipo: "ordenar", perg: "Organiza:", palavras: ["are", "Where", "from", "you"], resposta: "Where are you from", explica: "Pergunta: where + verbo + sujeito." },
    { tipo: "escuta", perg: "Ouve e identifica a profissão:", audio: "She is an engineer.", opcoes: ["engineer", "teacher", "nurse"], correta: 0, explica: "'Engineer' tem três sílabas com ênfase no fim: en-dji-NÍIR." }
  ]
},
{
  id: "a1-06", nivel: "iniciante", ordem: 6, icone: "👨‍👩‍👧", min: 14,
  titulo: "Família e possessivos",
  resumo: "My, your, his, her — falar das pessoas que amamos sem erros.",
  objetivos: ["Nomear familiares", "Usar my / your / his / her / our / their", "Descrever pessoas com adjetivos"],
  explicacao: [
    { t: "Os possessivos", p: "<strong>my</strong> (meu/minha), <strong>your</strong> (teu/tua/seu/sua), <strong>his</strong> (dele), <strong>her</strong> (dela), <strong>its</strong> (de objeto/animal), <strong>our</strong> (nosso), <strong>their</strong> (deles/delas). Em inglês não variam com o género do objeto: <em>my brother, my sister, my children</em>." },
    { t: "Atenção a his/her", p: "A confusão clássica: <em>his</em> = do homem, <em>her</em> = da mulher. <em>His name is Paulo. Her name is Ana.</em> O possessivo refere-se ao dono, não ao objeto." },
    { t: "Família", p: "<strong>mother / father</strong> (mãe/pai), <strong>parents</strong> (pais), <strong>son / daughter</strong> (filho/filha), <strong>brother / sister</strong>, <strong>uncle / aunt</strong>, <strong>grandparents</strong>. Note: <em>parents</em> = pais (pai e mãe); <em>relatives</em> = parentes." },
    { t: "Descrever pessoas", p: "Adjetivos ficam antes do substantivo: <em>my older brother</em>. Ordem típica: opinião, tamanho, idade, forma, cor. <em>a beautiful small old house</em>." }
  ],
  vocabulario: [
    { en: "mother", pt: "mãe", pron: "MÂ-dhâr", ex: "My mother is a teacher.", exPt: "A minha mãe é professora." },
    { en: "father", pt: "pai", pron: "FÁ-dhâr", ex: "His father works here.", exPt: "O pai dele trabalha aqui." },
    { en: "son / daughter", pt: "filho / filha", pron: "sân / DÓ-târ", ex: "They have one son and two daughters.", exPt: "Eles têm um filho e duas filhas." },
    { en: "brother / sister", pt: "irmão / irmã", pron: "BRÂ-dhâr / SÍS-târ", ex: "My sister lives in Brazil.", exPt: "A minha irmã vive no Brasil." },
    { en: "children", pt: "filhos (crianças)", pron: "TCHÍL-drân", ex: "I have two children.", exPt: "Tenho dois filhos." },
    { en: "wife / husband", pt: "esposa / marido", pron: "UÁIF / RÂZ-bând", ex: "This is my wife, Ana.", exPt: "Esta é a minha esposa, Ana." },
    { en: "old / young", pt: "velho / jovem", pron: "ÔULD / iâng", ex: "My grandfather is old but strong.", exPt: "O meu avô é velho mas forte." },
    { en: "family", pt: "família", pron: "FÉ-mi-li", ex: "I love my family.", exPt: "Amo a minha família." }
  ],
  dica: "Para apresentar a família sem hesitar, use a estrutura: <strong>This is my + pessoa. + His/Her name is + nome.</strong> Exemplo: This is my sister. Her name is Carla.",
  exercicios: [
    { tipo: "escolha", perg: "Paulo is my brother. ___ wife is a doctor.", opcoes: ["Her", "His", "Their"], correta: 1, explica: "A esposa 'dele' (Paulo, homem) → his wife." },
    { tipo: "escolha", perg: "This is my mother. ___ name is Fátima.", opcoes: ["His", "Her", "Its"], correta: 1, explica: "Mãe (mulher) → her name." },
    { tipo: "completar", perg: "Completa:", frase: "I have two ___ (filhos).", resposta: ["children", "sons"], explica: "Plural irregular: child → children. 'Sons' também é aceitável se forem rapazes." },
    { tipo: "traducao", perg: "Traduz: O meu irmão vive em Portugal.", resposta: ["my brother lives in portugal"], explica: "Com he/she/it o presente leva -s: lives. Não esqueça!" },
    { tipo: "ordenar", perg: "Organiza:", palavras: ["is", "This", "sister", "my"], resposta: "This is my sister", explica: "This is + possessivo + pessoa." },
    { tipo: "escuta", perg: "Ouve e escolhe a palavra ouvida:", audio: "children", opcoes: ["children", "chicken", "chairs"], correta: 0, explica: "Children (filhos) vs chicken (frango) — sons parecidos, significados muito diferentes." }
  ]
},
{
  id: "a1-07", nivel: "iniciante", ordem: 7, icone: "⏰", min: 16,
  titulo: "A rotina diária e o presente simples",
  resumo: "O tempo verbal que vais usar em 60% das conversas.",
  objetivos: ["Conjugar verbos no presente simples", "Usar o -s da terceira pessoa", "Falar da rotina com advérbios de frequência"],
  explicacao: [
    { t: "Como funciona o presente simples", p: "Sujeito + verbo. Com <strong>I, you, we, they</strong> o verbo fica igual ao infinitivo sem 'to': <em>I work, they live</em>. Com <strong>he, she, it</strong> acrescenta-se <strong>-s</strong>: <em>he works, she lives</em>." },
    { t: "O -s é obrigatório", p: "Este é o erro mais comum de estudantes portugueses: esquecer o -s. <em>He work</em> ❌ / <em>He works</em> ✅. Se a frase passa a 'he/she/it', pense sempre: 'põe o -s!'" },
    { t: "Regras do -s", p: "Verbos terminados em -o, -s, -sh, -ch, -x → <strong>-es</strong>: <em>goes, watches, finishes</em>. Terminados em consoante + y → <strong>-ies</strong>: <em>study → studies</em>. Irregulares: <em>have → has</em>." },
    { t: "Frequência", p: "<strong>always</strong> (sempre) 100%, <strong>usually</strong> (normalmente) 90%, <strong>often</strong> (frequentemente) 70%, <strong>sometimes</strong> (às vezes) 50%, <strong>rarely</strong> (raramente) 10%, <strong>never</strong> (nunca) 0%. Posição: antes do verbo principal — <em>I always drink coffee</em>." }
  ],
  tabela: {
    titulo: "Presente simples",
    cabecalho: ["Pessoa", "Work", "Study"],
    linhas: [["I / You / We / They", "work", "study"], ["He / She / It", "works", "studies"]]
  },
  vocabulario: [
    { en: "to wake up", pt: "acordar", pron: "tu UÊIK âp", ex: "I wake up at six.", exPt: "Acordo às seis." },
    { en: "to have breakfast", pt: "tomar pequeno-almoço", pron: "tu rév BRÉK-fâst", ex: "She has breakfast at seven.", exPt: "Ela toma pequeno-almoço às sete." },
    { en: "to go to work", pt: "ir trabalhar", pron: "tu GÔU tu uârk", ex: "They go to work by bus.", exPt: "Eles vão trabalhar de autocarro." },
    { en: "every day", pt: "todos os dias", pron: "ÉV-ri dêi", ex: "I study English every day.", exPt: "Estudo inglês todos os dias." },
    { en: "usually", pt: "normalmente", pron: "IÚ-ju-â-li", ex: "I usually study at night.", exPt: "Normalmente estudo à noite." },
    { en: "to finish", pt: "terminar", pron: "tu FÍN-ich", ex: "He finishes work at five.", exPt: "Ele termina o trabalho às cinco." },
    { en: "to sleep", pt: "dormir", pron: "tu SLIIP", ex: "I sleep eight hours.", exPt: "Durmo oito horas." },
    { en: "early / late", pt: "cedo / tarde", pron: "ÂR-li / LEIT", ex: "I wake up early, he wakes up late.", exPt: "Acordo cedo, ele acorda tarde." }
  ],
  dica: "Truque de memória: imagine o 'he' e o 'she' como reis — precisam sempre de um presente extra (o -s). 'He works', 'she studies'.",
  exercicios: [
    { tipo: "escolha", perg: "Completa: She ___ to work by bus.", opcoes: ["go", "goes", "gos"], correta: 1, explica: "Verbos terminados em -o recebem -es: go → goes." },
    { tipo: "escolha", perg: "Completa: He ___ English every day.", opcoes: ["study", "studies", "studys"], correta: 1, explica: "Consoante + y → -ies: study → studies." },
    { tipo: "completar", perg: "Completa:", frase: "I usually ___ up at six o'clock. (acordar)", resposta: ["wake"], explica: "'Wake up' com 'I' fica sem -s." },
    { tipo: "traducao", perg: "Traduz: Ela toma pequeno-almoço às sete.", resposta: ["she has breakfast at seven", "she has breakfast at 7"], explica: "'Have' é irregular: she has. A hora usa 'at'." },
    { tipo: "ordenar", perg: "Organiza:", palavras: ["always", "I", "coffee", "drink"], resposta: "I always drink coffee", explica: "Advérbio de frequência antes do verbo principal." },
    { tipo: "escrita", perg: "Escreve 3 frases sobre a tua rotina diária.", exemplo: "I wake up at six. I go to work at eight. I study English at night.", explica: "Use verbos no presente simples e horas com 'at'." }
  ]
},
{
  id: "a1-08", nivel: "iniciante", ordem: 8, icone: "❓", min: 15,
  titulo: "Perguntas essenciais e cores",
  resumo: "What, where, who, when, why, how — e as cores do dia a dia.",
  objetivos: ["Fazer perguntas com palavras interrogativas", "Usar o auxiliar do/does", "Nomear cores e descrever objetos"],
  explicacao: [
    { t: "As seis palavras mágicas", p: "<strong>What</strong> (o quê), <strong>Where</strong> (onde), <strong>When</strong> (quando), <strong>Who</strong> (quem), <strong>Why</strong> (porquê), <strong>How</strong> (como). Com estas seis palavras consegue sobreviver em qualquer conversa." },
    { t: "Perguntas com do / does", p: "No presente simples, as perguntas precisam de auxiliar: <strong>Do you speak English?</strong> / <strong>Does she live here?</strong> Quando entra 'does', o verbo volta ao infinitivo sem -s: <em>Does she live?</em> (não 'lives')." },
    { t: "Cores", p: "<strong>red, blue, yellow, green, black, white, orange, brown, grey, pink, purple</strong>. Para descrever: <em>a red car</em> — cor antes do substantivo. Se quiser dizer 'o carro é vermelho': <em>the car is red</em>." },
    { t: "Perguntas úteis de sobrevivência", p: "<strong>What does this mean?</strong> (O que significa isto?), <strong>How do you say ... in English?</strong> (Como se diz ... em inglês?), <strong>Can you help me?</strong> (Pode ajudar-me?). Guarde estas três." }
  ],
  vocabulario: [
    { en: "What", pt: "O quê / Qual", pron: "uót", ex: "What is your name?", exPt: "Qual é o teu nome?" },
    { en: "Where", pt: "Onde", pron: "uér", ex: "Where do you live?", exPt: "Onde moras?" },
    { en: "When", pt: "Quando", pron: "uén", ex: "When is the class?", exPt: "Quando é a aula?" },
    { en: "Who", pt: "Quem", pron: "rúu", ex: "Who is that man?", exPt: "Quem é aquele homem?" },
    { en: "Why", pt: "Porquê", pron: "uái", ex: "Why do you study English?", exPt: "Porque estudas inglês?" },
    { en: "How", pt: "Como", pron: "ráu", ex: "How do you say this?", exPt: "Como se diz isto?" },
    { en: "red / blue / yellow", pt: "vermelho / azul / amarelo", pron: "red / bluu / ié-lôu", ex: "The flag has red, blue and yellow.", exPt: "A bandeira tem vermelho, azul e amarelo." },
    { en: "black / white", pt: "preto / branco", pron: "blék / uáit", ex: "I have a black bag.", exPt: "Tenho uma mala preta." }
  ],
  dica: "Se ficar sem palavras no meio de uma conversa, diga: <strong>How do you say ... in English?</strong> e aponte. É melhor perguntar do que ficar em silêncio.",
  exercicios: [
    { tipo: "escolha", perg: "Completa: ___ does she live?", opcoes: ["What", "Where", "Who"], correta: 1, explica: "Pergunta de lugar → where." },
    { tipo: "escolha", perg: "Qual frase está correta?", opcoes: ["Does she lives here?", "Does she live here?", "Do she live here?"], correta: 1, explica: "Com 'does' o verbo fica no infinitivo: live, sem -s." },
    { tipo: "completar", perg: "Completa:", frase: "___ do you study English? Because I want a better job.", resposta: ["why"], explica: "A resposta com 'because' indica que a pergunta era 'why' (porquê)." },
    { tipo: "traducao", perg: "Traduz: Como se diz isto em inglês?", resposta: ["how do you say this in english", "how do you say it in english"], explica: "Frase de sobrevivência essencial." },
    { tipo: "ordenar", perg: "Organiza:", palavras: ["do", "Where", "live", "you"], resposta: "Where do you live", explica: "Palavra interrogativa + auxiliar + sujeito + verbo." },
    { tipo: "escuta", perg: "Ouve a pergunta e escolhe a resposta adequada:", audio: "Where are you from?", opcoes: ["I am from Brazil.", "I am fine.", "It is red."], correta: 0, explica: "'Where are you from?' pede origem, então responde-se com um país/cidade." }
  ]
}
);
