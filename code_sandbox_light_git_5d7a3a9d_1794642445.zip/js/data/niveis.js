/* ============================================================
   English Fácil — Níveis e configuração do curso
   ============================================================ */
window.EF = window.EF || {};

window.EF.niveis = [
  {
    id: "iniciante",
    nome: "Iniciante",
    cefr: "A1 – A2",
    icone: "🌱",
    cor: "a1",
    corHex: "#2563eb",
    resumo: "Alfabeto, números, cumprimentos, apresentações, vocabulário básico e frases simples do dia a dia.",
    descricao: "Comece do absoluto zero. No fim deste nível consegue apresentar-se, falar da família, pedir num café, dizer as horas e construir frases completas no presente e no passado.",
    pontos: ["Alfabeto e sons", "Números, horas e dinheiro", "Cumprimentos e despedidas", "Apresentações e verbo to be", "Família e possessivos", "Rotina diária e presente simples", "Perguntas essenciais", "Esta conclusão vale o certificado A2"]
  },
  {
    id: "intermediario",
    nome: "Intermédio",
    cefr: "B1 – B2",
    icone: "📗",
    cor: "b1",
    corHex: "#7c3aed",
    resumo: "Conversação, gramática, tempos verbais, construção de frases e compreensão de textos.",
    descricao: "Aqui deixa de traduzir mentalmente. Trabalha o passado, o present perfect, o futuro, phrasal verbs e leitura de textos reais com estratégia.",
    pontos: ["Passado simples", "Present perfect vs. passado", "Futuro: will / going to", "Leitura e conectores", "Phrasal verbs", "Listening ativo", "Condicionais"]
  },
  {
    id: "avancado",
    nome: "Avançado",
    cefr: "C1 – C2",
    icone: "🎓",
    cor: "c1",
    corHex: "#e11d48",
    resumo: "Inglês profissional, expressões idiomáticas, escrita avançada e conversação fluente.",
    descricao: "Refina o registo: emails formais, idioms, ensaios argumentativos, voz passiva e conversa natural com fillers e estratégias de discordância elegante.",
    pontos: ["Inglês profissional e formal", "Expressões idiomáticas", "Escrita argumentativa", "Conversação fluente", "Estruturas avançadas", "Sotaques e inteligibilidade"]
  },
  {
    id: "real",
    nome: "Situações reais",
    cefr: "A2 – C1",
    icone: "🌍",
    cor: "real",
    corHex: "#0d9488",
    resumo: "Viagens, entrevistas de emprego, negócios, escola, trabalho e situações do dia a dia.",
    descricao: "Inglês que resolve problemas concretos: viajar, passar numa entrevista, trabalhar numa empresa internacional, falar com médicos e professores.",
    pontos: ["Aeroporto, hotel e restaurante", "Entrevistas de emprego", "Reuniões e negociação", "Saúde, escola e serviços", "Conversa social", "Frases prontas para cada situação"]
  }
];

window.EF.medalhas = [
  { id: "primeiro-passo", nome: "Primeiro Passo", icone: "🚀", desc: "Concluir a primeira aula" },
  { id: "cinco-aulas", nome: "A caminho", icone: "🛤️", desc: "Concluir 5 aulas" },
  { id: "dez-aulas", nome: "Dedicação", icone: "💪", desc: "Concluir 10 aulas" },
  { id: "todas-iniciante", nome: "Base Sólida", icone: "🌱", desc: "Concluir o nível Iniciante" },
  { id: "todas-intermediario", nome: "Comunicador", icone: "📗", desc: "Concluir o nível Intermédio" },
  { id: "todas-avancado", nome: "Fluência", icone: "🎓", desc: "Concluir o nível Avançado" },
  { id: "sequencia-3", nome: "3 dias seguidos", icone: "🔥", desc: "Estudar 3 dias consecutivos" },
  { id: "sequencia-7", nome: "Semana Perfeita", icone: "⚡", desc: "Estudar 7 dias consecutivos" },
  { id: "sequencia-30", nome: "Hábito de Ouro", icone: "🏆", desc: "Estudar 30 dias consecutivos" },
  { id: "cem-pontos", nome: "100 Pontos", icone: "⭐", desc: "Acumular 100 pontos" },
  { id: "mil-pontos", nome: "Mil Pontos", icone: "🌟", desc: "Acumular 1000 pontos" },
  { id: "dicionario", nome: "Curioso", icone: "🔍", desc: "Guardar 10 palavras favoritas" },
  { id: "teste-perfeito", nome: "Nota Máxima", icone: "🎯", desc: "Acertar todas as perguntas de um teste" },
  { id: "conversador", nome: "Conversador", icone: "💬", desc: "Enviar 10 mensagens ao professor virtual" }
];

window.EF.nivelDePontos = function (pontos) {
  const faixas = [
    { min: 0, nome: "Curioso", icone: "🌱" },
    { min: 100, nome: "Explorador", icone: "🧭" },
    { min: 250, nome: "Praticante", icone: "📘" },
    { min: 500, nome: "Comunicador", icone: "🗣️" },
    { min: 900, nome: "Confidente", icone: "🚀" },
    { min: 1500, nome: "Fluente", icone: "🏅" }
  ];
  let atual = faixas[0], proximo = null;
  for (let i = 0; i < faixas.length; i++) {
    if (pontos >= faixas[i].min) { atual = faixas[i]; proximo = faixas[i + 1] || null; }
  }
  return { atual, proximo };
};

/* Frases do dia — rodízio determinístico pela data */
window.EF.frasesDoDia = [
  { en: "Practice makes perfect.", pt: "A prática leva à perfeição." },
  { en: "Little by little, one travels far.", pt: "Devagar se vai longe." },
  { en: "Every day is a chance to learn something new.", pt: "Cada dia é uma oportunidade de aprender algo novo." },
  { en: "The best time to start was yesterday. The next best time is now.", pt: "A melhor altura para começar era ontem. A segunda melhor é agora." },
  { en: "Do not be afraid of mistakes. They are part of learning.", pt: "Não tenhas medo dos erros. Eles fazem parte de aprender." },
  { en: "Speak, even if it is not perfect.", pt: "Fala, mesmo que não seja perfeito." },
  { en: "A journey of a thousand miles begins with a single step.", pt: "Uma viagem de mil milhas começa com um único passo." },
  { en: "Confidence is more important than perfection.", pt: "A confiança é mais importante do que a perfeição." },
  { en: "Small steps every day beat big steps once a year.", pt: "Pequenos passos todos os dias vencem grandes passos uma vez por ano." },
  { en: "Learning a language is learning a new way to think.", pt: "Aprender uma língua é aprender uma nova forma de pensar." }
];

window.EF.desafios = [
  { titulo: 'Diz 3 frases em voz alta', desc: 'Apresenta-te em inglês: nome, cidade e profissão.', pontos: 10, link: 'conversacao.html' },
  { titulo: 'Traduz 5 palavras novas', desc: 'Abre o dicionário, escolhe 5 palavras desconhecidas e guarda-as nos favoritos.', pontos: 10, link: 'dicionario.html' },
  { titulo: 'Ouve 3 palavras do dicionário', desc: 'Treina o ouvido: usa o botão de áudio em 3 palavras. Repete cada uma em voz alta.', pontos: 5, link: 'dicionario.html' },
  { titulo: 'Faz um mini-teste', desc: 'Completa o teste rápido de 6 perguntas do nível em que estás.', pontos: 15, link: 'exercicios.html' },
  { titulo: 'Conclui uma aula', desc: 'Escolhe a próxima aula da tua lista e termina os exercícios todos.', pontos: 20, link: 'cursos.html' },
  { titulo: 'Conversa com o professor', desc: 'Escreve 3 mensagens ao professor virtual. Podes perguntar qualquer coisa em português.', pontos: 10, link: 'conversacao.html' },
  { titulo: 'Escreve um parágrafo', desc: 'Escreve 4 frases em inglês com um conector (however, because, therefore).', pontos: 15, link: 'exercicios.html?tipo=escrita' },
  { titulo: 'Fala 60 segundos', desc: 'Grava-te a falar durante um minuto sobre o teu dia. Ouve e repete.', pontos: 15, link: 'exercicios.html?tipo=fala' }
];

window.EF.palavrasDoDia = [
  { en: "improve", pt: "melhorar", pron: "im-PRÚUV", classe: "verbo", ex: "Reading every day improves your English.", exPt: "Ler todos os dias melhora o teu inglês." },
  { en: "achieve", pt: "alcançar", pron: "â-TCHÍIV", classe: "verbo", ex: "You can achieve your goals with practice.", exPt: "Podes alcançar os teus objetivos com prática." },
  { en: "brave", pt: "corajoso", pron: "brêiv", classe: "adjetivo", ex: "Be brave and speak in English.", exPt: "Sê corajoso e fala em inglês." },
  { en: "curious", pt: "curioso", pron: "KIÚ-ri-âs", classe: "adjetivo", ex: "Curious students learn faster.", exPt: "Alunos curiosos aprendem mais depressa." },
  { en: "effort", pt: "esforço", pron: "É-fort", classe: "substantivo", ex: "Every effort counts.", exPt: "Cada esforço conta." },
  { en: "progress", pt: "progresso", pron: "PRÔ-gres", classe: "substantivo", ex: "You are making great progress.", exPt: "Estás a fazer um ótimo progresso." },
  { en: "challenge", pt: "desafio", pron: "TCHÉ-lêndj", classe: "substantivo", ex: "Take the challenge today.", exPt: "Aceita o desafio hoje." },
  { en: "fluent", pt: "fluente", pron: "FLÚU-ânt", classe: "adjetivo", ex: "She is fluent in English.", exPt: "Ela é fluente em inglês." }
];
