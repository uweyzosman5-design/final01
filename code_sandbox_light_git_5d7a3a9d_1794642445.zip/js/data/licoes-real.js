/* ============================================================
   English Fácil — Currículo: Inglês para situações reais
   ============================================================ */
window.EF = window.EF || {};
window.EF.licoes = window.EF.licoes || [];

window.EF.licoes.push(
{
  id: "real-01", nivel: "real", ordem: 1, icone: "✈️", min: 20,
  titulo: "Viagens: aeroporto, hotel e restaurante",
  resumo: "Do check-in ao pedido no restaurante — sobreviver a qualquer viagem.",
  objetivos: ["Fazer check-in e check-out", "Reservar e pedir num restaurante", "Pedir ajuda quando se perde"],
  explicacao: [
    { t: "No aeroporto", p: "<strong>Where is the check-in desk?</strong> (Onde é o balcão de check-in?) <strong>I would like a window seat, please.</strong> (Gostaria de um lugar à janela.) <strong>Is this flight delayed?</strong> (Este voo está atrasado?) <strong>Where is gate 12?</strong> (Onde é a porta 12?)" },
    { t: "No hotel", p: "<strong>I have a reservation under the name Silva.</strong> (Tenho uma reserva em nome de Silva.) <strong>What time is check-out?</strong> (A que horas é o check-out?) <strong>Is breakfast included?</strong> (O pequeno-almoço está incluído?) <strong>Could I have a wake-up call?</strong> (Poderia dar-me um alarme?)" },
    { t: "No restaurante", p: "<strong>Table for two, please.</strong> <strong>Could I see the menu?</strong> <strong>What do you recommend?</strong> (O que recomenda?) <strong>I am allergic to nuts.</strong> (Sou alérgico a frutos secos.) <strong>The bill, please.</strong> (A conta, por favor.)" },
    { t: "Quando te perdes", p: "<strong>Excuse me, how do I get to the station?</strong> <strong>Is it far from here?</strong> (É longe daqui?) <strong>Could you show me on the map?</strong> (Pode mostrar-me no mapa?) <strong>I am lost.</strong> (Estou perdido.)" }
  ],
  vocabulario: [
    { en: "boarding pass", pt: "cartão de embarque", pron: "BÔR-ding péss", ex: "Here is your boarding pass.", exPt: "Aqui está o seu cartão de embarque." },
    { en: "luggage", pt: "bagagem", pron: "LÂ-guidj", ex: "My luggage is missing.", exPt: "A minha bagagem desapareceu." },
    { en: "reservation", pt: "reserva", pron: "re-zâr-VÊI-shân", ex: "I have a reservation for tonight.", exPt: "Tenho uma reserva para hoje à noite." },
    { en: "room key", pt: "chave do quarto", pron: "ruum kii", ex: "I lost my room key.", exPt: "Perdi a chave do quarto." },
    { en: "menu", pt: "ementa, menu", pron: "MÉ-nju", ex: "Could I see the menu, please?", exPt: "Poderia ver a ementa, por favor?" },
    { en: "bill / check", pt: "conta", pron: "bil / tchek", ex: "The bill, please.", exPt: "A conta, por favor." },
    { en: "to be allergic", pt: "ser alérgico", pron: "tu bi â-LÂR-djik", ex: "I am allergic to seafood.", exPt: "Sou alérgico a marisco." },
    { en: "to get lost", pt: "perder-se", pron: "tu guét lost", ex: "I got lost in the city centre.", exPt: "Perdi-me no centro da cidade." }
  ],
  dica: "Em viagem, o inglês educado salva-te. Comece sempre com <strong>Excuse me</strong> e termine com <strong>Thank you so much</strong>. Funciona em qualquer país.",
  exercicios: [
    { tipo: "escolha", perg: "Estás num restaurante e queres pagar. Dizes:", opcoes: ["The bill, please.", "I want money.", "Give me the menu."], correta: 0, explica: "'The bill, please' é a fórmula universal." },
    { tipo: "escolha", perg: "Queres um lugar à janela no avião:", opcoes: ["I would like an aisle seat.", "I would like a window seat.", "I would like a table seat."], correta: 1, explica: "'Window seat' = lugar à janela. 'Aisle seat' = lugar no corredor." },
    { tipo: "completar", perg: "Completa:", frase: "I have a ___ under the name Silva. (reserva)", resposta: ["reservation", "booking"], explica: "Ambos são corretos; 'reservation' é mais comum em hotéis." },
    { tipo: "traducao", perg: "Traduz: O pequeno-almoço está incluído?", resposta: ["is breakfast included", "is the breakfast included"], explica: "Estrutura passiva comum em hotéis." },
    { tipo: "ordenar", perg: "Organiza:", palavras: ["get", "How", "I", "do", "to", "station", "the"], resposta: "How do I get to the station", explica: "'How do I get to...' é a pergunta padrão de direções." },
    { tipo: "escuta", perg: "Ouve e escolhe o local:", audio: "Your room is on the third floor. Breakfast is at seven.", opcoes: ["hotel", "aeroporto", "restaurante"], correta: 0, explica: "'Room' e 'breakfast' indicam hotel." }
  ]
},
{
  id: "real-02", nivel: "real", ordem: 2, icone: "💼", min: 22,
  titulo: "Entrevistas de emprego em inglês",
  resumo: "As 10 perguntas mais frequentes e como responder com confiança.",
  objetivos: ["Apresentar-te profissionalmente", "Responder a perguntas difíceis", "Fazer as tuas próprias perguntas"],
  explicacao: [
    { t: "A pergunta de abertura", p: "<strong>Tell me about yourself.</strong> Não conte a tua vida: 3 frases — formação, experiência relevante, porque queres esta vaga. <em>I have five years of experience in logistics, and I am looking for a role where I can grow.</em>" },
    { t: "Pontos fortes e fracos", p: "<strong>What are your strengths?</strong> → escolha 2 fortes e dê um exemplo. <strong>What is your greatest weakness?</strong> → fraqueza real + o que fazes para melhorar. Nunca diga 'I am a perfectionist' — é um cliché que os recrutadores detetam." },
    { t: "Perguntas de situação", p: "<strong>Tell me about a time when you solved a problem.</strong> Use a estrutura STAR: <em>Situation</em> (contexto), <em>Task</em> (o teu papel), <em>Action</em> (o que fizeste), <em>Result</em> (resultado concreto)." },
    { t: "As tuas perguntas", p: "No fim perguntam: <strong>Do you have any questions for us?</strong> Nunca diga não. Pergunte: <em>What would a typical day look like? How is success measured in this role? What are the next steps?</em>" }
  ],
  tabela: {
    titulo: "Perguntas e respostas-chave",
    cabecalho: ["Pergunta", "Início de resposta"],
    linhas: [["Tell me about yourself", "I have ... years of experience in ..."], ["Why do you want this job?", "I am particularly interested in ... because ..."], ["What are your strengths?", "I would say my main strength is ..."], ["Where do you see yourself in 5 years?", "I would like to develop into ..."], ["Do you have any questions?", "Yes — what are the next steps?"]]
  },
  vocabulario: [
    { en: "to apply for", pt: "candidatar-se a", pron: "tu â-PLAI for", ex: "I applied for the position.", exPt: "Candidatei-me à vaga." },
    { en: "experience", pt: "experiência", pron: "eks-PÍ-ri-âns", ex: "I have three years of experience.", exPt: "Tenho três anos de experiência." },
    { en: "skills", pt: "competências", pron: "skilz", ex: "My skills match the job.", exPt: "As minhas competências correspondem ao trabalho." },
    { en: "teamwork", pt: "trabalho em equipa", pron: "TÍIM-uârk", ex: "I value teamwork.", exPt: "Valorizo o trabalho em equipa." },
    { en: "challenge", pt: "desafio", pron: "TCHÉ-lêndj", ex: "I enjoy new challenges.", exPt: "Gosto de novos desafios." },
    { en: "to be responsible for", pt: "ser responsável por", pron: "tu bi ri-SPÔN-sâ-bâl for", ex: "I was responsible for the budget.", exPt: "Era responsável pelo orçamento." },
    { en: "salary", pt: "salário", pron: "SÉ-lâ-ri", ex: "What is the salary range?", exPt: "Qual é o intervalo salarial?" },
    { en: "to look forward to", pt: "aguardar com expectativa", pron: "tu luk FÔR-uârd tu", ex: "I look forward to hearing from you.", exPt: "Aguardo a vossa resposta." }
  ],
  dica: "Treine a entrevista em voz alta, cronometrada. Respostas de 60 a 90 segundos são o ideal — nem monossílabos, nem monólogos.",
  exercicios: [
    { tipo: "escolha", perg: "Como responder a 'Tell me about yourself'?", opcoes: ["Falar da infância e da família.", "Resumir formação, experiência e interesse na vaga.", "Dizer que está nervoso."], correta: 1, explica: "Foco profissional em 3 frases: formação, experiência, motivação." },
    { tipo: "escolha", perg: "O que significa a estrutura STAR?", opcoes: ["Situation, Task, Action, Result", "Start, Talk, Answer, Repeat", "Skills, Talent, Ability, Result"], correta: 0, explica: "STAR estrutura respostas comportamentais de forma convincente." },
    { tipo: "completar", perg: "Completa:", frase: "I would like to ___ for the position of manager. (candidatar-me)", resposta: ["apply"], explica: "'Apply for a position' — preposição 'for'." },
    { tipo: "traducao", perg: "Traduz: Tenho cinco anos de experiência nesta área.", resposta: ["i have five years of experience in this area", "i have 5 years of experience in this area", "i have five years experience in this area"], explica: "Estrutura fixa: years of experience." },
    { tipo: "ordenar", perg: "Organiza:", palavras: ["forward", "look", "I", "to", "you", "hearing", "from"], resposta: "I look forward to hearing from you", explica: "Fecho profissional clássico de candidatura." },
    { tipo: "fala", perg: "Responde em voz alta em 60-90 segundos: 'Tell me about yourself.'", frase: "I have four years of experience in customer service. I am responsible for a small team of five people. I am looking for a role where I can develop my management skills, which is why this position interests me.", dica: "Grave-te e conte as palavras: 80-110 palavras é o ideal." }
  ]
},
{
  id: "real-03", nivel: "real", ordem: 3, icone: "🏢", min: 22,
  titulo: "Negócios: reuniões, chamadas e negociação",
  resumo: "Vocabulário e fórmulas para trabalhar em inglês todos os dias.",
  objetivos: ["Conduzir e participar em reuniões", "Fazer chamadas profissionais", "Negociar com linguagem adequada"],
  explicacao: [
    { t: "Abrir uma reunião", p: "<strong>Good morning everyone. Thank you for joining.</strong> <strong>Shall we start?</strong> <strong>The purpose of today's meeting is to...</strong> (O objetivo da reunião de hoje é...). <strong>Let's go through the agenda.</strong>" },
    { t: "Intervir com elegância", p: "<strong>Could I just come in here?</strong> (Posso intervir?) <strong>Sorry to interrupt, but...</strong> <strong>Building on what Ana said...</strong> (Continuando o que a Ana disse...) <strong>Can I add a quick point?</strong>" },
    { t: "Chamadas", p: "<strong>This is Ana Silva speaking.</strong> <strong>Could I speak to Mr. Jones, please?</strong> <strong>Sorry, the line is bad. Could you repeat that?</strong> <strong>Let me summarise what we agreed.</strong>" },
    { t: "Negociar", p: "<strong>We were hoping for a slightly better price.</strong> <strong>If we increase the order, would you consider a discount?</strong> <strong>That works for us.</strong> (Isso funciona para nós.) <strong>Let me take that back to my team.</strong> Nunca diga 'that is impossible' — diga 'that could be difficult, but let's explore alternatives'." }
  ],
  tabela: {
    titulo: "Frases de reunião por função",
    cabecalho: ["Função", "Frase"],
    linhas: [["Abrir", "Shall we start? / Let's get started."], ["Intervir", "Could I come in here?"], ["Concordar", "That works for us."], ["Discordar", "I have some reservations about that."], ["Adiar", "Let's park that for now."], ["Encerrar", "To sum up, we agreed on three points."]]
  },
  vocabulario: [
    { en: "meeting", pt: "reunião", pron: "MÍI-ting", ex: "The meeting starts at nine.", exPt: "A reunião começa às nove." },
    { en: "to negotiate", pt: "negociar", pron: "tu ni-GÔU-shi-eit", ex: "We negotiated a better deal.", exPt: "Negociámos um acordo melhor." },
    { en: "discount", pt: "desconto", pron: "DÍS-kaunt", ex: "Could you offer a discount?", exPt: "Pode oferecer um desconto?" },
    { en: "invoice", pt: "fatura", pron: "ÍN-vois", ex: "Please send the invoice.", exPt: "Por favor, envie a fatura." },
    { en: "to agree", pt: "concordar", pron: "tu â-GRÍI", ex: "We agree on the terms.", exPt: "Concordamos com os termos." },
    { en: "quarter", pt: "trimestre", pron: "KUÔR-târ", ex: "Sales grew this quarter.", exPt: "As vendas cresceram neste trimestre." },
    { en: "budget", pt: "orçamento", pron: "BÂ-djet", ex: "It is within our budget.", exPt: "Está dentro do nosso orçamento." },
    { en: "to summarise", pt: "resumir", pron: "tu SÂ-mâ-raiz", ex: "Let me summarise the main points.", exPt: "Deixe-me resumir os pontos principais." }
  ],
  dica: "Em negociação, o silêncio é uma ferramenta. Depois de apresentar a tua proposta, cala-te e deixa o outro responder. Falar mais não significa ganhar mais.",
  exercicios: [
    { tipo: "escolha", perg: "Como discordar de forma profissional?", opcoes: ["That is impossible.", "I have some reservations about that.", "You are wrong."], correta: 1, explica: "'Reservations' comunica dúvida sem confronto." },
    { tipo: "escolha", perg: "Ao telefone, como te identificas?", opcoes: ["I am Ana.", "This is Ana Silva speaking.", "Me Ana."], correta: 1, explica: "Fórmula telefónica padrão em contexto profissional." },
    { tipo: "completar", perg: "Completa:", frase: "Let me ___ up what we agreed. (resumir)", resposta: ["sum", "summarise"], explica: "'Sum up' (phrasal) e 'summarise' são ambos corretos." },
    { tipo: "traducao", perg: "Traduz: Podemos discutir o orçamento na próxima reunião?", resposta: ["can we discuss the budget at the next meeting", "could we discuss the budget at the next meeting"], explica: "'At the meeting' — preposição 'at' para eventos." },
    { tipo: "ordenar", perg: "Organiza:", palavras: ["start", "we", "Shall"], resposta: "Shall we start", explica: "'Shall we' é a forma educada de sugerir algo em conjunto." },
    { tipo: "escuta", perg: "Ouve e escolhe o objetivo:", audio: "Could I just come in here? I think we are missing an important point.", opcoes: ["Interromper educadamente", "Encerrar a reunião", "Pedir a conta"], correta: 0, explica: "'Could I just come in here?' é a fórmula para intervir." }
  ]
},
{
  id: "real-04", nivel: "real", ordem: 4, icone: "🏥", min: 20,
  titulo: "Saúde, escola e serviços do dia a dia",
  resumo: "Farmácia, médico, escola dos filhos, banco e casa.",
  objetivos: ["Descrever sintomas ao médico", "Resolver assuntos escolares", "Abrir conta e tratar de serviços"],
  explicacao: [
    { t: "No médico", p: "<strong>I have a headache / a sore throat / a fever.</strong> (dor de cabeça / dor de garganta / febre) <strong>It hurts here.</strong> (Dói aqui.) <strong>Since when? Three days.</strong> <strong>I need a prescription.</strong> (Preciso de receita.) <strong>I am allergic to penicillin.</strong>" },
    { t: "Na farmácia", p: "<strong>Do you have something for a cough?</strong> (Tem algo para a tosse?) <strong>How often should I take it?</strong> (Com que frequência devo tomar?) <strong>Is it safe for children?</strong> (É seguro para crianças?)" },
    { t: "Na escola", p: "<strong>I would like to speak to the teacher.</strong> <strong>My son is in grade four.</strong> (O meu filho está no 4º ano.) <strong>Could you explain the school calendar?</strong> <strong>How can I support my child at home?</strong>" },
    { t: "No banco e em casa", p: "<strong>I would like to open an account.</strong> <strong>What documents do I need?</strong> <strong>I am having an issue with my water bill.</strong> <strong>The electricity is not working.</strong> (A eletricidade não funciona.) <strong>Could you send someone to check?</strong>" }
  ],
  vocabulario: [
    { en: "headache", pt: "dor de cabeça", pron: "RÉD-eik", ex: "I have a terrible headache.", exPt: "Tenho uma dor de cabeça terrível." },
    { en: "fever", pt: "febre", pron: "FÍI-vâr", ex: "She has a high fever.", exPt: "Ela tem febre alta." },
    { en: "sore throat", pt: "dor de garganta", pron: "sor THRÔUT", ex: "I have a sore throat.", exPt: "Tenho dor de garganta." },
    { en: "prescription", pt: "receita médica", pron: "pri-SKRÍP-shân", ex: "The doctor gave me a prescription.", exPt: "O médico deu-me uma receita." },
    { en: "appointment", pt: "consulta marcada", pron: "â-PÔINT-mânt", ex: "I would like to book an appointment.", exPt: "Gostaria de marcar uma consulta." },
    { en: "to open an account", pt: "abrir uma conta", pron: "tu ÔU-pân én â-KÁUNT", ex: "I want to open a bank account.", exPt: "Quero abrir uma conta bancária." },
    { en: "bill", pt: "fatura, conta", pron: "bil", ex: "I need to pay the electricity bill.", exPt: "Preciso de pagar a conta da eletricidade." },
    { en: "to book", pt: "reservar, marcar", pron: "tu buk", ex: "I booked an appointment for Monday.", exPt: "Marquei uma consulta para segunda." }
  ],
  dica: "Aprenda a frase <strong>Could you explain that again, please?</strong> — em consultas médicas e documentos oficiais, compreender bem vale mais do que parecer fluente.",
  exercicios: [
    { tipo: "escolha", perg: "Como dizes ao médico que tens dor de garganta?", opcoes: ["I have a sore throat.", "I have a sore leg.", "I have a head throat."], correta: 0, explica: "'Sore throat' = garganta inflamada." },
    { tipo: "escolha", perg: "Queres marcar uma consulta:", opcoes: ["I want to book an appointment.", "I need a prescription now.", "I have a bill."], correta: 0, explica: "'Book an appointment' = marcar consulta." },
    { tipo: "completar", perg: "Completa:", frase: "What documents do I ___ to open an account?", resposta: ["need"], explica: "'Do I need' — pergunta com auxiliar do." },
    { tipo: "traducao", perg: "Traduz: Preciso de uma receita para esta tosse.", resposta: ["i need a prescription for this cough", "i need a prescription for a cough"], explica: "'Prescription' é receita médica; 'recipe' é receita de culinária." },
    { tipo: "ordenar", perg: "Organiza:", palavras: ["appointment", "book", "I", "would", "like", "to", "an"], resposta: "I would like to book an appointment", explica: "'Would like to' = gostaria de, forma educada." },
    { tipo: "escuta", perg: "Ouve e escolhe o problema descrito:", audio: "I have had a headache for three days and I feel tired.", opcoes: ["dor de cabeça", "dor de dentes", "dor nas costas"], correta: 0, explica: "Headache = dor de cabeça. Note 'have had ... for three days' (present perfect)." }
  ]
},
{
  id: "real-05", nivel: "real", ordem: 5, icone: "📱", min: 18,
  titulo: "Conversa social e fazer amigos",
  resumo: "Small talk: o que dizer em festas, vizinhos e redes sociais.",
  objetivos: ["Iniciar conversa com estranhos", "Falar de gostos e tempo livre", "Terminar uma conversa com elegância"],
  explicacao: [
    { t: "O que é small talk", p: "Conversa leve sobre tempo, local, trânsito, desporto. Não é superficialismo — é o protocolo que abre portas para conversas reais." },
    { t: "Abrir conversa", p: "<strong>Lovely day, isn't it?</strong> (Está um dia bonito, não está?) <strong>Is this your first time here?</strong> <strong>How do you know the host?</strong> (Como conheces o anfitrião?) <strong>Where are you from originally?</strong>" },
    { t: "Falar de gostos", p: "<strong>I am really into football.</strong> (Gosto muito de futebol.) <strong>I am not that keen on cooking.</strong> (Não gosto muito de cozinhar.) <strong>I have recently started learning to play guitar.</strong> Este último padrão — present perfect + -ing — faz maravilhas." },
    { t: "Sair de uma conversa", p: "<strong>It was lovely talking to you, but I should go and say hello to someone.</strong> <strong>Let's keep in touch.</strong> <strong>I will message you on WhatsApp.</strong> Nunca desapareça sem uma frase de despedida." }
  ],
  vocabulario: [
    { en: "small talk", pt: "conversa informal", pron: "smol tok", ex: "British people love small talk about the weather.", exPt: "Os britânicos gostam de conversas informais sobre o tempo." },
    { en: "to be into", pt: "gostar muito de", pron: "tu bi ÍN-tu", ex: "I am into photography.", exPt: "Gosto muito de fotografia." },
    { en: "to be keen on", pt: "ser fã de", pron: "tu bi kiin on", ex: "She is very keen on music.", exPt: "Ela é muito fã de música." },
    { en: "neighbour", pt: "vizinho", pron: "NÊI-bâr", ex: "My neighbour is friendly.", exPt: "O meu vizinho é simpático." },
    { en: "host", pt: "anfitrião", pron: "rôust", ex: "The host is very welcoming.", exPt: "O anfitrião é muito acolhedor." },
    { en: "to keep in touch", pt: "manter contacto", pron: "tu kiip in tâtch", ex: "Let's keep in touch.", exPt: "Vamos manter contacto." },
    { en: "free time", pt: "tempo livre", pron: "frii taim", ex: "What do you do in your free time?", exPt: "O que fazes no teu tempo livre?" },
    { en: "lovely", pt: "agradável, bonito", pron: "LÂV-li", ex: "It was lovely talking to you.", exPt: "Foi agradável falar contigo." }
  ],
  dica: "Nas culturas anglófonas, perguntar 'How much do you earn?' é considerado indelicado. Fale de tempo, comida, desporto e viagens — nunca de salário, política ou religião com quem acabou de conhecer.",
  exercicios: [
    { tipo: "escolha", perg: "Como abrir conversa sobre o tempo?", opcoes: ["Lovely day, isn't it?", "How much money do you make?", "Why are you here?"], correta: 0, explica: "Comentário + tag question é o padrão do small talk." },
    { tipo: "escolha", perg: "O que significa 'I am into music'?", opcoes: ["Estou dentro da música", "Gosto muito de música", "Ouço música baixo"], correta: 1, explica: "'Be into something' = gostar muito." },
    { tipo: "completar", perg: "Completa:", frase: "Let's keep in ___. (contacto)", resposta: ["touch"], explica: "'Keep in touch' é a expressão fixa." },
    { tipo: "traducao", perg: "Traduz: O que fazes no teu tempo livre?", resposta: ["what do you do in your free time", "what do you do on your free time"], explica: "Pergunta social universal e segura." },
    { tipo: "ordenar", perg: "Organiza:", palavras: ["talking", "lovely", "It", "was", "you", "to"], resposta: "It was lovely talking to you", explica: "Fórmula de despedida amigável." },
    { tipo: "fala", perg: "Pratica 3 frases de small talk em voz alta.", frase: "Lovely day, isn't it? I am originally from Maputo but I have lived in Lisbon for two years. What about you?", dica: "Termine sempre com uma pergunta para devolver a conversa." }
  ]
}
);
