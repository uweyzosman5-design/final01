/* ============================================================
   English Fácil — Currículo: Nível Intermédio (B1–B2)
   ============================================================ */
window.EF = window.EF || {};
window.EF.licoes = window.EF.licoes || [];

window.EF.licoes.push(
{
  id: "b1-01", nivel: "intermediario", ordem: 1, icone: "⏳", min: 20,
  titulo: "Passado simples: contar histórias",
  resumo: "Ontem, na semana passada, em 2010 — falar do que já aconteceu.",
  objetivos: ["Formar o passado regular (-ed)", "Usar os irregulares mais comuns", "Fazer negativas e perguntas no passado"],
  explicacao: [
    { t: "O passado mais usado", p: "O <strong>past simple</strong> descreve ações terminadas no passado. Para verbos regulares basta acrescentar <strong>-ed</strong>: <em>work → worked</em>, <em>play → played</em>, <em>visit → visited</em>." },
    { t: "Verbos irregulares (memorizar é inevitável)", p: "Os 12 mais frequentes: <em>go → went, have → had, do → did, say → said, get → got, make → made, know → knew, come → came, see → saw, take → took, think → thought, eat → ate</em>. Aprenda 3 por dia — em duas semanas fica com os essenciais." },
    { t: "Negativa e pergunta: did", p: "Com <strong>did</strong>, o verbo volta ao presente: <em>I did not go</em> (não 'did not went'). Pergunta: <em>Did you see him?</em> Resposta curta: <em>Yes, I did</em> / <em>No, I didn't</em>." },
    { t: "Marcadores de tempo", p: "<strong>yesterday</strong> (ontem), <strong>last week/month/year</strong> (semana/mês/ano passado), <strong>two days ago</strong> (há dois dias — ago vem depois), <strong>in 2015</strong>, <strong>when I was young</strong>." }
  ],
  tabela: {
    titulo: "Regulares vs irregulares",
    cabecalho: ["Presente", "Passado", "Português"],
    linhas: [["work", "worked", "trabalhei"], ["study", "studied", "estudei"], ["stop", "stopped", "parei"], ["go", "went", "fui"], ["buy", "bought", "comprei"], ["speak", "spoke", "falei"]]
  },
  vocabulario: [
    { en: "yesterday", pt: "ontem", pron: "IÉS-târ-dêi", ex: "Yesterday I went to the market.", exPt: "Ontem fui ao mercado." },
    { en: "last night", pt: "ontem à noite", pron: "lést NAIT", ex: "Last night I studied English.", exPt: "Ontem à noite estudei inglês." },
    { en: "ago", pt: "há (tempo atrás)", pron: "â-GÔU", ex: "I arrived two years ago.", exPt: "Cheguei há dois anos." },
    { en: "to arrive", pt: "chegar", pron: "tu â-RAIV", ex: "She arrived late.", exPt: "Ela chegou tarde." },
    { en: "to buy", pt: "comprar", pron: "tu BAI", ex: "I bought a new phone.", exPt: "Comprei um telemóvel novo." },
    { en: "to meet", pt: "encontrar, conhecer", pron: "tu MÍIT", ex: "We met in 2019.", exPt: "Conhecemo-nos em 2019." },
    { en: "story", pt: "história", pron: "STÔ-ri", ex: "Tell me a story about your trip.", exPt: "Conta-me uma história da tua viagem." },
    { en: "suddenly", pt: "de repente", pron: "SÂ-dân-li", ex: "Suddenly, it started to rain.", exPt: "De repente, começou a chover." }
  ],
  dica: "Nunca diga <s>I didn't went</s>. Depois de <strong>did / didn't</strong> o verbo fica sempre no presente: <em>I didn't go</em>. É a regra mais violada por quem fala português.",
  exercicios: [
    { tipo: "escolha", perg: "Completa: I ___ to the beach last weekend.", opcoes: ["go", "went", "gone"], correta: 1, explica: "'Go' é irregular: go → went. 'Gone' é o particípio, usado com 'have'." },
    { tipo: "escolha", perg: "Qual frase está correta?", opcoes: ["I didn't saw him.", "I didn't see him.", "I not saw him."], correta: 1, explica: "Depois de 'didn't' usa-se o verbo no presente: see." },
    { tipo: "completar", perg: "Completa:", frase: "She ___ (buy) a car two years ___.", resposta: ["bought ago"], dica: "Verbo irregular + marcador de tempo depois do período.", explica: "Bought (comprei) + 'ago' depois do tempo: two years ago." },
    { tipo: "traducao", perg: "Traduz: Ontem estudei inglês durante duas horas.", resposta: ["yesterday i studied english for two hours", "yesterday i studied english for 2 hours"], explica: "Duração usa 'for': for two hours." },
    { tipo: "ordenar", perg: "Organiza:", palavras: ["did", "What", "yesterday", "you", "do"], resposta: "What did you do yesterday", explica: "Interrogativa + auxiliar did + sujeito + verbo base." },
    { tipo: "escrita", perg: "Escreve 3 frases sobre o teu último fim de semana, no passado.", exemplo: "Last Saturday I visited my family. We ate lunch together. In the evening I watched a film.", explica: "Use marcadores de tempo no início para dar contexto." }
  ]
},
{
  id: "b1-02", nivel: "intermediario", ordem: 2, icone: "🎯", min: 18,
  titulo: "Present perfect vs. passado simples",
  resumo: "A diferença que separa o intermédio do avançado.",
  objetivos: ["Usar have/has + particípio", "Distinguir ever/never/just/already/yet", "Escolher entre present perfect e past simple"],
  explicacao: [
    { t: "O que é o present perfect", p: "Forma: <strong>have / has + particípio passado</strong>. <em>I have visited London.</em> Usa-se quando o momento exato não importa ou quando a ação continua a ter efeito no presente." },
    { t: "A regra prática", p: "Se dizes o momento exato → <strong>past simple</strong>: <em>I saw him yesterday</em>. Se não dizes quando, ou usas 'ever/never/just/already/yet' → <strong>present perfect</strong>: <em>I have seen him</em>. Foque na presença ou ausência de tempo definido." },
    { t: "Palavras que pedem present perfect", p: "<strong>ever</strong> (alguma vez), <strong>never</strong> (nunca), <strong>just</strong> (acabou de), <strong>already</strong> (já), <strong>yet</strong> (ainda — em negativas/perguntas), <strong>since</strong> (desde), <strong>for</strong> (durante)." },
    { t: "Português vs inglês", p: "Em português dizemos 'Já comi' e usamos passado. Em inglês 'I have already eaten' — present perfect. Este é o ponto em que os falantes de português mais escorregam." }
  ],
  tabela: {
    titulo: "Comparação direta",
    cabecalho: ["Situação", "Frase", "Porquê"],
    linhas: [["Vi-o ontem", "I saw him yesterday", "tempo definido"], ["Já vi este filme", "I have already seen this film", "sem tempo definido"], ["Vivo aqui desde 2020", "I have lived here since 2020", "continua"], ["Trabalhei lá 3 anos", "I worked there for 3 years", "terminou"]]
  },
  vocabulario: [
    { en: "ever", pt: "alguma vez", pron: "ÉV-âr", ex: "Have you ever been to London?", exPt: "Alguma vez estiveste em Londres?" },
    { en: "never", pt: "nunca", pron: "NÉV-âr", ex: "I have never eaten sushi.", exPt: "Nunca comi sushi." },
    { en: "already", pt: "já", pron: "ol-RÉ-di", ex: "She has already finished.", exPt: "Ela já terminou." },
    { en: "yet", pt: "ainda (em perguntas/negativas)", pron: "iét", ex: "I haven't finished yet.", exPt: "Ainda não terminei." },
    { en: "since", pt: "desde", pron: "sins", ex: "I have worked here since 2018.", exPt: "Trabalho aqui desde 2018." },
    { en: "for", pt: "durante, há", pron: "for", ex: "I have studied for two hours.", exPt: "Estudo há duas horas." },
    { en: "experience", pt: "experiência", pron: "eks-PÍ-ri-âns", ex: "It was a great experience.", exPt: "Foi uma ótima experiência." },
    { en: "recently", pt: "recentemente", pron: "RÍI-sânt-li", ex: "I have recently changed jobs.", exPt: "Mudei de emprego recentemente." }
  ],
  dica: "Pergunta de ouro: <strong>Have you ever...?</strong> com o particípio. Serve para criar conversa com qualquer pessoa, em qualquer lugar do mundo.",
  exercicios: [
    { tipo: "escolha", perg: "Completa: I ___ never been to Asia.", opcoes: ["have", "has", "am"], correta: 0, explica: "Com 'I' usa-se 'have': I have never been." },
    { tipo: "escolha", perg: "Qual frase está correta?", opcoes: ["I have seen him yesterday.", "I saw him yesterday.", "I have saw him yesterday."], correta: 1, explica: "'Yesterday' indica tempo definido → past simple." },
    { tipo: "completar", perg: "Completa:", frase: "She has lived here ___ 2019. (desde)", resposta: ["since"], explica: "'Since' + ponto no tempo; 'for' + duração." },
    { tipo: "traducao", perg: "Traduz: Já terminei o meu trabalho.", resposta: ["i have already finished my work", "i've already finished my work", "i have already finished work"], explica: "'Já' no sentido de ação completa → already + present perfect." },
    { tipo: "ordenar", perg: "Organiza:", palavras: ["ever", "Have", "to", "been", "you", "Brazil"], resposta: "Have you ever been to Brazil", explica: "Estrutura: have + sujeito + ever + particípio + to + lugar." },
    { tipo: "escuta", perg: "Ouve e escolhe o significado:", audio: "I haven't finished yet.", opcoes: ["Já terminei.", "Ainda não terminei.", "Nunca termino."], correta: 1, explica: "'Haven't ... yet' = ainda não (mas vou terminar)." }
  ]
},
{
  id: "b1-03", nivel: "intermediario", ordem: 3, icone: "🔮", min: 18,
  titulo: "Futuro: will, going to e presente contínuo",
  resumo: "Planos, previsões e decisões do momento.",
  objetivos: ["Usar will para decisões e promessas", "Usar going to para planos", "Usar o presente contínuo para futuro próximo"],
  explicacao: [
    { t: "Will — decisão na hora", p: "<strong>will + verbo</strong>. Usa-se para decisões tomadas no momento, promessas e previsões: <em>I will help you. It will rain tomorrow. I will call you.</em> Negativa: <em>won't</em>." },
    { t: "Going to — plano já decidido", p: "<strong>am/is/are + going to + verbo</strong>. <em>I am going to visit my parents next month.</em> A decisão já existe. Também serve para previsões com evidência: <em>Look at those clouds — it is going to rain.</em>" },
    { t: "Presente contínuo para futuro", p: "Para compromissos marcados: <em>I am meeting the client at 10 tomorrow.</em> É o mais natural quando já está na agenda." },
    { t: "Como escolher", p: "Decisão do momento → <strong>will</strong>. Intenção/plano → <strong>going to</strong>. Compromisso marcado → <strong>presente contínuo</strong>. Na prática, os nativos usam os três de forma flexível — não tenha medo de errar." }
  ],
  vocabulario: [
    { en: "tomorrow", pt: "amanhã", pron: "tâ-MÔ-rôu", ex: "I will see you tomorrow.", exPt: "Vejo-te amanhã." },
    { en: "next week", pt: "na próxima semana", pron: "nékst UÍIK", ex: "We are going to travel next week.", exPt: "Vamos viajar na próxima semana." },
    { en: "to plan", pt: "planear", pron: "tu PLÉN", ex: "I am planning a trip.", exPt: "Estou a planear uma viagem." },
    { en: "probably", pt: "provavelmente", pron: "PRÓ-bâ-bli", ex: "I will probably arrive late.", exPt: "Provavelmente vou chegar tarde." },
    { en: "maybe", pt: "talvez", pron: "MÊI-bi", ex: "Maybe I will study tonight.", exPt: "Talvez estude esta noite." },
    { en: "to promise", pt: "prometer", pron: "tu PRÓ-mis", ex: "I promise I will call.", exPt: "Prometo que vou ligar." },
    { en: "appointment", pt: "consulta, compromisso", pron: "â-PÔINT-mânt", ex: "I have an appointment at three.", exPt: "Tenho um compromisso às três." },
    { en: "soon", pt: "em breve", pron: "suun", ex: "See you soon!", exPt: "Até breve!" }
  ],
  dica: "Em inglês britânico e em Moçambique, 'I will' + verbo é a forma mais segura. Se hesitar entre will e going to, use <strong>will</strong> — raramente está errado.",
  exercicios: [
    { tipo: "escolha", perg: "O telefone toca. Dizes:", opcoes: ["I am going to answer it.", "I will answer it.", "I answer it."], correta: 1, explica: "Decisão tomada no momento → will." },
    { tipo: "escolha", perg: "Completa: We ___ visit our family next month. (plano já decidido)", opcoes: ["will", "are going to", "go"], correta: 1, explica: "Plano definido → going to." },
    { tipo: "completar", perg: "Completa a negativa:", frase: "I ___ come tomorrow, I am busy. (won't)", resposta: ["will not", "won't", "wont"], explica: "Negativa de will: will not / won't." },
    { tipo: "traducao", perg: "Traduz: Vou estudar inglês amanhã.", resposta: ["i am going to study english tomorrow", "i will study english tomorrow", "i'm going to study english tomorrow"], explica: "As duas formas são aceitáveis; 'going to' se já é um plano." },
    { tipo: "ordenar", perg: "Organiza:", palavras: ["probably", "will", "I", "late", "arrive"], resposta: "I will probably arrive late", explica: "'Probably' fica entre will e o verbo." },
    { tipo: "fala", perg: "Fala em voz alta os teus planos para o próximo ano (3 frases).", frase: "Next year I am going to improve my English. I will travel more. I will work hard.", dica: "Lê devagar e grava-te para comparar." }
  ]
},
{
  id: "b1-04", nivel: "intermediario", ordem: 4, icone: "📖", min: 20,
  titulo: "Compreensão de textos e conectores",
  resumo: "Ler um artigo em inglês sem tradutor, do início ao fim.",
  objetivos: ["Identificar a ideia principal de um texto", "Usar conectores de causa, contraste e adição", "Deduzir palavras pelo contexto"],
  explicacao: [
    { t: "Estratégia de leitura", p: "Não leia palavra por palavra. Primeiro leia o título e a primeira frase de cada parágrafo (skimming). Depois procure informações específicas (scanning). Só no fim traduza o que ficou obscuro." },
    { t: "Conectores de adição", p: "<strong>and, also, moreover, in addition, furthermore</strong>. Servem para somar ideias. Num texto, indicam que vem mais do mesmo assunto." },
    { t: "Conectores de contraste", p: "<strong>but, however, although, even though, whereas, on the other hand</strong>. Quando vê 'however', prepare-se: a ideia vai mudar de direção. É a pista mais valiosa na leitura." },
    { t: "Causa e consequência", p: "<strong>because, since, as</strong> (porque), <strong>so, therefore, as a result, consequently</strong> (por isso). Dominar estes dez conectores melhora a escrita mais do que aprender 500 palavras novas." }
  ],
  tabela: {
    titulo: "Conectores por função",
    cabecalho: ["Função", "Conectores", "Exemplo"],
    linhas: [["Adição", "and, also, moreover", "It is cheap and fast."], ["Contraste", "but, however, although", "It is cheap; however, it is slow."], ["Causa", "because, since, as", "I study because I need it."], ["Consequência", "so, therefore", "I need it, so I study."], ["Exemplo", "for example, such as", "Languages, such as English."], ["Conclusão", "in conclusion, finally", "In conclusion, practice works."]]
  },
  vocabulario: [
    { en: "however", pt: "no entanto", pron: "rau-ÉV-âr", ex: "The test was hard; however, I passed.", exPt: "O teste foi difícil; no entanto, passei." },
    { en: "although", pt: "embora", pron: "ol-DHÔU", ex: "Although it was raining, we went out.", exPt: "Embora estivesse a chover, saímos." },
    { en: "therefore", pt: "portanto", pron: "DHÉR-for", ex: "He was late; therefore, he missed the bus.", exPt: "Ele atrasou-se; portanto, perdeu o autocarro." },
    { en: "such as", pt: "tal como", pron: "sâtch éz", ex: "Fruits such as mango and banana.", exPt: "Frutas tal como manga e banana." },
    { en: "main idea", pt: "ideia principal", pron: "mein ai-DÍ-â", ex: "What is the main idea of the text?", exPt: "Qual é a ideia principal do texto?" },
    { en: "to improve", pt: "melhorar", pron: "tu im-PRÚUV", ex: "Reading improves your vocabulary.", exPt: "Ler melhora o teu vocabulário." },
    { en: "in conclusion", pt: "em conclusão", pron: "in kân-KLÚU-zhân", ex: "In conclusion, practice is essential.", exPt: "Em conclusão, a prática é essencial." },
    { en: "research", pt: "pesquisa", pron: "ri-SÂRTCH", ex: "Research shows that reading helps.", exPt: "A pesquisa mostra que ler ajuda." }
  ],
  dica: "Regra de ouro da leitura: se não conheces uma palavra, não pares. Continue até ao fim do parágrafo e volte. Em 80% dos casos o contexto revela o significado.",
  exercicios: [
    { tipo: "escolha", perg: "Qual conector introduz contraste?", opcoes: ["moreover", "however", "therefore"], correta: 1, explica: "'However' = no entanto, introduz contraste." },
    { tipo: "escolha", perg: "Completa: ___ it was expensive, I bought it.", opcoes: ["Although", "Because", "So"], correta: 0, explica: "'Although' = embora, introduz uma concessão." },
    { tipo: "completar", perg: "Completa:", frase: "I was tired, ___ I went to bed early. (por isso)", resposta: ["so"], explica: "'So' liga causa e consequência numa frase simples." },
    { tipo: "traducao", perg: "Traduz: Estudo inglês porque quero um emprego melhor.", resposta: ["i study english because i want a better job", "i study english because i want a better job"], explica: "'Because' introduce a causa. Note: better job, adjetivo antes do substantivo." },
    { tipo: "ordenar", perg: "Organiza:", palavras: ["reading", "improves", "vocabulary", "Your"], resposta: "Your reading improves vocabulary", explica: "Sujeito + verbo + complemento." },
    { tipo: "escrita", perg: "Escreve um parágrafo de 4 frases com pelo menos 2 conectores (however, therefore, because, although).", exemplo: "Learning English is important. However, it takes time. I study every day because I want to travel. Therefore, I practise listening and speaking.", explica: "Verifique se usou os conectores no início da frase, seguidos de vírgula." }
  ]
},
{
  id: "b1-05", nivel: "intermediario", ordem: 5, icone: "🗣️", min: 18,
  titulo: "Phrasal verbs essenciais",
  resumo: "Verbos com preposições que mudam tudo — e que os nativos usam sempre.",
  objetivos: ["Reconhecer os 15 phrasal verbs mais usados", "Entender o sentido pelo contexto", "Usar phrasal verbs em conversa"],
  explicacao: [
    { t: "O que são", p: "Um verbo + partícula que cria um significado novo. <em>give</em> = dar; <em>give up</em> = desistir. Não tente traduzir palavra a palavra — aprenda o bloco inteiro." },
    { t: "Separáveis e inseparáveis", p: "Alguns aceitam o objeto no meio: <em>turn on the light / turn the light on</em>. Outros não: <em>look after the baby</em> (nunca 'look the baby after'). Na dúvida, mantenha o objeto no fim." },
    { t: "Os 10 que vai ouvir hoje", p: "<strong>get up</strong> (levantar-se), <strong>wake up</strong>, <strong>look for</strong> (procurar), <strong>find out</strong> (descobrir), <strong>give up</strong> (desistir), <strong>turn on/off</strong>, <strong>pick up</strong> (apanhar/buscar), <strong>come back</strong> (voltar), <strong>take care of</strong> (cuidar), <strong>run out of</strong> (ficar sem)." },
    { t: "Estratégia de estudo", p: "Não estude listas de 200 phrasal verbs. Aprenda 5 por semana, sempre dentro de uma frase real que você criou. A memória guarda histórias, não listas." }
  ],
  tabela: {
    titulo: "Phrasal verbs por tema",
    cabecalho: ["Phrasal verb", "Significado", "Exemplo"],
    linhas: [["look for", "procurar", "I am looking for my keys."], ["find out", "descobrir", "I found out the truth."], ["give up", "desistir", "Never give up."], ["get along", "dar-se bem", "We get along well."], ["look forward to", "aguardar com expectativa", "I look forward to your reply."], ["put off", "adiar", "They put off the meeting."]]
  },
  vocabulario: [
    { en: "to look for", pt: "procurar", pron: "tu LUK for", ex: "I am looking for a job.", exPt: "Estou à procura de emprego." },
    { en: "to give up", pt: "desistir", pron: "tu GUIV âp", ex: "Do not give up on your English.", exPt: "Não desistas do teu inglês." },
    { en: "to find out", pt: "descobrir", pron: "tu FAIND aut", ex: "I found out that he is my neighbour.", exPt: "Descobri que ele é meu vizinho." },
    { en: "to turn on / off", pt: "ligar / desligar", pron: "tu TÂRN on / of", ex: "Please turn off the light.", exPt: "Por favor, desliga a luz." },
    { en: "to come back", pt: "voltar", pron: "tu kâm BÉK", ex: "She came back yesterday.", exPt: "Ela voltou ontem." },
    { en: "to get up", pt: "levantar-se", pron: "tu guét ÂP", ex: "I get up at six.", exPt: "Levanto-me às seis." },
    { en: "to look forward to", pt: "aguardar com expectativa", pron: "tu luk FÔR-uârd tu", ex: "I look forward to meeting you.", exPt: "Aguardo com expectativa conhecer-te." },
    { en: "to run out of", pt: "ficar sem", pron: "tu rân ÁUT ov", ex: "We ran out of milk.", exPt: "Ficámos sem leite." }
  ],
  dica: "Quando ouvir um phrasal verb desconhecido numa série, anote a frase inteira — não só o verbo. A frase é o que o cérebro recorda.",
  exercicios: [
    { tipo: "escolha", perg: "I am ___ a new apartment.", opcoes: ["looking for", "looking after", "looking at"], correta: 0, explica: "'Look for' = procurar. 'Look after' = cuidar; 'look at' = olhar para." },
    { tipo: "escolha", perg: "O que significa 'give up'?", opcoes: ["levantar", "desistir", "entregar"], correta: 1, explica: "'Give up' = desistir. 'Give back' = devolver; 'give in' = ceder." },
    { tipo: "completar", perg: "Completa:", frase: "Please ___ off the light before you leave. (desligar)", resposta: ["turn"], explica: "'Turn off' = desligar; 'turn on' = ligar." },
    { tipo: "traducao", perg: "Traduz: Nunca desistas de aprender inglês.", resposta: ["never give up learning english", "never give up on learning english"], explica: "'Give up + -ing' descreve a atividade abandonada." },
    { tipo: "ordenar", perg: "Organiza:", palavras: ["up", "Never", "give"], resposta: "Never give up", explica: "Frase motivacional clássica e muito usada." },
    { tipo: "escuta", perg: "Ouve e escolhe o phrasal verb ouvido:", audio: "I am looking forward to your reply.", opcoes: ["looking forward to", "looking after", "looking for"], correta: 0, explica: "'Look forward to' expressa expectativa positiva." }
  ]
},
{
  id: "b1-06", nivel: "intermediario", ordem: 6, icone: "🎧", min: 22,
  titulo: "Listening ativo: ouvir e entender nativos",
  resumo: "Porque é que os nativos parecem falar depressa — e como treinar o ouvido.",
  objetivos: ["Reconhecer a ligação entre palavras (linking)", "Entender formas reduzidas (gonna, wanna)", "Criar um plano de listening diário"],
  explicacao: [
    { t: "O segredo: não falam depressa, falam ligado", p: "Em inglês as palavras encostam umas às outras: <em>an apple</em> soa 'anapple'; <em>what are you</em> soa 'wha-cha'. O ouvido treinado reconhece blocos, não palavras isoladas." },
    { t: "Reduções comuns", p: "<strong>going to → gonna</strong>, <strong>want to → wanna</strong>, <strong>kind of → kinda</strong>, <strong>let me → lemme</strong>, <strong>them → 'em</strong>. São informais, mas estão em toda a parte em séries e músicas." },
    { t: "Método de 3 passos", p: "1) Ouça sem texto e anote o que entendeu. 2) Ouça com a transcrição e marque o que falhou. 3) Repita em voz alta imitando o ritmo. Este ciclo de 10 minutos vale mais do que uma hora de escuta passiva." },
    { t: "Onde treinar", p: "Podcasts para aprendizes (6 Minute English), canais de notícias com legendas (BBC, DW), séries com legendas em inglês — nunca em português. E este site: use o botão de áudio em cada palavra." }
  ],
  vocabulario: [
    { en: "to listen", pt: "ouvir (com atenção)", pron: "tu LÍS-ân", ex: "Listen to this song.", exPt: "Ouve esta música." },
    { en: "to hear", pt: "ouvir (perceber som)", pron: "tu RÍR", ex: "Can you hear me?", exPt: "Consegues ouvir-me?" },
    { en: "pronunciation", pt: "pronúncia", pron: "prâ-nân-si-ÊI-zhân", ex: "Your pronunciation is improving.", exPt: "A tua pronúncia está a melhorar." },
    { en: "accent", pt: "sotaque", pron: "ÉK-sânt", ex: "He has a British accent.", exPt: "Ele tem sotaque britânico." },
    { en: "to repeat", pt: "repetir", pron: "tu ri-PÍIT", ex: "Repeat after me.", exPt: "Repete depois de mim." },
    { en: "subtitle", pt: "legenda", pron: "SÂB-tai-tâl", ex: "Turn on the English subtitles.", exPt: "Liga as legendas em inglês." },
    { en: "fast", pt: "rápido", pron: "fést", ex: "You speak too fast.", exPt: "Falas demasiado rápido." },
    { en: "loud", pt: "alto (som)", pron: "laud", ex: "Please speak louder.", exPt: "Por favor, fala mais alto." }
  ],
  dica: "Nunca use legendas em português. O cérebro desliga o ouvido e lê. Comece com legendas em inglês e depois desligue-as progressivamente.",
  exercicios: [
    { tipo: "escuta", perg: "Ouve e escolhe o que foi dito:", audio: "What are you going to do?", opcoes: ["What are you going to do?", "Where are you going to go?", "What did you do?"], correta: 0, explica: "Na fala rápida 'what are you' liga-se e soa como 'whatcha'." },
    { tipo: "escolha", perg: "O que significa 'gonna' na fala informal?", opcoes: ["going to", "got to", "gone"], correta: 0, explica: "'Gonna' é a redução de 'going to'. 'Got to' reduz-se a 'gotta'." },
    { tipo: "escuta", perg: "Ouve e identifica a palavra reduzida:", audio: "I wanna learn English.", opcoes: ["want to", "went to", "need to"], correta: 0, explica: "'Wanna' = want to, muito comum em música e séries." },
    { tipo: "completar", perg: "Completa:", frase: "Please speak ___, I cannot hear you. (mais alto)", resposta: ["louder"], explica: "Comparativo de 'loud' → louder." },
    { tipo: "traducao", perg: "Traduz: Podes repetir mais devagar, por favor?", resposta: ["can you repeat more slowly please", "could you repeat more slowly please", "can you repeat slower please"], explica: "'Could you' é mais educado do que 'can you'." },
    { tipo: "fala", perg: "Lê em voz alta imitando o áudio:", frase: "What are you going to do tonight? I am going to study English.", dica: "Liga as palavras: 'wha-cha gonna do'. Não separe cada palavra." }
  ]
},
{
  id: "b2-01", nivel: "intermediario", ordem: 7, icone: "🧩", min: 20,
  titulo: "Condicionais e hipóteses",
  resumo: "Se eu fosse..., se eu tivesse..., eu teria... — falar de possibilidades.",
  objetivos: ["Usar o first conditional", "Usar o second conditional", "Evitar o erro clássico do 'would' no if"],
  explicacao: [
    { t: "First conditional — futuro real", p: "<strong>If + presente, will + verbo.</strong> <em>If it rains, I will stay home.</em> Situação possível no futuro. Note: nunca se usa 'will' depois de 'if'." },
    { t: "Second conditional — hipótese irreal", p: "<strong>If + passado, would + verbo.</strong> <em>If I had money, I would travel.</em> Imaginação, situação improvável. O passado aqui não indica tempo — indica distância da realidade." },
    { t: "O erro mais comum", p: "Dizer <s>If I would have money</s>. Nunca use 'would' na parte com 'if'. O 'would' fica na segunda parte: <em>If I had money, I would buy a house.</em>" },
    { t: "Third conditional (avançado)", p: "<strong>If + had + particípio, would have + particípio.</strong> <em>If I had studied, I would have passed.</em> Arrependimento sobre o passado — não é possível mudar." }
  ],
  tabela: {
    titulo: "Os três condicionais",
    cabecalho: ["Tipo", "Estrutura", "Exemplo"],
    linhas: [["1º", "If + presente, will", "If you study, you will pass."], ["2º", "If + passado, would", "If I were you, I would study."], ["3º", "If + had + p.p., would have", "If I had known, I would have come."]]
  },
  vocabulario: [
    { en: "if", pt: "se", pron: "if", ex: "If you want, we can study together.", exPt: "Se quiseres, podemos estudar juntos." },
    { en: "unless", pt: "a menos que", pron: "ân-LÉS", ex: "I will not go unless you come.", exPt: "Não vou a menos que venhas." },
    { en: "would", pt: "(condicional) -ia", pron: "uud", ex: "I would like some water.", exPt: "Gostaria de um pouco de água." },
    { en: "possible", pt: "possível", pron: "PÓ-si-bâl", ex: "It is possible to learn fast.", exPt: "É possível aprender rápido." },
    { en: "imagine", pt: "imagina", pron: "i-MÉ-djin", ex: "Imagine you had one year off.", exPt: "Imagina que tinhas um ano livre." },
    { en: "chance", pt: "chance, oportunidade", pron: "tchéns", ex: "This is your chance to speak.", exPt: "Esta é a tua oportunidade de falar." },
    { en: "advice", pt: "conselho", pron: "âd-VAIS", ex: "If I were you, I would take the advice.", exPt: "Se eu fosse tu, seguiria o conselho." },
    { en: "luck", pt: "sorte", pron: "lâk", ex: "Good luck with your exam!", exPt: "Boa sorte no teu exame!" }
  ],
  dica: "<strong>If I were you, I would...</strong> (Se eu fosse tu, ...) é a forma mais elegante de dar conselhos em inglês. Guarde esta frase pronta.",
  exercicios: [
    { tipo: "escolha", perg: "Completa: If it ___, we will cancel the trip.", opcoes: ["will rain", "rains", "rained"], correta: 1, explica: "Depois de 'if' usa-se presente, mesmo falando do futuro." },
    { tipo: "escolha", perg: "Qual frase está correta?", opcoes: ["If I would have a car, I would drive.", "If I had a car, I would drive.", "If I have a car, I would drive."], correta: 1, explica: "Second conditional: if + passado, would + verbo." },
    { tipo: "completar", perg: "Completa:", frase: "If I ___ you, I would accept the job. (se eu fosse)", resposta: ["were", "was"], explica: "'If I were you' é a forma fixa preferida em inglês." },
    { tipo: "traducao", perg: "Traduz: Se eu tivesse tempo, estudaria mais.", resposta: ["if i had time i would study more", "if i had time i would study more english"], explica: "Second conditional: had + would study." },
    { tipo: "ordenar", perg: "Organiza:", palavras: ["will", "you", "If", "study", "pass", "you"], resposta: "If you study you will pass", explica: "First conditional: if + presente, will + verbo." },
    { tipo: "escrita", perg: "Escreve 2 frases com 'If I were...' sobre a tua vida.", exemplo: "If I were rich, I would travel around the world. If I were the president, I would improve education.", explica: "Use 'would + verbo' na segunda parte, sempre." }
  ]
}
);
