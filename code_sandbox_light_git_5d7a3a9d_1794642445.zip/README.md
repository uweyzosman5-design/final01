# English Fácil

Plataforma de aprendizagem de inglês do zero ao avançado, totalmente em português, pensada para falantes de português de **Moçambique, Portugal e Brasil**. Site estático (HTML + CSS + JavaScript puro, sem build step), com interface responsiva, modo escuro, gamificação, dicionário, professor virtual e painel administrativo.

---

## Páginas e caminhos de entrada

| Caminho | Descrição |
| --- | --- |
| `index.html` | Página inicial: hero, vantagens, níveis, aulas gratuitas, estatísticas/ranking, palavra e frase do dia, depoimentos, contacto, FAQ |
| `cursos.html` | Os 4 níveis, lista filtrável/pesquisável das 26 aulas, mini-teste de nível (6 perguntas), certificados |
| `aula.html?id=<id>` | Aula completa: objetivos, explicação, tabela, vocabulário com áudio, exercícios, teste final. Sem `?id`, abre a próxima aula não concluída |
| `exercicios.html` | Prática livre por 7 tipos de exercício, filtro por nível, desafio diário, mini-teste semanal e histórico |
| `conversacao.html` | Professor virtual (chat) + 7 diálogos guiados de situações reais |
| `dicionario.html` | 135+ entradas inglês↔português com áudio, exemplos, sinónimos, antónimos, filtro A-Z, categorias e favoritos |
| `painel.html` | Área do aluno: progresso, pontos, sequência, medalhas, ranking, certificados, favoritos, histórico de testes, definições |
| `certificado.html?nivel=<id>` | Certificado imprimível (bloqueado até 100% do nível) |
| `admin.html` | Painel administrativo: aulas, exercícios, utilizadores, estatísticas, definições |

Parâmetros úteis:
- `aula.html?id=a1-01` — aula específica (ids: `a1-01..a1-08`, `b1-01..b2-01`, `c1-01..c2-03`, `real-01..real-05`)
- `cursos.html?nivel=iniciante|intermediario|avancado|real` — abre já filtrado
- `exercicios.html?tipo=escolha|completar|traducao|ordenar|escuta|escrita|fala` — abre prática desse tipo
- `exercicios.html?desafio=1` — entra direto no desafio do dia
- `dicionario.html?q=palavra` — pesquisa pré-preenchida
- `conversacao.html?tema=<título da aula>` — abre o chat em contexto da aula

---

## Funcionalidades implementadas

### Aprendizagem
- **26 aulas completas** em 4 percursos: Iniciante (A1–A2, 8 aulas), Intermédio (B1–B2, 7), Avançado (C1–C2, 6), Situações reais (5).
- Cada aula: objetivos, explicação em português com HTML rico, tabela de referência, 8–9 palavras/frases com **tradução + pronúncia aproximada + exemplo + tradução do exemplo**, dica do professor, 6–8 exercícios e teste final.
- **Áudio real** em cada palavra/frase via Web Speech API (vozes `en-GB`/`en-US`), com seletor de voz no painel e degradação graciosa quando o navegador não suporta.
- **7 tipos de exercício**: escolha múltipla, completar, tradução, ordenar palavras (drag-por-toque), listening (áudio automático), writing (com exemplo modelo), speaking (MediaRecorder + reprodução da própria voz). Todos com correção **imediata** e explicação do motivo.
- **Teste de nível (C1–C2)** de 6 perguntas com sugestão de nível e primeira aula.
- **Mini-teste semanal** determinístico (mesmas 10 perguntas durante a semana, muda na semana seguinte).

### Professor virtual (`js/core/professor.js`)
Tutor 100% client-side, sem chaves de API e sem custo. Responde a:
- **Tradução**: «Como se diz *obrigado* em inglês?» → usa dicionário + vocabulário das aulas.
- **Significado**: «O que significa *deadline*?»
- **Gramática**: 15 tópicos (present perfect, past simple, to be, artigos, plurais, preposições, present continuous, condicionais, phrasal verbs, pronomes, comparativos, voz passiva, pronúncia, memorização, futuro).
- **Correção**: 22+ regras de erros típicos de lusófonos (`I have 25 years`, `I didn't went`, `he don't`, `more easier`, `informations`, `explain me`, `depends of`, `I am agree`…), mais heurísticas de terceira pessoa (`-s`), maiúscula inicial e pontuação.
- **Diálogos guiados**: restaurante, aeroporto, entrevista de emprego, hotel, médico, conversa social, compras — com avaliação da resposta e sugestão.

### Gamificação
Pontos por aula concluída (20 + bónus até 10), por teste, por desafio e por mensagem ao professor; sequência de dias com recorde; 14 medalhas; 6 níveis de pontuação (Curioso → Fluente); ranking partilhado.

### Contas
Registo/login com email + palavra-passe guardada **como hash SHA-256 com salt** (fallback FNV quando `crypto.subtle` não existe). Sessão persistida. Exportação de dados em JSON e eliminação de conta.

### Admin
Login próprio (por omissão `admin@englishfacil.local` / `englishfacil`, alterável e guardado com hash). Permite criar/editar/remover/reordenar aulas, criar exercícios dos 7 tipos, ver contas locais, ranking, mensagens de contacto, gráficos Chart.js e exportar aulas em JSON.

---

## Arquitetura de ficheiros

```
index.html, cursos.html, aula.html, exercicios.html,
conversacao.html, dicionario.html, painel.html,
certificado.html, admin.html, favicon.svg
css/style.css                  Design system completo (variáveis, dark mode, responsivo, impressão)
js/data/niveis.js              Níveis, medalhas, níveis de pontos, desafios/palavras/frases do dia
js/data/licoes-a1.js           Nível Iniciante (8 aulas)
js/data/licoes-b1.js           Nível Intermédio (7 aulas)
js/data/licoes-c1.js           Nível Avançado (6 aulas)
js/data/licoes-real.js         Situações reais (5 aulas)
js/data/dicionario.js          Dicionário (~135 entradas)
js/core/conteudo.js            Camada de override do conteúdo (edições do admin)
js/core/store.js               Persistência, contas, progresso, pontos, medalhas, ranking
js/core/audio.js               Web Speech API + delegação de [data-falar]
js/core/ui.js                  Cabeçalho/rodapé injetados, toasts, modais, login, tema, reveal
js/core/exercicios.js          Motor de exercícios + criador de testes sequenciais
js/core/professor.js           Motor do professor virtual
js/pages/*.js                  Lógica de cada página
```

### Ordem de scripts (obrigatória)
`data/*` → `core/conteudo.js` → `core/store.js` → `core/audio.js` → `core/ui.js` → `core/exercicios.js` → (`core/professor.js` em conversação) → `pages/*.js`.

---

## Armazenamento de dados

**Duas camadas independentes:**

1. **Contas, progresso, favoritos, medalhas, testes, tema, voz, edições de conteúdo** → `localStorage` do navegador.
   - Chave `englishfacil:v1` — utilizadores, sessão, configuração, envios de ranking.
   - Chave `englishfacil:conteudo:v1` — aulas editadas/criadas/removidas pelo admin.
   - Chave `englishfacil:admin:v1` — credenciais do administrador (hash).
   - `sessionStorage` — sessão do admin e histórico de chat (`englishfacil:chat:v1`).
   - **Os dados são por navegador e por origem.** Não há sincronização entre dispositivos — por isso existe a exportação JSON e a tela de eliminação de conta.

2. **Ranking partilhado e mensagens de contacto** → base de dados da plataforma, via Table API relativo:
   - `tables/ranking` — `nome`, `pontos`, `nivel`, `licoes`, `sequencia` (8 registos de arranque).
   - `tables/feedback` — `nome`, `email`, `assunto`, `mensagem`.
   - Lido com `GET tables/ranking?limit=N&sort=-pontos`; escrito com `POST tables/ranking`. O código tolera tabela indisponível e continua a funcionar offline (o ranking mostra o aluno local).

> Nota importante: o **armazenamento de preview/editor é separado do banco D1 do site publicado**. Os 8 registos de ranking inseridos nas ferramentas de tabela existem no preview. Para os ver no site publicado é necessário um Hosted Deploy seguido de `HostedDbSyncFromPreview` (com a devida autorização).

---

## Design

- Paleta: azul (`#1d4ed8` / `#2563eb`), branco, amarelo (`#facc15`); modo escuro completo via `[data-tema="escuro"]`.
- Tipografia: Plus Jakarta Sans (títulos) + Inter, via Google Fonts.
- Componentes: botões, badges, cards, níveis em gradiente, vocabulário, exercícios, chat, tabelas, medalhas, certificado.
- Responsivo: breakpoints em 980 / 860 / 720 px; menu hamburger; alvos de toque ≥ 40 px; `prefers-reduced-motion`.
- Acessibilidade: HTML semântico, `aria-*` em navegação/menus/modais/toasts, `role="status"` nos feedbacks, textos alternativos nos ícones, foco visível.
- SEO: `<title>`/`meta description` únicos por página, `canonical`, Open Graph, JSON-LD `EducationalOrganization`, `lang="pt-PT"`.

---

## Como usar

1. Abrir `index.html`.
2. **Começar a Aprender** → `cursos.html` → escolher nível → abrir aula.
3. Criar conta (botão *Entrar* → *Criar conta*) para guardar progresso, ou explorar sem conta (progresso não é guardado).
4. Painel administrativo em `admin.html` com as credenciais de demonstração indicadas no ecrã.

---

## Testes realizados

Verificado em headless Chromium:
- Consola limpa em `index.html`, `cursos.html`, `aula.html`, `exercicios.html`, `conversacao.html`, `dicionario.html`, `painel.html`, `certificado.html`, `admin.html` (corrigido um erro de sintaxe por apóstrofo não escapado em `js/pages/admin.js`).
- Capturas desktop (1280×800) e mobile (390×844): hero, botões, vocabulário com botões de áudio/estrela, exercícios com opções A/B/C, dicionário com filtro A-Z, chat com 7 diálogos, painel sem sessão, ausência de overflow horizontal e de código exposto.

---

## Trabalho pendente / próximos passos

- **Autenticação real multi-dispositivo**: as contas vivem no `localStorage`. Para uso em produção com vários dispositivos é necessário backend (a Table API não deve guardar hashes sem regras de acesso). Enquanto for local, mantenha a mensagem atual ao utilizador.
- **Publicação**: o site publicado só reflete as alterações após **Hosted Deploy** aprovado. O banco D1 nasce vazio; os dados de preview devem ser copiados com `HostedDbSyncFromPreview` (requer autorização do utilizador).
- **Edições do admin** aplicam-se ao navegador em que foram feitas. Para as tornar globais, é preciso transportá-las para `js/data/licoes-*.js` (o painel exporta JSON para facilitar).
- Áudio depende de vozes instaladas no sistema; em alguns Linux/Android sem voz inglesa a síntese é limitada.
- `speaking` requer microfone e permissão; existe sempre o botão «Já pratiquei» como alternativa.
- Considerar expansão do dicionário (>135) e tradução de explicações para variantes PT-BR onde há diferença lexical (telemóvel/celular, autocarro/ônibus).
